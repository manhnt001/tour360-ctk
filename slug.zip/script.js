!Object['hasOwnProperty']('values') && (Object['values'] = function(a) { return Object['keys'](a)['map'](function(b) { return a[b]; }); });
!String['prototype']['startsWith'] && (String['prototype']['startsWith'] = function(a, b) { return b = b || 0x0, this['indexOf'](a, b) === b; });
TDV['EventDispatcher'] = function() { this['_handlers'] = {}; }, TDV['EventDispatcher']['prototype']['bind'] = function(a, b) { if (!(a in this['_handlers'])) this['_handlers'][a] = [];
    this['_handlers'][a]['push'](b); }, TDV['EventDispatcher']['prototype']['unbind'] = function(a, b) { if (a in this['_handlers']) { var c = this['_handlers'][a]['indexOf'](b); if (c != -0x1) this['_handlers'][a]['splice'](c, 0x1); } }, TDV['EventDispatcher']['prototype']['createNewEvent'] = function(a) { if (typeof Event === 'function') return new Event(a); var b = document['createEvent']('Event'); return b['initEvent'](a, !![], !![]), b; }, TDV['EventDispatcher']['prototype']['dispatchEvent'] = function(a) { if (a['type'] in this['_handlers']) { var b = this['_handlers'][a['type']]; for (var c = 0x0; c < b['length']; ++c) { b[c]['call'](window, a); if (a['defaultPrevented']) break; } } };
class Timer { static['timers'] = new Set();
    static['visibilityListenerAttached'] = ![];
    constructor(a, b = null) { this['remaining'] = a * 0x3e8, this['start'] = Date['now'](), this['timeoutId'] = null, this['paused'] = ![], this['cancelled'] = ![], this['callback'] = b, this['_resolve'] = null, this['_attachVisibilityListener'](), this['_startTimer'](), Timer['timers']['add'](this); }['_startTimer']() { this['start'] = Date['now'](), this['timeoutId'] = setTimeout(() => this['_finish'](), this['remaining']); }['_pause']() { clearTimeout(this['timeoutId']); const a = Date['now']() - this['start'];
        this['remaining'] -= a, this['paused'] = !![]; }['_resume']() { this['paused'] = ![], this['_startTimer'](); }['_finish']() { Timer['timers']['delete'](this); if (this['cancelled']) return; if (this['callback']) this['callback'](); if (this['_resolve']) this['_resolve'](); }['cancel']() { this['cancelled'] = !![], clearTimeout(this['timeoutId']), Timer['timers']['delete'](this); }['getRemaining']() { if (this['cancelled']) return 0x0; if (this['paused']) return this['remaining']; const a = Date['now']() - this['start']; return Math['max'](0x0, this['remaining'] - a); }['wait']() { if (this['cancelled']) return Promise['resolve'](); if (this['_resolve']) return this['_promise']; return this['_promise'] = new Promise(a => { this['_resolve'] = a; }), this['_promise']; }['_attachVisibilityListener']() { if (Timer['visibilityListenerAttached']) return;
        document['addEventListener']('visibilitychange', () => { const a = document['visibilityState'] === 'visible'; for (const b of Timer['timers']) { if (a && b['paused']) b['_resume']();
                else !a && !b['paused'] && b['_pause'](); } }), Timer['visibilityListenerAttached'] = !![]; } }
TDV['Tour'] = function(a, b) { TDV['EventDispatcher']['call'](this), this['player'] = undefined, this['_settings'] = a, this['_devicesUrl'] = b, this['_playersPlayingTmp'] = [], this['_isInitialized'] = ![], this['_isPaused'] = ![], this['_isRemoteSession'] = ![], this['_orientation'] = undefined, this['_lockedOrientation'] = undefined, this['_device'] = undefined, Object['defineProperty'](this, 'isInitialized', { 'get': function() { return this['_isInitialized']; } }), Object['defineProperty'](this, 'isPaused', { 'get': function() { return this['_isPaused']; } }), this['_setupRemote'](); }, TDV['Tour']['DEVICE_GENERAL'] = 'general', TDV['Tour']['DEVICE_MOBILE'] = 'mobile', TDV['Tour']['DEVICE_IPAD'] = 'ipad', TDV['Tour']['DEVICE_VR'] = 'vr', TDV['Tour']['DEVICE_QUEST2'] = 'quest2', TDV['Tour']['DEVICE_QUEST3'] = 'quest3', TDV['Tour']['DEVICE_PICO'] = 'pico', TDV['Tour']['DEVICE_PICO_ULTRA'] = 'pico_ultra', TDV['Tour']['DEVICE_HTC'] = 'htc', TDV['Tour']['EVENT_TOUR_INITIALIZED'] = 'tourInitialized', TDV['Tour']['EVENT_TOUR_LOADED'] = 'tourLoaded', TDV['Tour']['EVENT_TOUR_ENDED'] = 'tourEnded', TDV['Tour']['prototype'] = new TDV['EventDispatcher'](), TDV['Tour']['prototype']['dispose'] = function() { if (!this['player']) return;
    this['_onHashChange'] && (window['removeEventListener']('hashchange', this['_onHashChange']), this['_onHashChange'] = undefined);
    this['_onKeyUp'] && (document['removeEventListener']('keyup', this['_onKeyUp']), this['_onKeyUp'] = undefined);
    this['_onBeforeUnload'] && (window['removeEventListener']('beforeunload', this['_onBeforeUnload']), this['_onBeforeUnload'] = undefined); var a = this['_getRootPlayer']();
    a !== undefined && (a['stopTextToSpeech'](), a['stopGlobalAudios']()), this['player']['delete'](), this['player'] = undefined, this['_isInitialized'] = ![], window['currentGlobalAudios'] = undefined, window['pauseGlobalAudiosState'] = undefined, window['currentPanoramasWithCameraChanged'] = undefined, window['overlaysDispatched'] = undefined; }, TDV['Tour']['prototype']['load'] = function() { if (this['player']) return; var a = function(d) { if (d['name'] == 'begin') { var e = d['data']['source']['get']('camera'); if (e && e['get']('initialSequence') && e['get']('initialSequence')['get']('movements')['length'] > 0x0) return; } if (d['sourceClassName'] == 'MediaAudio' || d['sourceClassName'] == 'Model3DCameraSequence' || this['_isInitialized']) return;
        this['_isInitialized'] = !![], b['unbind']('preloadMediaShow', a, this, !![]), b['unbindOnObjectsOf']('PlayListItem', 'begin', a, this, !![]), b['unbind']('stateChange', a, this, !![]); if (this['_isPaused']) this['pause']();
        window['parent']['postMessage'](TDV['Tour']['EVENT_TOUR_LOADED'], '*'), this['dispatchEvent'](this['createNewEvent'](TDV['Tour']['EVENT_TOUR_LOADED'])); };
    this['_setup'](), this['_settings']['set'](TDV['PlayerSettings']['SCRIPT_URL'], this['_currentScriptUrl']); var b = this['player'] = TDV['PlayerAPI']['create'](this['_settings']);
    b['bindOnObject']('rootPlayer', 'start', c, this, !![]), window['addEventListener']('message', function(d) { var f = d['data']; if (f == 'pauseTour') f = 'pause';
        else { if (f == 'resumeTour') f = 'resume';
            else return; }
        this[f]['apply'](this); }['bind'](this));

    function c(d) { b['unbindOnObject']('rootPlayer', 'start', c, this, !![]); var f = d['data']['source'];
        f['get']('data')['tour'] = this; var g = window['location'] !== window['parent']['location'] || window['frameElement'] !== undefined;
        f['set']('fullscreenFallback', g ? 'out_of_frame' : 'none'); var h = window['navigator']['language'] || window['navigator']['userLanguage'] || 'en',
            j = f['get']('data')['locales'] || {},
            k = f['get']('data')['defaultLocale'] || h,
            l = this['locManager'] = new TDV['Tour']['LocaleManager'](f, j, k, this['_settings']['get'](TDV['PlayerSettings']['QUERY_STRING_PARAMETERS']));
        f['get']('data')['localeManager'] = l, this['_setupXR'](); var m = function() { var w = f['get']('data');!('updateText' in w) && (w['updateText'] = function(A, B) { var C = A[0x0]['split']('.'); if (C['length'] == 0x2) { var D = l['trans']['apply'](l, A),
                        E = A[0x1] || f; if (typeof E == 'string') { var F = E['split']('.');
                        E = f[F['shift']()]; for (var G = 0x0; G < F['length'] - 0x1; ++G) { if (E != undefined) E = 'get' in E ? E['get'](F[G]) : E[F[G]]; } if (E != undefined) { var H = F[F['length'] - 0x1]; if (Array['isArray'](E))
                                for (var I = 0x0; I < E['length']; ++I) { this['setValue'](E[I], H, D); } else this['setValue'](E, H, D); } } else E = E[B || C[0x0]], this['setValue'](E, C[0x1], D); } }['bind'](f)); var x = w['translateObjs'],
                y = w['updateText'],
                z = function() { for (var A in x) { y(x[A], A['split']('.')[0x0]); } };
            z(), z(); };
        this['locManager']['bind'](TDV['Tour']['LocaleManager']['EVENT_LOCALE_CHANGED'], m['bind'](this)); var n = this['_getParams'](location['search']['substr'](0x1));
        n = f['mixObject'](n, this['_getParams'](location['hash']['substr'](0x1))); var o = n['language']; if (!o || !this['locManager']['hasLocale'](n['language'])) { if (f['get']('data')['forceDefaultLocale']) o = k;
            else o = h; }
        this['setLocale'](o); var p = f['getByClassName']('HotspotPanoramaOverlay'); for (var q = 0x0, r = p['length']; q < r; ++q) { var s = p[q],
                t = s['get']('data'); if (!t) s['set']('data', t = {});
            t['defaultEnabledValue'] = s['get']('enabled'); }
        this['_setMediaFromURL'](n, 0x0), this['_updateParams'](n, ![]); if (this['isMobile']() && typeof this['_devicesUrl'][this['_device']] == 'object') { var u = function() { if (!f['isCardboardViewMode']() && this['_getOrientation']() != this['_orientation']) return this['reload'](!![]), !![]; return ![]; }; if (u['call'](this)) return; var v = f['getByClassName']('PanoramaPlayer'); for (var q = 0x0; q < v['length']; ++q) { v[q]['bind']('viewModeChange', u, this); }
            f['bind']('orientationChange', u, this); }
        this['_onHashChange'] = function() { var w = this['_getParams'](location['hash']['substr'](0x1));
            this['_setMediaFromURL'](w), this['_updateParams'](w, !![]); }['bind'](this), this['_onKeyUp'] = function(w) { if (w['key'] === undefined) return; switch (w['key']['toLowerCase']()) {
                case 'u':
                    this['updateDeepLink'](), f['copyToClipboard'](location['href']); break;
                case 'm':
                    var x = f['getByClassName']('MeasureModel3DObject'),
                        y = f['getActiveMediaWithViewer'](f['getMainViewer']());
                    x['length'] > 0x0 && y['get']('class') == 'Model3D' && f['startMeasurement'](null, x[0x0]); break; } }['bind'](this), this['_onBeforeUnload'] = function(w) { f['stopTextToSpeech'](); }, window['addEventListener']('hashchange', this['_onHashChange']), window['addEventListener']('beforeunload', this['_onBeforeUnload']), document['addEventListener']('keyup', this['_onKeyUp']), f['bind']('tourEnded', function() { this['dispatchEvent'](this['createNewEvent'](TDV['Tour']['EVENT_TOUR_ENDED'])); }, this, !![]), f['bind']('mute_changed', function() { if (this['get']('mute')) this['stopTextToSpeech'](); }, f, !![]), b['bind']('preloadMediaShow', a, this, !![]), b['bind']('stateChange', a, this, !![]), b['bindOnObjectsOf']('PlayListItem', 'begin', a, this, !![]), this['dispatchEvent'](this['createNewEvent'](TDV['Tour']['EVENT_TOUR_INITIALIZED'])); } }, TDV['Tour']['prototype']['pause'] = function() { this['_isPaused'] = !![]; if (!this['_isInitialized']) return; var a = function(k) { var l = k['source']; if (!this['_isPaused']) l['unbind']('stateChange', a, this);
            else l['get']('state') == 'playing' && l['pause'](); },
        b = this['player']['getByClassName']('PlayList'); for (var c = 0x0, d = b['length']; c < d; c++) { var e = b[c],
            f = e['get']('selectedIndex'); if (f != -0x1) { var g = e['get']('items')[f],
                h = g['get']('player'); if (h && h['pause']) { if (h['get']('state') != 'playing') h['bind']('stateChange', a, this);
                else h['pause']();
                this['_playersPlayingTmp']['push'](h); } } } var j = this['_getRootPlayer']();
    j['pauseGlobalAudios'](), j['quizPauseTimer'](); }, TDV['Tour']['prototype']['resume'] = function() { this['_isPaused'] = ![]; if (!this['_isInitialized']) return; while (this['_playersPlayingTmp']['length']) { var a = this['_playersPlayingTmp']['pop']();
        a['play'](); } var b = this['_getRootPlayer']();
    b['resumeGlobalAudios'](), b['quizResumeTimer'](); }, TDV['Tour']['prototype']['reload'] = function(a) { this['_orientation'] = this['_getOrientation'](); if (a) this['updateDeepLink']();
    this['dispose'](), this['load'](); }, TDV['Tour']['prototype']['exportState'] = function() { var a = this['_getRootPlayer'](); if (a !== undefined) { var b = {};
        b['url'] = a['updateDeepLink']({ 'includeCurrentView': !![], 'includeCurrentVisibleHotspots': !![], 'includeCurrentMeasureModel3DObjects': !![] }); var c = a['get']('data')['quiz']; return c && (b['quiz'] = c['exportState']()), b; } return null; }, TDV['Tour']['prototype']['importState'] = function(a) { var b = this['_getRootPlayer'](); if (b !== undefined) { a['url'] && (window['location']['hash'] = undefined, window['location']['hash'] = a['url']); if (a['quiz']) { var c = b['get']('data')['quiz'];
            c['importState'](a['quiz']); } } }, TDV['Tour']['prototype']['setMediaByIndex'] = function(a) { var b = this['_getRootPlayer'](); if (b !== undefined) return b['setMainMediaByIndex'](a); }, TDV['Tour']['prototype']['setMediaByName'] = function(a) { var b = this['_getRootPlayer'](); if (b !== undefined) return b['setMainMediaByName'](a); }, TDV['Tour']['prototype']['triggerOverlayByName'] = function(a, b, c) { var d = this['_getRootPlayer'](); if (!c) c = 'click'; if (d !== undefined && c) { var e = d['getPanoramaOverlayByName'](a, b);
        e && d['triggerOverlay'](e, c); } }, TDV['Tour']['prototype']['focusOverlayByName'] = function(a, b) { var c = this['_getRootPlayer'](); if (c !== undefined) { var d = c['getPanoramaOverlayByName'](a['get']('media'), b); if (d) { var e = d['get']('class'),
                f = e == 'VideoPanoramaOverlay' || e == 'QuadVideoPanoramaOverlay' ? d : d['get']('items')[0x0],
                g, h;
            e = f['get']('class'); if (e == 'QuadVideoPanoramaOverlay' || e == 'QuadHotspotPanoramaOverlayImage') { var j = f['get']('vertices'),
                    k = 0x0,
                    l = j['length'];
                g = 0x0, h = 0x0; while (k < l) { var m = j[k++],
                        n = m['get']('yaw'); if (n < 0x0) n += 0x168;
                    g += n, h += m['get']('pitch'); }
                g /= 0x4, h /= 0x4; if (g > 0xb4) g -= 0x168; } else g = f['get']('yaw'), h = f['get']('pitch'); var o = c['getPlayListWithItem'](a); if (o) { var p = function() { c['setPanoramaCameraWithSpot'](o, a, g, h); }; if (!this['_isInitialized']) { var q = function() { a['unbind']('begin', q, this), p(); };
                    a['bind']('begin', q, this); } else p(); } } } }, TDV['Tour']['prototype']['setComponentsVisibilityByTags'] = function(a, b, c) { var d = this['_getRootPlayer'](); if (d !== undefined) { var e = d['getComponentsByTags'](a, c); for (var f = 0x0, g = e['length']; f < g; ++f) { var h = e[f],
                j = h['get']('id') + '_vr';
            j in this && this[j]['set']('visible', b); var k = h['get']('data') || {}; if (!!k['visibleOnlyOnVR'] || !!k['visibleIfCardboardAvailable'] && !this['get']('cardboardAvailable') || !!k['visibleIfGyroscopeAvailable'] && !this['get']('gyroscopeAvailable')) return;
            h['set']('visible', b); } } }, TDV['Tour']['prototype']['setOverlaysVisibilityByTags'] = function(a, b, c) { var d = this['_getRootPlayer'](); if (d !== undefined) { var e = d['getOverlaysByTags'](a, c);
        d['setOverlaysVisibility'](e, b); } }, TDV['Tour']['prototype']['setOverlaysVisibilityByName'] = function(a, b) { var c = this['_getRootPlayer'](); if (c !== undefined) { var d = c['getActiveMediaWithViewer'](c['getMainViewer']()),
            e = []; for (var f = 0x0, g = a['length']; f < g; ++f) { var h = c['getPanoramaOverlayByName'](d, a[f]); if (h) e['push'](h); }
        c['setOverlaysVisibility'](e, b); } }, TDV['Tour']['prototype']['setObjectsVisibilityByID'] = function(a, b) { var c = this['_getRootPlayer'](); if (c !== undefined) { var d = c['getActiveMediaWithViewer'](c['getMainViewer']());
        d['get']('class') == 'Model3D' && c['setObjectsVisibilityByID'](d, a, b); } }, TDV['Tour']['prototype']['setModel3DVariant'] = function(a) { var b = this['_getRootPlayer'](); if (b !== undefined) { var c = b['getActiveMediaWithViewer'](b['getMainViewer']());
        c['get']('class') == 'Model3D' && c['set']('variant', a); } }, TDV['Tour']['prototype']['updateDeepLink'] = function() { var a = this['_getRootPlayer']();
    a !== undefined && a['updateDeepLink']({ 'includeCurrentView': !![], 'includeCurrentVisibleHotspots': !![], 'includeCurrentMeasureModel3DObjects': !![], 'setHash': !![] }); }, TDV['Tour']['prototype']['setLocale'] = function(a) { var b = this['_getRootPlayer']();
    b !== undefined && this['locManager'] !== undefined && this['locManager']['setLocale'](a); }, TDV['Tour']['prototype']['getLocale'] = function() { var a = this['_getRootPlayer'](); return a !== undefined && this['locManager'] !== undefined ? this['locManager']['currentLocaleID'] : undefined; }, TDV['Tour']['prototype']['isMobile'] = function() { return TDV['PlayerAPI']['mobile']; }, TDV['Tour']['prototype']['isIPhone'] = function() { return TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_IPHONE']; }, TDV['Tour']['prototype']['isIPad'] = function() { return TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_IPAD']; }, TDV['Tour']['prototype']['isIOS'] = function() { return this['isIPad']() || this['isIPhone'](); }, TDV['Tour']['prototype']['isQuest2'] = function() { return TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_OCULUS_QUEST_2']; }, TDV['Tour']['prototype']['isQuest3'] = function() { return TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_OCULUS_QUEST_3']; }, TDV['Tour']['prototype']['isPico'] = function() { return TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_PICO_4'] || TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_PICO_G3'] || TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_PICO_NEO2'] || TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_PICO_NEO3']; }, TDV['Tour']['prototype']['isPicoUltra'] = function() { return TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_PICO_4_ULTRA']; }, TDV['Tour']['prototype']['isHTC'] = function() { return TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_VIVE_FOCUS'] || TDV['PlayerAPI']['device'] == TDV['PlayerAPI']['DEVICE_PICO_G2']; }, TDV['Tour']['prototype']['isMobileApp'] = function() { return navigator['userAgent']['indexOf']('App/TDV') != -0x1; }, TDV['Tour']['prototype']['isVRDevice'] = function() { return [TDV['PlayerAPI']['DEVICE_PICO_G2'], TDV['PlayerAPI']['DEVICE_PICO_G3'], TDV['PlayerAPI']['DEVICE_PICO_NEO2'], TDV['PlayerAPI']['DEVICE_PICO_NEO3'], TDV['PlayerAPI']['DEVICE_PICO_4'], TDV['PlayerAPI']['DEVICE_PICO_4_ULTRA'], TDV['PlayerAPI']['DEVICE_OCULUS_QUEST_2'], TDV['PlayerAPI']['DEVICE_OCULUS_QUEST_3'], TDV['PlayerAPI']['DEVICE_VIVE_FOCUS']]['indexOf'](TDV['PlayerAPI']['device']) != -0x1; }, TDV['Tour']['prototype']['getNotchValue'] = function() { var a = document['documentElement'];
    a['style']['setProperty']('--notch-top', 'env(safe-area-inset-top)'), a['style']['setProperty']('--notch-right', 'env(safe-area-inset-right)'), a['style']['setProperty']('--notch-bottom', 'env(safe-area-inset-bottom)'), a['style']['setProperty']('--notch-left', 'env(safe-area-inset-left)'); var b = window['getComputedStyle'](a); return parseInt(b['getPropertyValue']('--notch-top') || '0', 0xa) || parseInt(b['getPropertyValue']('--notch-right') || '0', 0xa) || parseInt(b['getPropertyValue']('--notch-bottom') || '0', 0xa) || parseInt(b['getPropertyValue']('--notch-left') || '0', 0xa); }, TDV['Tour']['prototype']['hasNotch'] = function() { return this['getNotchValue']() > 0x0; }, TDV['Tour']['prototype']['_getOrientation'] = function() { var a = this['_getRootPlayer'](); if (a) return a['get']('orientation');
    else return this['_lockedOrientation'] ? this['_lockedOrientation'] : TDV['PlayerAPI']['getOrientation'](); }, TDV['Tour']['prototype']['_getParams'] = function(a) { const b = new URLSearchParams(a),
        c = Object['create'](null); for (const [d, e] of b['entries']()) { c[d['toLowerCase']()] = e; } return c; }, TDV['Tour']['prototype']['_getRootPlayer'] = function() { return this['player'] !== undefined ? this['player']['getById']('rootPlayer') : undefined; }, TDV['Tour']['prototype']['_setup'] = function() { if (!this['_orientation']) this['_orientation'] = this['_getOrientation']();
    this['_device'] = this['_getDevice'](), this['_currentScriptUrl'] = this['_getScriptUrl'](); if (this['isMobile']()) { var a = document['getElementById']('metaViewport'); if (a) { var b = this['_devicesUrl'][this['_device']],
                c = 0x1;
            (typeof b == 'object' && this['_orientation'] in b && this['_orientation'] == TDV['PlayerAPI']['ORIENTATION_LANDSCAPE'] || this['_device'] == TDV['Tour']['DEVICE_GENERAL']) && (c = a['getAttribute']('data-tdv-general-scale') || 0.5); var d = a['getAttribute']('content');
            d = d['replace'](/initial-scale=(\d+(\.\d+)?)/, function(e, f) { return 'initial-scale=' + c; }), a['setAttribute']('content', d); } } }, TDV['Tour']['prototype']['_setupXR'] = function() { const a = this['_getRootPlayer'](),
        b = a['get']('data')['translateObjs'],
        c = a['get']('data')['xrPanels']; if (!c) return; const d = e => { const f = a['clone'](e, undefined, (g, h) => { const j = g['get']('class'); if (['WebFrame', 'ViewerArea', 'TabPanel', 'Window', 'ZoomImage']['indexOf'](j) !== -0x1) return null; if (j === 'PlayList') return g; const k = {},
                l = g['get']('data'); if (l) { if (!!l['visibleOnlyOnStandard']) return null;!!l['visibleOnlyOnVR'] && (k['visible'] = l['visibleOnVR'], k['data'] = { 'visibleOnlyOnVR': ![] }); } let m = g['get']('id');
            k['id'] = m + '_vr'; const n = g['getEventNames'](); for (const o of n) { a['cloneBindings'](g, h, o, p => { return p['replace'](m, k['id']); }); } for (let p in b) { if (p['indexOf'](m) === 0x0) { const q = p['replace'](m, k['id']);
                    b[q] = [...b[p]]; } } if (j == 'Button' || j == 'IconButton') { const r = ['buttonMute', 'buttonUnmute', 'buttonToggleMute']; for (const s of r) { const t = a['get'](s); if (!t || t['indexOf'](g) == -0x1) continue;
                    a['set'](s, [h, ...t]); } } return k; }); return f; }; for (let e = 0x0; e < c['length']; ++e) { const f = c[e],
            g = f['get']('data'),
            h = _getObject(a, g['content']),
            j = d(h); if (!j) continue;
        j['set']('width', g['width']), j['set']('height', g['height']), f['set']('content', j); }
    a['set']('xrPanels', c); }, TDV['Tour']['prototype']['_getScriptUrl'] = function() { var a = this['_devicesUrl'][this['_device']]; return typeof a == 'object' && (this['_orientation'] in a && (a = a[this['_orientation']])), a; }, TDV['Tour']['prototype']['_getDevice'] = function() { var a = TDV['Tour']['DEVICE_GENERAL']; if (!this['_isRemoteSession']) { if (this['isIPad']() && TDV['Tour']['DEVICE_IPAD'] in this['_devicesUrl']) a = TDV['Tour']['DEVICE_IPAD'];
        else { if (this['isQuest2']() && TDV['Tour']['DEVICE_QUEST2'] in this['_devicesUrl']) a = TDV['Tour']['DEVICE_QUEST2'];
            else { if (this['isQuest3']() && TDV['Tour']['DEVICE_QUEST3'] in this['_devicesUrl']) a = TDV['Tour']['DEVICE_QUEST3'];
                else { if (this['isPicoUltra']() && TDV['Tour']['DEVICE_PICO_ULTRA'] in this['_devicesUrl']) a = TDV['Tour']['DEVICE_PICO_ULTRA'];
                    else { if (this['isPico']() && TDV['Tour']['DEVICE_PICO'] in this['_devicesUrl']) a = TDV['Tour']['DEVICE_PICO'];
                        else { if (this['isHTC']() && TDV['Tour']['DEVICE_HTC'] in this['_devicesUrl']) a = TDV['Tour']['DEVICE_HTC'];
                            else { if (this['isMobile']() && TDV['Tour']['DEVICE_MOBILE'] in this['_devicesUrl'] && !this['isVRDevice']()) a = TDV['Tour']['DEVICE_MOBILE']; } } } } } } } return a; }, TDV['Tour']['prototype']['_setMediaFromURL'] = function(a, b) { var c = this['_getRootPlayer'](),
        d = c['getActivePlayerWithViewer'](c['getMainViewer']()),
        e = d ? c['getMediaFromPlayer'](d) : undefined,
        f; if ('media' in a) { var g = a['media'],
            h = Number(g);
        f = isNaN(h) ? this['setMediaByName'](g) : this['setMediaByIndex'](h - 0x1); } else { if ('media-index' in a) f = this['setMediaByIndex'](parseInt(a['media-index']) - 0x1);
        else 'media-name' in a && (f = this['setMediaByName'](decodeURIComponent(a['media-name']))); }
    f == undefined && b !== undefined && (f = this['setMediaByIndex'](0x0)); if (f != undefined) { var i = f['get']('player'),
            j = function() { 'trigger-overlay-name' in a && this['triggerOverlayByName'](f['get']('media'), a['trigger-overlay-name'], a['trigger-overlay-event']); if ('focus-overlay-name' in a) this['focusOverlayByName'](f, a['focus-overlay-name']);
                else { if ('yaw' in a || 'pitch' in a) { var n = c['getPlayListWithItem'](f); if (n) switch (f['get']('class')) {
                            case 'PanoramaPlayListItem':
                                var o = parseFloat(a['yaw']) || undefined,
                                    p = parseFloat(a['pitch']) || undefined,
                                    q = parseFloat(a['fov']) || undefined;
                                c['setPanoramaCameraWithSpot'](n, f, o, p, q); break;
                            case 'Model3DPlayListItem':
                                var r = ['yaw', 'pitch', 'x', 'y', 'z', 'distance'],
                                    s = {}; for (var t = 0x0; t < r['length']; ++t) { var u = r[t],
                                        v = parseFloat(a[u]); if (!isNaN(v)) s[u] = v; }
                                c['setModel3DCameraSpot'](n, f, s); break; } } } }['bind'](this); if (i) { var k = i['get']('viewerArea') == c['getMainViewer'](),
                l = c['getMediaFromPlayer'](i); if (k && e == f['get']('media') || !k && l == f['get']('media')) return j(), f != undefined; } var m = function() { f['unbind']('begin', m, this), j(); };
        f['bind']('begin', m, c); } return f != undefined; }, TDV['Tour']['prototype']['_setupRemote'] = function() { if (this['isMobile']() && TDV['Remote'] != undefined) { var a = function() { var b, c = function() { var f = this['_getRootPlayer']();
                b = f['get']('lockedOrientation'), f['set']('lockedOrientation', this['_lockedOrientation']); }['bind'](this);
            this['_isRemoteSession'] = !![], this['_lockedOrientation'] = TDV['PlayerAPI']['ORIENTATION_LANDSCAPE']; if (this['_device'] != TDV['Tour']['DEVICE_GENERAL']) { var d = function() { c(), this['unbind'](TDV['Tour']['EVENT_TOUR_INITIALIZED'], d); }['bind'](this);
                this['bind'](TDV['Tour']['EVENT_TOUR_INITIALIZED'], d), this['reload'](!![]); } else c(); var e = function() { this['_isRemoteSession'] = ![], this['_getRootPlayer']()['set']('lockedOrientation', b), TDV['Remote']['unbind'](TDV['Remote']['EVENT_CALL_END'], e); var f = this['_getScriptUrl'](); if (this['_currentScriptUrl'] != f) this['reload'](!![]); }['bind'](this);
            TDV['Remote']['bind'](TDV['Remote']['EVENT_CALL_END'], e); }['bind'](this);
        TDV['Remote']['bind'](TDV['Remote']['EVENT_CALL_BEGIN'], a); } }, TDV['Tour']['prototype']['_updateParams'] = function(a, b) { if (b && 'language' in a) { var c = a['language'];
        this['locManager']['hasLocale'](c) && this['setLocale'](c); } var d = function(f, g, h) { var j = g['split'](','); for (var k = 0x0, l = j['length']; k < l; ++k) { f['call'](this, j[k]['split']('+'), h, 'and'); } },
        e = function(f) { var g = this['_getRootPlayer'](),
                h = g['getActiveMediaWithViewer'](g['getMainViewer']()); if (h['get']('class') != 'Model3D') return; var i = h['get']('objects'),
                j = [];
            f['split']('+')['forEach'](function(k) { var l = k['split'](','),
                    m = l['shift'](); if (m in g && l['length'] % 0x3 == 0x0) { var n = l[0x0],
                        o = l[0x1],
                        p = l[0x2],
                        q = i['some'](function(v) { return v['get']('class') == 'MeasureModel3DObject' && n == v['get']('x') && o == v['get']('y') && p == v['get']('z'); }); if (q) return; var r = [],
                        s = _cloneMeasureModel3DObject['call'](this, this[m]);
                    s['set']('mode', 'view'), s['set']('x', n), s['set']('y', o), s['set']('z', p); for (var t = 0x3; t < l['length']; t += 0x3) { var u = this['createInstance']('MeasureModel3DObjectPoint');
                        u['set']('x', l[t]), u['set']('y', l[t + 0x1]), u['set']('z', l[t + 0x2]), r['push'](u); }
                    s['set']('points', r), j['push'](s); } }['bind'](g)), j['length'] > 0x0 && h['set']('objects', i['concat'](j)); }; if ('hide-components-tags' in a || 'hct' in a) d['call'](this, this['setComponentsVisibilityByTags'], a['hide-components-tags'] || a['hct'], ![]); if ('show-components-tags' in a || 'sct' in a) d['call'](this, this['setComponentsVisibilityByTags'], a['show-components-tags'] || a['sct'], !![]); if ('hide-overlays-tags' in a || 'hot' in a) d['call'](this, this['setOverlaysVisibilityByTags'], a['hide-overlays-tags'] || a['hot'], ![]); if ('show-overlays-tags' in a || 'sot' in a) d['call'](this, this['setOverlaysVisibilityByTags'], a['show-overlays-tags'] || a['sot'], !![]); if ('hide-overlays-names' in a || 'hon' in a) this['setOverlaysVisibilityByName'](decodeURIComponent(a['hide-overlays-names'] || a['hon'])['split'](','), ![]); if ('show-overlays-names' in a || 'son' in a) this['setOverlaysVisibilityByName'](decodeURIComponent(a['show-overlays-names'] || a['son'])['split'](','), !![]); if ('show-object-ids' in a || 'sobjids' in a) this['setObjectsVisibilityByID'](decodeURIComponent(a['show-object-ids'] || a['sobjids'])['split'](','), !![]); if ('hide-object-ids' in a || 'hobjids' in a) this['setObjectsVisibilityByID'](decodeURIComponent(a['hide-object-ids'] || a['hobjids'])['split'](','), ![]); if ('variant' in a) this['setModel3DVariant'](decodeURIComponent(a['variant'])); if ('measures' in a) e['call'](this, decodeURIComponent(a['measures']['split'](';'))); }, TDV['Tour']['LocaleManager'] = function(a, b, c, d) { TDV['EventDispatcher']['call'](this), this['rootPlayer'] = a, this['locales'] = {}, this['defaultLocale'] = c, this['queryParam'] = d, this['currentLocaleMap'] = {}, this['currentLocaleID'] = undefined; for (var e in b) { this['registerLocale'](e, b[e]); } }, TDV['Tour']['LocaleManager']['EVENT_LOCALE_CHANGED'] = 'localeChanged', TDV['Tour']['LocaleManager']['prototype'] = new TDV['EventDispatcher'](), TDV['Tour']['LocaleManager']['prototype']['registerLocale'] = function(a, b) { var c = [a, a['split']('-')[0x0]]; for (var d = 0x0; d < c['length']; ++d) { a = c[d], !(a in this['locales']) && (this['locales'][a] = b); } }, TDV['Tour']['LocaleManager']['prototype']['unregisterLocale'] = function(a) { delete this['locales'][a], a == this['currentLocaleID'] && this['setLocale'](this['defaultLocale']); }, TDV['Tour']['LocaleManager']['prototype']['hasLocale'] = function(a) { return a in this['locales']; }, TDV['Tour']['LocaleManager']['prototype']['setLocale'] = function(a) { var b, c = a['split']('-')[0x0],
        d = [a, c]; for (var e = 0x0; e < d['length']; ++e) { var f = d[e]; if (f in this['locales']) { b = f; break; } } if (b === undefined)
        for (var f in this['locales']) { if (f['indexOf'](c) == 0x0) { b = f; break; } }
    b === undefined && (b = this['defaultLocale']); var g = this['locales'][b]; if (g !== undefined && this['currentLocaleID'] != b) { this['currentLocaleID'] = b; var h = this; if (typeof g == 'string') { var j = new XMLHttpRequest();
            j['onreadystatechange'] = function() { if (j['readyState'] == 0x4) { if (j['status'] == 0xc8) h['locales'][b] = h['currentLocaleMap'] = h['_parsePropertiesContent'](j['responseText']), h['dispatchEvent'](h['createNewEvent'](TDV['Tour']['LocaleManager']['EVENT_LOCALE_CHANGED']));
                    else throw g + '\x20can\x27t\x20be\x20loaded'; } }; var k = g; if (this['queryParam']) k += (k['indexOf']('?') == -0x1 ? '?' : '&') + this['queryParam'];
            j['open']('GET', k), j['send'](); } else this['currentLocaleMap'] = g, this['dispatchEvent'](this['createNewEvent'](TDV['Tour']['LocaleManager']['EVENT_LOCALE_CHANGED'])); } }, TDV['Tour']['LocaleManager']['prototype']['trans'] = function(a) {
    function b(f) { return /^\d+$/ ['test'](f); } var c = this['currentLocaleMap'][a]; if (c && arguments['length'] > 0x2) { var d = typeof arguments[0x2] == 'object' ? arguments[0x2] : undefined,
            e = arguments;
        c = c['replace'](/\{\{([\w _\-\.]+)\}\}/g, function(f, g) { if (b(g)) g = e[parseInt(g) + 0x1];
            else { if (d !== undefined) g = d[g]; } if (typeof g == 'string') g = this['currentLocaleMap'][g] || g;
            else { if (typeof g == 'function') g = g['call'](this['rootPlayer']); } return g !== undefined ? g : ''; }['bind'](this)); } return c; }, TDV['Tour']['LocaleManager']['prototype']['_parsePropertiesContent'] = function(a) { a = a['replace'](/(^|\n)#[^\n]*/g, ''); var b = {},
        c = a['split']('\x0a'); for (var d = 0x0, e = c['length']; d < e; ++d) { var f = c[d]['trim'](); if (f['length'] == 0x0) continue; var g = f['indexOf']('='); if (g == -0x1) { console['error']('Locale\x20parser:\x20Invalid\x20line\x20' + d); continue; } var h = f['substr'](0x0, g)['trim'](),
            j = f['substr'](g + 0x1)['trim'](),
            k; while ((k = j['lastIndexOf']('\x5c')) != -0x1 && k == j['length'] - 0x1 && ++d < e) { j = j['substr'](0x0, j['length'] - 0x2), f = c[d]; if (f['length'] == 0x0) break;
            j += '\x0a' + f, j = j['trim'](); }
        b[h] = j; } return b; }, TDV['Tour']['HistoryData'] = function(a) { this['playList'] = a, this['list'] = [], this['pointer'] = -0x1; }, TDV['Tour']['HistoryData']['prototype']['add'] = function(a) { if (this['pointer'] < this['list']['length'] && this['list'][this['pointer']] == a) return;++this['pointer'], this['list']['splice'](this['pointer'], this['list']['length'] - this['pointer'], a); }, TDV['Tour']['HistoryData']['prototype']['back'] = function() { if (!this['canBack']()) return;
    this['playList']['set']('selectedIndex', this['list'][--this['pointer']]); }, TDV['Tour']['HistoryData']['prototype']['forward'] = function() { if (!this['canForward']()) return;
    this['playList']['set']('selectedIndex', this['list'][++this['pointer']]); }, TDV['Tour']['HistoryData']['prototype']['canBack'] = function() { return this['pointer'] > 0x0; }, TDV['Tour']['HistoryData']['prototype']['canForward'] = function() { return this['pointer'] >= 0x0 && this['pointer'] < this['list']['length'] - 0x1; };

function _getObject(a, b) { return typeof b == 'string' ? a[b['replace']('this.', '')] : b; }

function _initModels() { var a = this['getByClassName']('Model3D');
    a['forEach'](function(b) { var c = b['get']('data'),
            d = c['panoramaLocations'];
        d && d['forEach'](function(f) { f = _getObject(this, f); var g = f['get']('data'),
                h = _getObject(this, g['panorama']);
            h['set']('modelLocations', (h['get']('modelLocations') || [])['concat'](f)); }['bind'](this)); var e = c['dynamicPixelRatio'] !== undefined ? c['dynamicPixelRatio'] : !![]; if (e) b['pixelRatioMinScale'] = 0.5;
        this['getPlayListItems'](b)['forEach'](function(f) { _initModel3DItem['call'](this, f); }['bind'](this)); }['bind'](this)); }

function _initModel3DItem(a) { var b = a['get']('player'); if (!b) return; var c = b['get']('viewerArea'); if (!c) return; var d = a['get']('media'),
        e, f;
    a['bind']('start', function() { f = c['get']('aaEnabled'); var g = d['get']('model')['get']('levels')[0x0]['get']('url')['split']('.')['pop']()['split']('?')['shift']()['toLowerCase'](),
            h = ['ply', 'splat', 'bin']['indexOf'](g) !== -0x1;
        c['set']('aaEnabled', !h); }, this), a['bind']('begin', function() { _initModel['call'](this, d); var g = d['get']('data')['keepModel3DLoadedWithoutLocation']; if (g === undefined) g = !![];
        this['getByClassName']('PanoramaPlayer')['filter'](h => h['get']('viewerArea') == c)['forEach'](h => { h['set']('keepModel3DLoadedWithoutLocation', g); }), this['getCurrentPlayers']()['forEach'](function(h) { h['get']('class') == 'PanoramaPlayer' && h['get']('viewerArea') == c && h['set']('model3DPlayer', b); }); }, this), a['bind']('stop', function() { c['set']('aaEnabled', f); }, this); }

function _initModel(a) { var b = a['get']('data'); if (!b) a['set']('data', b = {}); if (!b['panoramaLocations'] || b['isInitialized'] || !a['get']('isLoaded')) return; var c = this['get']('data'),
        d = 0xb4 / Math['PI'],
        e = a['get']('worldUnitToMeters') || 0x1,
        f = b['maxDistanceObjectsVisible'] || 0x0,
        g = b['panoramaLocations'],
        h = [],
        i = c['surfaceSelectionHotspotMode'],
        j = i == 'hotspotEnabled',
        k = new Set();
    g['forEach'](function(r) { r = _getObject(this, r); var s = r['get']('data'),
            t = a['getDistanceToFloor']([r['get']('x'), r['get']('y'), r['get']('z')]),
            u = _getObject(this, s['panorama']),
            v = g['filter'](function(F) { var G = _getObject(this, _getObject(this, F)['get']('data')); return !G['excludeAsHotspotPanorama'] && u != G['panorama'] && !k['has'](u); }['bind'](this))['map'](function(F) { F = _getObject(this, F); var G = F['get']('data'),
                    H = !!G['excludeSurfaceSelectionModel'],
                    I = F['get']('x') - r['get']('x'),
                    J = F['get']('y') - r['get']('y'),
                    K = F['get']('z') - r['get']('z'),
                    L = Math['atan2'](I, -K) * d,
                    M = Math['atan2'](J, Math['sqrt'](I * I + K * K)) * d,
                    N = Math['sqrt'](I * I + J * J + K * K),
                    O = a['getDistanceToFloor']([F['get']('x'), F['get']('y'), F['get']('z')]); if (t !== undefined && O !== undefined) J = O - t; var P = Math['sqrt'](I * I + J * J + K * K); return { 'yaw': L, 'pitch': M, 'width': G['width'], 'height': G['height'], 'opacity': G['opacity'], 'anchorX': G['anchorX'] ? G['anchorX'] : 0.5, 'anchorY': G['anchorY'] ? G['anchorY'] : 0.5, 'transparentAreaActive': !!G['transparentAreaActive'], 'actions': G['actions'], 'position': { 'x': F['get']('x'), 'y': F['get']('y'), 'z': F['get']('z') }, 'toolTip': G['toolTip'], 'image': _getObject(this, G['image']), 'distance': N * e, 'floorDistance': P * e, 'panorama': _getObject(this, G['panorama']), 'backwardYaw': L - 0xb4 - F['get']('yaw'), 'excludeSurfacePanorama': H }; }['bind'](this));
        v['sort'](function(F, G) { return F['distance'] - G['distance']; }), k['add'](u); var w = [],
            x = (u['get']('adjacentPanoramas') || [])['concat'](),
            y = a['get']('maxNearestObjectsVisible'),
            z = b['showOnlyHotspotsLineSightInPanoramas'],
            A = { 'x': r['get']('x'), 'y': r['get']('y'), 'z': r['get']('z') },
            B = [];
        v['forEach'](function(F) { if (F['panorama'] == u || y > 0x0 && w['length'] >= y || f > 0x0 && F['distance'] > f || z && a['testIntersection'](A, F['position'])) return; var G = m['call'](this, F['panorama'], F['yaw'] - r['get']('yaw'), F['pitch'], F['width'], F['height'], F['anchorX'], F['anchorY'], F['opacity'], F['transparentAreaActive'], F['image'], j && !F['excludeSurfacePanorama']),
                H = n['call'](this, F['panorama'], F['yaw'] - r['get']('yaw'), F['backwardYaw'], F['floorDistance'], !F['excludeSurfacePanorama']);
            w['push'](G); var I = x['findIndex'](function(M) { return M['get']('panorama') == F['panorama']; }); if (I != -0x1) x['splice'](I, 0x1);
            x['push'](H); var J = G['get']('areas')[0x0];
            F['toolTip'] && J['set']('toolTip', F['toolTip']);
            J['bind']('click', l['bind'](this, u, F['panorama'], a, !![]), this), H['bind']('select', l['bind'](this, u, F['panorama'], a, !![]), this), B['push'](G), B['push'](H); var K = F['actions']; if (K) { q['call'](this, G, K), q['call'](this, J, K); var L = G['get']('items')[0x0];
                q['call'](this, L, K); if ('click' in K) H['bind']('select', new Function('event', K['click']), this); } }['bind'](this)), u['set']('overlays', (u['get']('overlays') || [])['concat'](w)), u['set']('adjacentPanoramas', x); var C = !a['get']('surfaceSelectionEnabled') || !!s['excludeSurfaceSelectionModel'],
            D; if (C) { D = o['call'](this, r['get']('x'), r['get']('y'), r['get']('z'), s['width'], s['height'], s['anchorX'] ? s['anchorX'] : 0.5, s['anchorY'] ? s['anchorY'] : 0.5, s['opacity'], !!s['transparentAreaActive'], b['showOnlyHotspotsLineSight'], _getObject(this, s['image'])), D['set']('id', 'sprite_' + r['get']('id')), D['set']('translationLineColor', s['translationLineColor'] != null ? s['translationLineColor'] : '#ffffff'), D['set']('translationLineOpacity', s['translationLineOpacity'] != null ? s['translationLineOpacity'] : 0x1), D['set']('translationLineVisible', s['translationLineVisible'] != null ? s['translationLineVisible'] : ![]), D['set']('translationLineWidth', s['translationLineWidth'] != null ? s['translationLineWidth'] : 0x1), D['set']('translationLength', s['translationLength'] != null ? s['translationLength'] : b['showOnlyHotspotsLineSight'] && (s['translationY'] == null || s['translationY'] == 0x0) ? s['height'] / 0x2 : undefined), D['set']('translationX', s['translationX'] != null ? s['translationX'] : 0x0), D['set']('translationY', s['translationY'] != null && s['translationY'] != 0x0 ? s['translationY'] : b['showOnlyHotspotsLineSight'] ? 0x1 : 0x0), D['set']('translationZ', s['translationZ'] != null ? s['translationZ'] : 0x0); if (s['toolTip']) D['set']('toolTip', s['toolTip']); } else D = p['call'](this, r['get']('x'), r['get']('y'), r['get']('z'));
        s['object'] = D; if (s['tags'] !== undefined) D['get']('data')['tags'] = s['tags']; if (s['enabled'] !== undefined) D['set']('enabled', s['enabled']);
        D['get']('data')['location'] = r, D['get']('data')['panoramaOverlays'] = B; var E = s['actions'];
        E && q['call'](this, D, E), D['bind']('click', l['bind'](this, a, u, a, ![]), this), h['push'](D); }['bind'](this)), a['set']('objects', (a['get']('objects') || [])['concat'](h)), b['isInitialized'] = !![];

    function l(r, s, t, u) { var v = this['getPlayListsWithMedia'](r, !![])['filter'](function(C) { return this['getMediaFromPlayer'](C['get']('items')[C['get']('selectedIndex')]['get']('player')) == r; }['bind'](this)); if (v['length'] == 0x0) return; var w = this['getPlayListItemByMedia'](v[0x0], r),
            x = w['get']('player')['get']('viewerArea'),
            y;
        this['getPlayListsWithMedia'](s)['forEach'](function(C) { var D = this['getPlayListItemByMedia'](C, s);
            D['get']('player')['get']('viewerArea') == x && (u && w['get']('player')['get']('viewerArea')['get']('translationTransitionEnabled') && (z(), D['bind']('begin', B, this)), x['set']('panoramaToPanoramaModelTransitionEnabled', b['panoramaToPanoramaModelTransitionEnabled']), C['set']('selectedIndex', C['get']('items')['indexOf'](D))); }['bind'](this));

        function z() { y = t['get']('objects')['filter'](function(C) { var D = C['get']('data'); return D && D['location'] !== undefined; }), y['forEach'](function(C) { C['set']('enabled', ![]); }); }

        function A() { y['forEach'](function(C) { C['set']('enabled', !![]); }); }

        function B(C) { C['source']['unbind']('begin', B, this), A(); } }

    function m(r, s, t, u, v, w, x, y, z, A, B) { var C = _createInstanceFromObj(this, { 'class': 'HotspotPanoramaOverlay', 'useHandCursor': !![], 'enabledInSurfaceSelection': B, 'enabledInVR': !![], 'areas': [{ 'class': 'HotspotPanoramaOverlayArea', 'mapColor': z ? 'any' : 'image', 'displayTooltipInTouchScreens': c['displayTooltipInTouchScreens'] }], 'items': [{ 'class': 'FlatHotspotPanoramaOverlayImage', 'yaw': s, 'pitch': t, 'width': u, 'height': v, 'offsetX': w * u, 'offsetY': x * v, 'opacity': y !== undefined ? y : 0x1 }] }); return C['get']('items')[0x0]['set']('image', A), C; }

    function n(r, s, t, u, v) { return _createInstanceFromObj(this, { 'class': 'AdjacentPanorama', 'panorama': 'this.' + r['get']('id'), 'backwardYaw': t, 'yaw': s, 'distance': u, 'enabledInSurfaceSelection': v }); }

    function o(r, s, t, u, v, w, A, B, C, D, E) { var F = _createInstanceFromObj(this, { 'class': 'SpriteModel3DObject', 'x': r, 'y': s, 'z': t, 'anchorX': w, 'anchorY': A, 'depthTest': D, 'transparentAreaActive': C, 'hideBasedOnDistance': !![], 'width': u, 'height': v, 'opacity': B != undefined ? B : 0x1, 'data': {} }); return F['set']('image', E), F; }

    function p(r, s, t) { return _createInstanceFromObj(this, { 'class': 'SurfaceReticleModel3DObject', 'x': r, 'y': s, 'z': t, 'depthTest': ![], 'data': {} }); }

    function q(r, s) { Object['keys'](s)['forEach'](function(t) { if (r['hasEvent'](t)) r['bind'](t, new Function('event', s[t]), this); }['bind'](this)); } }

function _findLocationWithPanorama(a) { var b = this['getByClassName']('Model3D'); for (var c = 0x0, d = b['length']; c < d; ++c) { var e = b[c],
            f = e['get']('data'); if (f && f['panoramaLocations']) { var g = f['panoramaLocations']['find'](function(h) { return h = _getObject(this, h), _getObject(this, h['get']('data')['panorama']) == a; }['bind'](this)); if (g) return _getObject(this, g); } } return undefined; }

function _getPlayersWithViewer(a) { var b = this['getCurrentPlayers'](),
        c = b['length']; while (c-- > 0x0) { var d = b[c];
        d['get']('viewerArea') != a && b['splice'](c, 0x1); } return b; }

function _createInstance(a, b, c) { var d = a['createInstance'](b); return c && (d['set']('id', c), a[c] = d), d; }

function _createInstanceFromObj(a, b) { return c(b);

    function c(d, f) { if (typeof d == 'object') { if ('class' in d) try { f = _createInstance(a, d['class'], d['id']); } catch (j) { f = d; } else f = d; } var g = function(k, l) { if ('set' in f) f['set'](k, l);
            else f[k] = l; }; for (var h in d) { var i = d[h]; if (typeof i == 'object' && i !== null) g(h, c(i, f));
            else { if (typeof i == 'string' && i['indexOf']('this.') == 0x0) g(h, a[i['replace']('this.', '')]);
                else g(h, i); } } return f; } }
TDV['Tour']['Script'] = function() {}, TDV['Tour']['Script']['assignObjRecursively'] = function(a, b) { for (var c in a) { var d = a[c]; if (typeof d == 'object' && d !== null) this['assignObjRecursively'](a[c], b[c] || (b[c] = {}));
        else b[c] = d; } return b; }, TDV['Tour']['Script']['autotriggerAtStart'] = function(a, b, c) { var d = function(e) { b(); if (c == !![]) a['unbind']('change', d, this); };
    a['bind']('change', d, this); }, TDV['Tour']['Script']['changeBackgroundWhilePlay'] = function(a, b, c) { var d = function() { e['unbind']('stop', d, this), c == g['get']('backgroundColor') && j == g['get']('backgroundColorRatios') && (g['set']('backgroundColor', h), g['set']('backgroundColorRatios', i)); },
        e = a['get']('items')[b],
        f = e['get']('player'),
        g = f['get']('viewerArea'),
        h = g['get']('backgroundColor'),
        i = g['get']('backgroundColorRatios'),
        j = [0x0];
    (c != h || j != i) && (g['set']('backgroundColor', c), g['set']('backgroundColorRatios', j), e['bind']('stop', d, this)); }, TDV['Tour']['Script']['changeOpacityWhilePlay'] = function(a, b, c) { var d = function() { e['unbind']('stop', d, this), h == g['get']('backgroundOpacity') && g['set']('opacity', h); },
        e = a['get']('items')[b],
        f = e['get']('player'),
        g = f['get']('viewerArea'),
        h = g['get']('backgroundOpacity');
    c != h && (g['set']('backgroundOpacity', c), e['bind']('stop', d, this)); }, TDV['Tour']['Script']['changePlayListWithSameSpot'] = function(a, b) { var c = a['get']('selectedIndex'); if (c >= 0x0 && b >= 0x0 && c != b) { var d = a['get']('items')[c],
            e = a['get']('items')[b],
            f = d['get']('player'),
            g = e['get']('player'); if ((f['get']('class') == 'PanoramaPlayer' || f['get']('class') == 'Video360Player') && (g['get']('class') == 'PanoramaPlayer' || g['get']('class') == 'Video360Player')) { var h = this['clonePanoramaCamera'](e['get']('camera'));
            this['setCameraSameSpotAsMedia'](h, d['get']('media')); var i = h['get']('initialPosition'); if (i['get']('yaw') == undefined || i['get']('pitch') == undefined || i['get']('hfov') == undefined) return;
            this['startPanoramaWithCamera'](e['get']('media'), h); } } }, TDV['Tour']['Script']['clone'] = function(a, b, c, d = new WeakMap()) { if (Array['isArray'](a)) return a['map'](e => { return this['clone'](e, undefined, c, d); })['filter'](e => { return e !== null; }); if (a && typeof a === 'object') { if (d['has'](a)) return d['get'](a); let e; if (typeof a['get'] === 'function' && a['get']('class') !== undefined) { const f = a['get']('class');
            e = this['rootPlayer']['createInstance'](f); let g; if (typeof c === 'function') { g = c(a, e); if (g === null) return null; if (g === a) return a; } else g = {};
            d['set'](a, e); if (b === undefined) { b = a['getAttributeNames']()['filter'](i => { return i !== 'id'; }); if (f === 'Video360Resource') b = b['filter'](i => i !== 'levels');
                else { if (f === 'Video360') b = b['filter'](i => i !== 'frames'); } } let h = g['id'];
            h && (e['set']('id', h), this[h] = e); for (const i of b) { if (i in g) { if (i === 'data') { const l = this['clone'](a['get']('data'), undefined, c, d);
                        Object['assign'](l, g[i]), g[i] = l; }
                    e['set'](i, g[i]); continue; } const j = this['clone'](a['get'](i), undefined, c, d); if (j !== null) e['set'](i, j); } } else { e = {}, d['set'](a, e); for (const m in a) { if (m in e) continue; if (Object['prototype']['hasOwnProperty']['call'](a, m)) { const n = this['clone'](a[m], undefined, c, d); if (n !== null) e[m] = n; } } } return e; } return a; }, TDV['Tour']['Script']['cloneBindings'] = function(a, b, c, d) { var e = a['getBindings'](c, undefined, !![]); for (let g = 0x0; g < e['length']; ++g) { let h = e[g];
        typeof h == 'string' && (typeof d === 'function' && (h = d(h)), h = new Function('event', h)), b['bind'](c, h, this); } }, TDV['Tour']['Script']['clonePanoramaCamera'] = function(a) { var b = this['clone'](a, ['manualRotationSpeed', 'manualZoomSpeed', 'automaticRotationSpeed', 'automaticZoomSpeed', 'timeToIdle', 'sequences', 'draggingFactor', 'hoverFactor']),
        c = ['initialSequence', 'idleSequence']; for (var d = 0x0; d < c['length']; ++d) { var e = c[d],
            f = a['get'](e); if (f) { var g = this['clone'](f, ['mandatory', 'repeat', 'restartMovementOnUserInteraction', 'restartMovementDelay']);
            b['set'](e, g); var h = f['get']('movements'),
                k = [],
                l = ['easing', 'duration', 'hfovSpeed', 'pitchSpeed', 'yawSpeed', 'path', 'stereographicFactorSpeed', 'targetYaw', 'targetPitch', 'targetHfov', 'targetStereographicFactor', 'hfovDelta', 'pitchDelta', 'yawDelta']; for (var m = 0x0; m < h['length']; ++m) { var n = h[m],
                    o = this['clone'](n, l);
                this['cloneBindings'](n, o, 'end', p => { return p['replace'](a['get']('id'), b['get']('id')); }), k['push'](o); }
            g['set']('movements', k); } } return b; }, TDV['Tour']['Script']['copyObjRecursively'] = function(a) { var b = {}; for (var c in a) { var d = a[c]; if (typeof d == 'object' && d !== null) b[c] = this['copyObjRecursively'](a[c]);
        else b[c] = d; } return b; }, TDV['Tour']['Script']['copyToClipboard'] = function(a) { if (navigator['clipboard']) navigator['clipboard']['writeText'](a);
    else { var b = document['createElement']('textarea');
        b['value'] = a, b['style']['position'] = 'fixed', document['body']['appendChild'](b), b['focus'](), b['select'](); try { document['execCommand']('copy'); } catch (c) {}
        document['body']['removeChild'](b); } }, TDV['Tour']['Script']['createTween'] = function(a, b, c, d, e) { var f = this['rootPlayer']['createInstance']('Effect'),
        g = this['get']('data')['tweensState'];!g && (this['get']('data')['tweensState'] = g = {}); var h = 'get' in a && typeof a['get'] === 'function',
        i = (h && a['get']('id') ? a['get']('id') : (Math['random']() + 0x1)['toString'](0x24)['substring'](0x2)) + '_',
        j = {}; for (var k in b) { var l = b[k]; if (k['startsWith']('on') && (typeof l === 'function' || typeof l === 'string')) { var m = k['slice'](0x2); if (typeof l === 'string') l = eval('(' + l + ')');
            f['bind'](m['charAt'](0x0)['toLowerCase']() + m['slice'](0x1), l, this); } else { if (typeof l === 'string' && l['startsWith']('#')) { var n = parseInt('0x' + (h ? a['get'](k)['slice'](0x1) : a[k]['slice'](0x1))),
                    o = parseInt('0x' + l['slice'](0x1));
                j[k] = { 'color': !![], 'initialRGB': [n >> 0x10 & 0xff, n >> 0x8 & 0xff, n & 0xff], 'finalRGB': [o >> 0x10 & 0xff, o >> 0x8 & 0xff, o & 0xff] }, g[i + k] = f; } else { j[k] = h ? a['get'](k) : a[k]; if (k == 'yaw' && Math['abs'](l - j[k]) > 0xb4) j[k] = j[k] + (l > j[k] ? 0x168 : -0x168);
                g[i + k] = f; } } } return f['set']('duration', (c || 0x0) * 0x3e8), f['set']('easing', d || 'cubic_in_out'), f['set']('animationDirection', e || 'normal'), f['bind']('end', function() { for (var p in j) { if (g[i + p] == f) delete g[i + p]; }
        this['disposeInstance'](f); }, this), f['bind']('frame', function() { var p = f['getPosition'](); for (var q in j) { var s = j[q]; if (g[i + q] != f) continue; if (typeof s === 'object' && 'color' in s) { var t = Math['round'](s['initialRGB'][0x0] + (s['finalRGB'][0x0] - s['initialRGB'][0x0]) * p),
                    u = Math['round'](s['initialRGB'][0x1] + (s['finalRGB'][0x1] - s['initialRGB'][0x1]) * p),
                    w = Math['round'](s['initialRGB'][0x2] + (s['finalRGB'][0x2] - s['initialRGB'][0x2]) * p);
                s = '#' + ((0x1 << 0x18) + (t << 0x10) + (u << 0x8) + w)['toString'](0x10)['slice'](0x1); } else s = s + (b[q] - s) * p; if (h) a['set'](q, s);
            else a[q] = s; } }, this), f; }, TDV['Tour']['Script']['executeFunctionWhenChange'] = function(a, b, c, d) { var e = undefined,
        f = function(j) { if (j['data']['previousSelectedIndex'] == b) { if (d) d['call'](this); if (c && e) e['unbind']('end', c, this);
                a['unbind']('change', f, this); } }; if (c) { var g = a['get']('items')[b],
            h = g['get']('class'); if (h == 'PanoramaPlayListItem' || h == 'Model3DPlayListItem') { var i = h == 'PanoramaPlayListItem' ? g['get']('camera') : g['get']('media')['get']('camera'); if (i != undefined) { e = i['get']('initialSequence'); if (e == undefined) e = i['get']('idleSequence'); } } else e = g['get']('media');
        e && e['bind']('end', c, this); }
    a['bind']('change', f, this); }, TDV['Tour']['Script']['executeJS'] = function(a) { try { eval(a); } catch (b) { console['log']('Javascript\x20error:\x20' + b), console['log']('\x20\x20\x20code:\x20' + a); } }, TDV['Tour']['Script']['fixTogglePlayPauseButton'] = function(a) { var b = a['get']('buttonPlayPause'); if (typeof b !== 'undefined' && a['get']('state') == 'playing') { if (!Array['isArray'](b)) b = [b]; for (var c = 0x0; c < b['length']; ++c) b[c]['set']('pressed', !![]); } }, TDV['Tour']['Script']['getActiveMediaWithViewer'] = function(a) { var b = this['getActivePlayerWithViewer'](a); if (b == undefined) return undefined; return this['getMediaFromPlayer'](b); }, TDV['Tour']['Script']['getActivePlayerWithViewer'] = function(a) { var b = this['getActivePlayersWithViewer'](a); return b['length'] > 0x1 && b['sort'](function(c, d) { var e = c['get']('class'),
            f = d['get']('class'); if (e == 'Model3DPlayer') return 0x1;
        else { if (f == 'Model3DPlayer') return -0x1;
            else return 0x0; } }), b['length'] > 0x0 ? b[0x0] : undefined; }, TDV['Tour']['Script']['getActivePlayersWithViewer'] = function(a) { var b = this['getCurrentPlayers'](),
        c = b['length'],
        d = []; while (c-- > 0x0) { var e = b[c]; if (e['get']('viewerArea') == a) { var f = e['get']('class'); if (f == 'PanoramaPlayer' && (e['get']('panorama') != undefined || e['get']('video') != undefined) || (f == 'VideoPlayer' || f == 'Video360Player') && e['get']('video') != undefined || f == 'PhotoAlbumPlayer' && e['get']('photoAlbum') != undefined || f == 'MapPlayer' && e['get']('map') != undefined || f == 'Model3DPlayer' && e['get']('model') != undefined) d['push'](e); } } return d; }, TDV['Tour']['Script']['getCurrentPlayerWithMedia'] = function(a) { var b = undefined,
        c = undefined; switch (a['get']('class')) {
        case 'Panorama':
        case 'LivePanorama':
        case 'HDRPanorama':
            b = 'PanoramaPlayer', c = 'panorama'; break;
        case 'Video360':
            b = 'PanoramaPlayer', c = 'video'; break;
        case 'PhotoAlbum':
            b = 'PhotoAlbumPlayer', c = 'photoAlbum'; break;
        case 'Map':
            b = 'MapPlayer', c = 'map'; break;
        case 'Video':
            b = 'VideoPlayer', c = 'video'; break;
        case 'Model3D':
            b = 'Model3DPlayer', c = 'media'; break; } if (b != undefined) { var d = this['getByClassName'](b); for (var e = 0x0; e < d['length']; ++e) { var f = d[e]; if (f['get'](c) == a) return f; } } else return undefined; }, TDV['Tour']['Script']['getCurrentPlayers'] = function() { var a = this['getByClassName']('PanoramaPlayer'); return a = a['concat'](this['getByClassName']('VideoPlayer')), a = a['concat'](this['getByClassName']('Video360Player')), a = a['concat'](this['getByClassName']('PhotoAlbumPlayer')), a = a['concat'](this['getByClassName']('MapPlayer')), a = a['concat'](this['getByClassName']('Model3DPlayer')), a; }, TDV['Tour']['Script']['getGlobalAudio'] = function(a) { var b = window['currentGlobalAudios']; return b != undefined && a['get']('id') in b && (a = b[a['get']('id')]['audio']), a; }, TDV['Tour']['Script']['getMediaByName'] = function(a) { var b = this['getByClassName']('Media'); for (var c = 0x0, d = b['length']; c < d; ++c) { var e = b[c],
            f = e['get']('data'); if (f && f['label'] == a) return e; } return undefined; }, TDV['Tour']['Script']['getMediaByTags'] = function(a, b) { return this['_getObjectsByTags'](a, ['Media'], 'tags2Media', b); }, TDV['Tour']['Script']['getAudioByTags'] = function(a, b) { return this['_getObjectsByTags'](a, ['Audio'], 'tags2Media', b); }, TDV['Tour']['Script']['getOverlaysByTags'] = function(a, b) { var c = this['_getObjectsByTags'](a, ['HotspotPanoramaOverlay', 'HotspotMapOverlay', 'VideoPanoramaOverlay', 'QuadVideoPanoramaOverlay', 'FramePanoramaOverlay', 'QuadFramePanoramaOverlay', 'SpriteModel3DObject', 'PanoramaModel3DLocation'], 'tags2Overlays', b); return c['flatMap'](d => { if (d['get']('class') == 'PanoramaModel3DLocation') { var e = d['get']('data')['object']; return [e]['concat'](e['get']('data')['panoramaOverlays']); } else return [d]; }); }, TDV['Tour']['Script']['getOverlaysByGroupname'] = function(a) { var b = this['get']('data'),
        c = 'groupname2Overlays',
        d = b[c]; if (!d) { var e = ['HotspotPanoramaOverlay', 'VideoPanoramaOverlay', 'QuadVideoPanoramaOverlay', 'FramePanoramaOverlay', 'QuadFramePanoramaOverlay'];
        b[c] = d = {}; for (var f = 0x0; f < e['length']; ++f) { var g = e[f],
                h = this['getByClassName'](g); for (var j = 0x0, k = h['length']; j < k; ++j) { var l = h[j],
                    m = l['get']('data'); if (m && m['group']) { var n = d[m['group']]; if (!n) d[m['group']] = n = [];
                    n['push'](l); } } } } return d[a] || []; }, TDV['Tour']['Script']['getRootOverlay'] = function(a) { var b = a['get']('class'),
        c = b['indexOf']('HotspotPanoramaOverlayArea') != -0x1,
        d = b['indexOf']('HotspotPanoramaOverlayImage') != -0x1; if (c || d) { var e = this['get']('data'),
            f = 'overlays',
            g = e[f]; if (!g) { var h = ['HotspotPanoramaOverlay'];
            g = []; for (var k = 0x0; k < h['length']; ++k) { var l = h[k];
                g = g['concat'](this['getByClassName'](l)); }
            e[f] = g; } var m = c ? 'areas' : 'items'; for (var n = 0x0, o = g['length']; n < o; ++n) { var p = g[n],
                q = p['get'](m); if (q)
                for (var r = 0x0; r < q['length']; ++r) { if (q[r] == a) return p; } } } return a; }, TDV['Tour']['Script']['initOverlayGroupRotationOnClick'] = function(a) { var b = this['getOverlaysByGroupname'](a); if (b['length'] > 0x1) { b['sort'](function(j, k) { var l = j['get']('data')['groupIndex'],
                m = k['get']('data')['groupIndex']; return l - m; }); for (var c = 0x0, d = b['length']; c < d; ++c) { var e = b[c],
                f = b[(c + 0x1) % d],
                g = e['get']('class'),
                h = e;
            g == 'HotspotPanoramaOverlay' && (h = e['get']('areas')[0x0]), h['bind']('click', function(j, k) { this['setOverlaysVisibility']([j], ![]), this['setOverlaysVisibility']([k], !![]); }['bind'](this, e, f), this); } } }, TDV['Tour']['Script']['getComponentsByTags'] = function(a, b) { return this['_getObjectsByTags'](a, ['UIComponent'], 'tags2Components', b); }, TDV['Tour']['Script']['_getObjectsByTags'] = function(a, b, c, d) { var e = this['get']('data'),
        f = e[c]; if (!f) { e[c] = f = {}; for (var g = 0x0; g < b['length']; ++g) { var h = b[g],
                k = this['getByClassName'](h); for (var l = 0x0, m = k['length']; l < m; ++l) { var n = k[l],
                    o = n['get']('data'); if (o && o['tags']) { var p = o['tags']; for (var q = 0x0, r = p['length']; q < r; ++q) { var s = p[q]; if (s in f) f[s]['push'](n);
                        else f[s] = [n]; } } } } } var t = undefined;
    d = d || 'and'; for (var l = 0x0, m = a['length']; l < m; ++l) { var u = f[a[l]]; if (!u) continue; if (!t) t = u['concat']();
        else { if (d == 'and')
                for (var q = t['length'] - 0x1; q >= 0x0; --q) { if (u['indexOf'](t[q]) == -0x1) t['splice'](q, 0x1); } else { if (d == 'or')
                        for (var q = u['length'] - 0x1; q >= 0x0; --q) { var n = u[q]; if (t['indexOf'](n) == -0x1) t['push'](n); } } } } return t || []; }, TDV['Tour']['Script']['getComponentByName'] = function(a) { var b = this['getByClassName']('UIComponent'); for (var c = 0x0, d = b['length']; c < d; ++c) { var e = b[c],
            f = e['get']('data'); if (f != undefined && f['name'] == a) return e; } return undefined; }, TDV['Tour']['Script']['getMainViewer'] = function() { var a = 'MainViewer'; return this[a] || this[a + '_mobile']; }, TDV['Tour']['Script']['getMediaFromPlayer'] = function(a) { switch (a['get']('class')) {
        case 'PanoramaPlayer':
            return a['get']('panorama') || a['get']('video');
        case 'VideoPlayer':
        case 'Video360Player':
            return a['get']('video');
        case 'PhotoAlbumPlayer':
            return a['get']('photoAlbum');
        case 'MapPlayer':
            return a['get']('map');
        case 'Model3DPlayer':
            return a['get']('model'); } }, TDV['Tour']['Script']['getMediaWidth'] = function(a) { switch (a['get']('class')) {
        case 'Video360':
            var b = a['get']('video'); if (b instanceof Array) { var c = 0x0; for (var d = 0x0; d < b['length']; d++) { var e = b[d]; if (e['get']('width') > c) c = e['get']('width'); } return c; } else return e['get']('width');
        default:
            return a['get']('width'); } }, TDV['Tour']['Script']['getMediaHeight'] = function(a) { switch (a['get']('class')) {
        case 'Video360':
            var b = a['get']('video'); if (b instanceof Array) { var c = 0x0; for (var d = 0x0; d < b['length']; d++) { var e = b[d]; if (e['get']('height') > c) c = e['get']('height'); } return c; } else return e['get']('height');
        default:
            return a['get']('height'); } }, TDV['Tour']['Script']['getOverlays'] = function(a) { switch (a['get']('class')) {
        case 'LivePanorama':
        case 'HDRPanorama':
        case 'Panorama':
            var b = a['get']('overlays')['concat']() || [],
                c = a['get']('frames'); for (var d = 0x0; d < c['length']; ++d) { b = b['concat'](c[d]['get']('overlays') || []); } return b;
        case 'Video360':
        case 'Map':
            return a['get']('overlays') || [];
        case 'Model3D':
            return a['get']('objects');
        default:
            return []; } }, TDV['Tour']['Script']['getPanoramaOverlayByName'] = function(a, b) { var c = this['getOverlays'](a); for (var d = 0x0, e = c['length']; d < e; ++d) { var f = c[d],
            g = f['get']('data'); if (g != undefined && g['label'] == b) return f; } return undefined; }, TDV['Tour']['Script']['getPanoramaOverlaysByTags'] = function(a, b, c) { var d = [],
        e = this['getOverlays'](a),
        f = this['getOverlaysByTags'](b, c); for (var g = 0x0, h = e['length']; g < h; ++g) { var j = e[g]; if (f['indexOf'](j) != -0x1) d['push'](j); } return d; }, TDV['Tour']['Script']['getPixels'] = function(a) { var b = /((\+|-)?d+(.d*)?)(px|vw|vh|vmin|vmax)?/i ['exec'](a); if (b == undefined) return 0x0; var c = parseFloat(b[0x1]),
        d = b[0x4],
        e = this['rootPlayer']['get']('actualWidth') / 0x64,
        f = this['rootPlayer']['get']('actualHeight') / 0x64; switch (d) {
        case 'vw':
            return c * e;
        case 'vh':
            return c * f;
        case 'vmin':
            return c * Math['min'](e, f);
        case 'vmax':
            return c * Math['max'](e, f);
        default:
            return c; } }, TDV['Tour']['Script']['getPlayListsWithMedia'] = function(a, b) { var c = [],
        d = this['getByClassName']('PlayList'); for (var e = 0x0, f = d['length']; e < f; ++e) { var g = d[e]; if (b && g['get']('selectedIndex') == -0x1) continue; var h = this['getPlayListItemByMedia'](g, a); if (h != undefined && h['get']('player') != undefined) c['push'](g); } return c; }, TDV['Tour']['Script']['_getPlayListsWithViewer'] = function(a) { var b = this['getByClassName']('PlayList'),
        c = function(e) { var f = e['get']('items'); for (var g = f['length'] - 0x1; g >= 0x0; --g) { var h = f[g],
                    k = h['get']('player'); if (k !== undefined && k['get']('viewerArea') == a) return !![]; } return ![]; }; for (var d = b['length'] - 0x1; d >= 0x0; --d) { if (!c(b[d])) b['splice'](d, 0x1); } return b; }, TDV['Tour']['Script']['getPlayListWithItem'] = function(a) { var b = this['getByClassName']('PlayList'); for (var c = b['length'] - 0x1; c >= 0x0; --c) { var d = b[c],
            e = d['get']('items'); for (var f = e['length'] - 0x1; f >= 0x0; --f) { var g = e[f]; if (g == a) return d; } } return undefined; }, TDV['Tour']['Script']['getFirstPlayListWithMedia'] = function(a, b) { var c = this['getPlayListsWithMedia'](a, b); return c['length'] > 0x0 ? c[0x0] : undefined; }, TDV['Tour']['Script']['getPlayListItemByMedia'] = function(a, b) { var c = a['get']('items'); for (var d = 0x0, e = c['length']; d < e; ++d) { var f = c[d]; if (f['get']('media') == b) return f; } return undefined; }, TDV['Tour']['Script']['getPlayListItemIndexByMedia'] = function(a, b) { var c = this['getPlayListItemByMedia'](a, b); return c ? a['get']('items')['indexOf'](c) : -0x1; };

function getPlayListItemClass(a) { switch (a['get']('class')) {
        case 'Panorama':
        case 'LivePanorama':
        case 'HDRPanorama':
            return 'PanoramaPlayListItem';
        case 'Map':
            return 'MapPlayListItem';
        case 'Model3D':
            return 'Model3DPlayListItem';
        case 'PhotoAlbum':
            return 'PhotoAlbumPlayListItem';
        case 'Video':
            return 'VideoPlayListItem';
        case 'Video360':
            return 'Video360PlayListItem'; } return null; }

function getPlayerClass(a) { switch (a['get']('class')) {
        case 'Panorama':
        case 'LivePanorama':
        case 'HDRPanorama':
            return 'PanoramaPlayer';
        case 'Map':
            return 'MapPlayer';
        case 'Model3D':
            return 'Model3DPlayer';
        case 'PhotoAlbum':
            return 'PhotoAlbumPlayer';
        case 'Video':
            return 'VideoPlayer';
        case 'Video360':
            return 'Video360Player'; } return null; }
TDV['Tour']['Script']['getPlayListItems'] = function(a, b) { var c = getPlayListItemClass(a); if (c !== undefined) { var d = this['getByClassName'](c); for (var e = d['length'] - 0x1; e >= 0x0; --e) { var f = d[e];
            (f['get']('media') != a || b != undefined && f['get']('player') != b) && d['splice'](e, 0x1); } return d; } else return []; }, TDV['Tour']['Script']['historyGoBack'] = function(a) { var b = this['get']('data')['history'][a['get']('id')];
    b != undefined && b['back'](); }, TDV['Tour']['Script']['historyGoForward'] = function(a) { var b = this['get']('data')['history'][a['get']('id')];
    b != undefined && b['forward'](); }, TDV['Tour']['Script']['init'] = function() { var a = this['get']('data')['history'],
        b = function(k) { var l = k['source'],
                m = l['get']('selectedIndex'); if (m < 0x0) return; var n = l['get']('id'); if (!a['hasOwnProperty'](n)) a[n] = new TDV['Tour']['HistoryData'](l);
            a[n]['add'](m); },
        c = this['getByClassName']('PlayList'); for (var d = 0x0, e = c['length']; d < e; ++d) { var f = c[d];
        f['bind']('change', b, this); } if (this['getMainViewer']()['get']('translationTransitionEnabled')) { var g = this['getByClassName']('ThumbnailList');
        g = g['concat'](this['getByClassName']('ThumbnailGrid')), g = g['concat'](this['getByClassName']('DropDown'));

        function k(l) { var m = l['source']['get']('playList'),
                n = m['get']('selectedIndex');
            n >= 0x0 && this['skip3DTransitionOnce'](m['get']('items')[n]['get']('player')); } for (var d = 0x0, h = g['length']; d < h; ++d) { var j = g[d];
            j['bind']('change', k, this); } }
    _initModels['call'](this); }, TDV['Tour']['Script']['sendAnalyticsData'] = function(a, b, c) { window['dataLayer'] && window['dataLayer']['push']({ 'event': b, 'label': c, 'category': a }); if (!this['get']('data')['tour']['player']['cookiesEnabled']) return;
    window['ga'] && window['ga']('send', 'event', a, b, c), window['gtag'] && window['gtag']('event', b, { 'category': a, 'label': c }); }, TDV['Tour']['Script']['initAnalytics'] = function() { var a = this['getByClassName']('Panorama');
    a = a['concat'](this['getByClassName']('Video360')), a = a['concat'](this['getByClassName']('Map')), a = a['concat'](this['getByClassName']('Model3D')); for (var b = 0x0, d = a['length']; b < d; ++b) { var e = a[b],
            f = e['get']('data'),
            g = f ? f['label'] : '',
            h = this['getOverlays'](e); for (var k = 0x0, l = h['length']; k < l; ++k) { var n = h[k],
                o = n['get']('data') != undefined ? g + '\x20-\x20' + n['get']('data')['label'] : g; switch (n['get']('class')) {
                case 'FlatHotspotPanoramaOverlay':
                case 'HotspotPanoramaOverlay':
                case 'HotspotMapOverlay':
                case 'AreaHotspotMapOverlay':
                    var p = n['get']('areas'); for (var q = 0x0; q < p['length']; ++q) { p[q]['bind']('click', this['sendAnalyticsData']['bind'](this, 'Hotspot', 'click', o), this, ![]); } break;
                case 'CeilingCapPanoramaOverlay':
                case 'TripodCapPanoramaOverlay':
                    n['bind']('click', this['sendAnalyticsData']['bind'](this, 'Cap', 'click', o), this, ![]); break;
                case 'QuadVideoPanoramaOverlay':
                case 'VideoPanoramaOverlay':
                    n['bind']('click', this['sendAnalyticsData']['bind'](this, 'Hotspot', 'click', o), this, ![]), n['bind']('start', this['sendAnalyticsData']['bind'](this, 'Hotspot', 'start', o), this, ![]); break;
                case 'QuadFramePanoramaOverlay':
                case 'FramePanoramaOverlay':
                case 'SpriteModel3DObject':
                    n['bind']('click', this['sendAnalyticsData']['bind'](this, 'Hotspot', 'click', o), this, ![]); break; } } } var r = this['getByClassName']('UIComponent'); for (var b = 0x0, d = r['length']; b < d; ++b) { var s = r[b],
            t = s['getBindings']('click'); if (t['length'] > 0x0) { var f = s['get']('data'); if (f === undefined) continue; var u = f['name'];
            s['bind']('click', this['sendAnalyticsData']['bind'](this, 'Skin', 'click', u), this, ![]); } } var v = this['mainPlayList']['get']('items')['concat'](this['getByClassName']('PlayListItem')),
        w = {}; for (var b = 0x0, d = v['length']; b < d; ++b) { var x = v[b],
            a = x['get']('media'); if (!(a['get']('id') in w)) { var f = a['get']('data');
            x['bind']('begin', this['sendAnalyticsData']['bind'](this, 'Media', 'play', f ? f['label'] : undefined), this, ![]), w[a['get']('id')] = x; } } if (TDV['Remote'] != undefined) { var y = undefined;
        TDV['Remote']['bind'](TDV['Remote']['EVENT_CALL_BEGIN'], function(A) { y = Date['now'](), this['sendAnalyticsData']('Live\x20Guided\x20Tour', 'Start\x20Call', 'Guest:\x20' + A); }['bind'](this)), TDV['Remote']['bind'](TDV['Remote']['EVENT_CALL_END'], function(A) { var B = new Date();
            B['setTime'](Date['now']() - y), this['sendAnalyticsData']('Live\x20Guided\x20Tour', 'End\x20Call', 'Guest:\x20' + A + '\x20Duration:\x20' + B['toUTCString']()['split']('\x20')[0x4]); }['bind'](this)); } }, TDV['Tour']['Script']['initQuiz'] = function(a, b, c) { var d = { "score": { "veil": { "backgroundColor": "#000000", "backgroundOpacity": 0.3 }, "window": { "shadow": true, "paddingBottom": 20, "backgroundColor": "#ffffff", "content": { "width": "100%", "horizontalAlign": "center" }, "shadowSpread": 4, "shadowColor": "#000000", "shadowVerticalLength": 0, "paddingRight": 20, "stats": { "height": 150, "label": { "fontColor": "#000000", "fontWeight": "normal", "fontFamily": "Arial", "fontSize": 15 }, "borderSize": 1, "layout": "vertical", "borderColor": "#009fe3", "verticalAlign": "middle", "horizontalAlign": "center", "mainValue": { "fontColor": "#000000", "fontWeight": "bold", "fontFamily": "Arial", "fontSize": 40 }, "minWidth": 150, "gap": 0, "title": { "fontColor": "#000000", "fontWeight": "normal", "paddingRight": 5, "paddingLeft": 5, "fontFamily": "Arial", "fontSize": 20, "paddingTop": 10 }, "borderRadius": 75, "secondaryValue": { "fontColor": "#000000", "fontWeight": "bold", "fontFamily": "Arial", "fontSize": 20, "paddingLeft": 5 } }, "horizontalAlign": "center", "paddingTop": 20, "buttonsContainer": { "width": "100%", "paddingLeft": 100, "verticalAlign": "middle", "paddingBottom": 50, "button": { "backgroundColor": "#009fe3", "fontWeight": "bold", "paddingRight": 25, "paddingLeft": 25, "verticalAlign": "middle", "paddingBottom": 12, "fontColor": "#ffffff", "fontFamily": "Arial", "fontSize": 15, "horizontalAlign": "center", "paddingTop": 12 }, "paddingRight": 100, "gap": 8, "horizontalAlign": "center", "paddingTop": 35 }, "minWidth": 500, "shadowHorizontalLength": 0, "calification": { "fontColor": "#009fe3", "fontWeight": "bold", "paddingRight": 100, "fontSize": 30, "width": "100%", "paddingBottom": 10, "textAlign": "center", "fontFamily": "Arial", "paddingLeft": 100, "verticalAlign": "middle", "paddingTop": 15 }, "title": { "fontColor": "#000000", "fontWeight": "bold", "paddingBottom": 15, "textAlign": "center", "fontFamily": "Arial", "fontSize": 50, "paddingTop": 50 }, "description": { "fontColor": "#000000", "fontWeight": "normal", "paddingRight": 100, "paddingLeft": 100, "paddingBottom": 15, "textAlign": "center", "fontFamily": "Arial", "fontSize": 16, "paddingTop": 15 }, "shadowBlurRadius": 4, "timeContainer": { "width": "100%", "gap": 5, "verticalAlign": "middle", "paddingBottom": 15, "paddingRight": 100, "paddingLeft": 100, "horizontalAlign": "center", "paddingTop": 10 }, "shadowOpacity": 0.3, "closeButton": { "iconLineWidth": 2, "backgroundColor": "#009fe3", "iconHeight": 18, "iconWidth": 18, "height": 45, "iconColor": "#ffffff", "width": 45 }, "paddingLeft": 20, "statsContainer": { "gap": 20, "overflow": "scroll", "contentOpaque": true, "verticalAlign": "middle", "paddingBottom": 15, "paddingRight": 100, "paddingLeft": 100, "horizontalAlign": "center", "paddingTop": 15 }, "maxWidth": 1500 } }, "timeout": { "veil": { "backgroundColor": "#000000", "backgroundOpacity": 0.3 }, "window": { "shadow": true, "shadowHorizontalLength": 0, "backgroundColor": "#ffffff", "button": { "backgroundColor": "#009fe3", "fontWeight": "bold", "paddingRight": 25, "paddingLeft": 25, "verticalAlign": "middle", "paddingBottom": 12, "fontColor": "#ffffff", "fontFamily": "Arial", "fontSize": 15, "horizontalAlign": "center", "paddingTop": 12 }, "shadowSpread": 4, "paddingBottom": 55, "paddingRight": 80, "gap": 15, "horizontalAlign": "center", "paddingTop": 45, "icon": { "height": 72, "url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAABGCAYAAAB/h5zrAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABhRJREFUeNrsW41y2jgQliVjGxMuhDR37/92l2uvhVIcjGtzuLO6aBRpdyVb9G4azWiABKH99n9XcibSj9V13geu6a7z7+scUhAkbwB6GbFmAVP8X0H/58Y76HfQ76DfQYeOLmLNGKq+pyIouxFzS3jNkZg9MucrvB8B96mIyW8EumV858L8XlLQC5DKqGqHSDX9WeMe6G+BdpZ6jwseDZsfIC0MBa6M7KqEzwr5/hlUu4P3MYzeXGdtfG6uc0eBtgGLQOAjqAo2nppKjnuejBkK2Ak8YwI2ifgTcVYrAJxi9ED80VOIrGH6xr/A8wDAvhBXwmZFYjtVsM8KgB8cAsOG1oCdCgCsw0pjMOAeprqhk8qA0bUV2jKGlo04lQLin5iJioJNxu9+uIF0qcSqhtcugPmLDNA//UppaA5c6lIW7RB+WtjHlYQooCUHOqqUKXJmqMrjzMA7cDinyLZPCV2XembMu8yykTmAn8GztjPa7grmVOmPIavJHBvontYooW0AEwYoGJqEIesh0HnuwPEWgKcTDm93MWz8An+rmNL9BK+pxgUYOjBp6g3QZ9PEFMHZLaP8HAn5bDApRHJ5hL13ILUlQZs0BPJmY994ZJSee1cVwxg1xPkV0HAKXD+Az6CAly5HKhGiCoaEj4wMSCIpofB4ZwkES0LinAOBe66kt8SGI/e+EJs9Qa5cA4FmJ6QytGgk+ptF0++gBePaF8R0BvjtmpFFdhjomviRnmHDo5TujFxAAvFmJ0UazsaU1p3hqDLY50zQY7akfBp3xDona0YYGBg2R33eIZHABQobB2DUApF2rcOpLekK1GqKHWtQujBpIX5zvXtvrD0ExP2OoF3q38oRB+PjKHc0ExKVmLW67PVhKLR9K4sTG4KQF8//1mCLF5GmXy3h97cgzbPHxHpC2j8cmrQ4gQ2fWq8AdAVEqZnBrsGbr+GzEnjvHOvhLW31LikOIZ7aLlf7GcDGFhlHRGMLG3RBxGVM7Ssmp+cAO0Am6BtUdVfmzMZaSzDk2WhIxNTOykhkqMLmM7FHTzRF8pyRgwtG9dQHqPRoDr8ZRPVMP7BnhkvBBZ0TMXeuCy+1w94UA8Au0GwwASw4B3jfGeUhR60lSNjWjoJwSntPo0MKf+MfZRBH0lg+q3vl48Z/EcALq8b9hEhf5+StpxgqjAzyo6fhQBbaMb2nylrPabS7HGPjcIwfEedZMJ0vCTrGZvsQlbL+X3pSX453PgY4WFS9Y1LHBkq/JdTDFGidOkqQ1h8Om+bk23tDC3z5Q8YBHfudY0AY0d3SjeEElaNg4IxTgClFSVoazmrq0N1M+9zpGNlrw6KK18xyZqG+EPM17/UBuz48THGtA5P0kDOzmIoAvQHn1CIdkSlZnB3ajkj+LQnQZ8n0hBVBTG20ZGqRZtRWORtD649wKZlFhUK4l4V4zgljQHpu3O5PZyclVMzzcffFsMsO6a5MHQfwBWfEhBSR1jYuqWwJ9XgWCW/yzTA2hKSf7R6ZzlmXRPjiHsHovtYCGBVy1lVBcZJDOOWsXQi8x3fWOUXuCCdYfatPHDjhyzzrLiG95MbYrQFeMSMC9ZxII5BC48BQIcnkPOZR9QMtFZEBcrLGFWHLPQW6IexWWXUxp9vSeACvxNsOamslLN8YzKWkfOCkaxfCoS0YHv8E9nhyaE9lVVqtxehGvF7j6Bg1fUaEqT0HdCdeL7BivS6sNWzeanDF9tqIuQeHs6Kcn76OQan/m1I1I36Uc6kOSwkphxXbQeXecDy4fBQmyYvg3e8ojIIkJCxdIkKZjiAPgnel80toCaYXSkEf+eTi9a5mqmcvJIC9Y6S6A/TgLjGgtZNRjH6U7qKUERUUJ8l5YPbE9L30XsS0VQJTPFfIakT8jcEF7LcU/MYl6yJ+aEUUCtwMX/oRBd+TOKVRMJQi/PST/chFTBlI3aD/GaOD0MQyqZiz5DPMStzuuS4qZO5CTCib6GA2It0zG5x2016EX7ybRVK3eobDtF3deo7q0M6pnqnBTwabsp+lxOsFODUDUDP0zTJSOyIFGqCfwssFfd+zN8Jbkmcv/xFgALaVsLLFsFFBAAAAAElFTkSuQmCC", "width": 62 }, "buttonsContainer": { "gap": 10, "width": "100%", "horizontalAlign": "center" }, "shadowColor": "#000000", "shadowOpacity": 0.3, "shadowVerticalLength": 0, "title": { "fontColor": "#000000", "fontWeight": "bold", "paddingBottom": 20, "textAlign": "center", "fontFamily": "Arial", "fontSize": 40 }, "shadowBlurRadius": 4, "paddingLeft": 80 } }, "question": { "veil": { "backgroundColor": "#000000", "backgroundOpacity": 0.3 }, "window": { "borderRadius": 5, "bodyContainer": { "height": "100%", "gap": 35, "paddingBottom": 30, "layout": "horizontal", "paddingRight": 30, "paddingLeft": 30, "width": "100%" }, "shadowSpread": 4, "shadowColor": "#000000", "paddingRight": 20, "option": { "text": { "fontColor": "#404040", "textAlign": "left", "selected": { "fontColor": "#000000", "textAlign": "left", "fontFamily": "Arial", "fontSize": 18, "paddingTop": 9 }, "verticalAlign": "middle", "fontFamily": "Arial", "fontSize": 18, "paddingTop": 9 }, "gap": 10, "label": { "backgroundColor": "#000000", "pressedBackgroundOpacity": 1, "fontColor": "#ffffff", "height": 38, "incorrect": { "backgroundColor": "#ed1c24", "pressedBackgroundOpacity": 1, "fontColor": "#ffffff", "height": 38, "verticalAlign": "middle", "horizontalAlign": "center", "fontWeight": "bold", "fontSize": 18, "borderRadius": 19, "fontFamily": "Arial", "width": 38, "backgroundOpacity": 1 }, "verticalAlign": "middle", "horizontalAlign": "center", "fontWeight": "bold", "correct": { "backgroundColor": "#39b54a", "pressedBackgroundOpacity": 1, "fontColor": "#ffffff", "height": 38, "verticalAlign": "middle", "horizontalAlign": "center", "fontWeight": "bold", "fontSize": 18, "borderRadius": 19, "fontFamily": "Arial", "width": 38, "backgroundOpacity": 1 }, "fontSize": 18, "borderRadius": 19, "fontFamily": "Arial", "width": 38, "backgroundOpacity": 0.2 } }, "horizontalAlign": "center", "minWidth": 500, "shadowHorizontalLength": 0, "title": { "fontColor": "#000000", "fontWeight": "bold", "paddingRight": 50, "paddingLeft": 50, "paddingBottom": 40, "textAlign": "center", "fontFamily": "Arial", "fontSize": 20, "paddingTop": 25 }, "optionsContainer": { "contentOpaque": true, "height": "100%", "gap": 10, "width": "30%", "overflow": "scroll" }, "width": "60%", "paddingBottom": 20, "shadow": true, "height": "60%", "mediaContainer": { "buttonNext": { "height": 37, "iconURL": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAlCAMAAACAj7KHAAAAA3NCSVQICAjb4U/gAAAAS1BMVEX///8AAAAAAAAAAAAAAACVlZWLi4uDg4MAAAC8vLx8fHx5eXl2dnZ0dHRxcXHDw8PAwMBra2tjY2PY2NiLi4v7+/v5+fn////7+/sWSBTRAAAAGXRSTlMAESIzRFVVVVVmZmZmZmZ3d3d3mZnu7v//nfgMagAAAAlwSFlzAAAK6wAACusBgosNWgAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAAWdEVYdENyZWF0aW9uIFRpbWUAMDYvMjkvMTUTtAt+AAAAjElEQVQokbXTyRaAIAgFUJHmeTL7/y9Naie+Toti2T0R4suYH4qI0HNKGpGV0iYwuoLFlEzeu0YT2dqH2jtFZHN3UR9T6FamKQi3O6Q+STL2O4r6WR4QcTZfdIQjR6NzttxUaKk2Eb/qdql34HfgbPA8eAdwb3jXD/eD7xTnAGcH5g1n9CHXBv8Ln9UJhXMPrAhUbYMAAAAASUVORK5CYII=", "width": 25 }, "height": "100%", "buttonPrevious": { "height": 37, "iconURL": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAlCAMAAACAj7KHAAAAA3NCSVQICAjb4U/gAAAAS1BMVEX///8AAAAAAAAAAAAAAACVlZWLi4uDg4MAAAC8vLx8fHx5eXl2dnZ0dHRxcXHDw8PAwMBra2tjY2PY2NiLi4v7+/v5+fn////7+/sWSBTRAAAAGXRSTlMAESIzRFVVVVVmZmZmZmZ3d3d3mZnu7v//nfgMagAAAAlwSFlzAAAK6wAACusBgosNWgAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAAWdEVYdENyZWF0aW9uIFRpbWUAMDYvMjkvMTUTtAt+AAAAkElEQVQokbXSyRaDIAwFUALOQ7W2iP//pQK6CGheF55mmXuYwlPqn0VEUp/uzPd0qAuFvqnsdKEInXVuziTCsDpfraYcxgi25MKh5rsxWHvDhMMIIJWf8EpAeei2CO/CJK8kXR2w5ED6E8B9m0zkNegc8W7ye8AM5LmBWYP/AX8KcgCyA/IGMqrkXJ92239aO3W4D6yL2ECSAAAAAElFTkSuQmCC", "width": 25 }, "width": "70%", "viewerArea": { "playbackBarHeadBackgroundColor": "#cccccc", "backgroundOpacity": 1, "playbackBarProgressBackgroundColor": "#3399ff", "playbackBarHeadBorderRadius": 7, "playbackBarBottom": 5, "playbackBarProgressOpacity": 0.5, "playbackBarLeft": 0, "playbackBarHeadShadowOpacity": 0.3, "playbackBarHeadBorderColor": "#ffffff", "playbackBarHeadHeight": 14, "playbackBarHeadShadowColor": "#000000", "playbackBarHeadShadowVerticalLength": 0, "playbackBarBorderSize": 0, "playbackBarBackgroundColor": "#000000", "playbackBarHeadShadowSpread": 2, "playbackBarHeadShadowHorizontalLength": 0, "playbackBarHeight": 6, "backgroundColor": "#e6e6e6", "playbackBarHeadBorderSize": 3, "playbackBarHeadOpacity": 1, "playbackBarHeadWidth": 14, "playbackBarHeadShadow": true, "playbackBarBorderRadius": 0, "playbackBarBackgroundOpacity": 0.5, "playbackBarHeadShadowBlurRadius": 2, "playbackBarRight": 0 } }, "backgroundColor": "#ffffff", "shadowVerticalLength": 0, "paddingTop": 20, "buttonsContainer": { "button": { "borderRadius": 3, "backgroundColor": "#000000", "fontSize": 18, "fontColor": "#ffffff", "paddingRight": 25, "verticalAlign": "middle", "horizontalAlign": "center", "paddingTop": 10, "fontWeight": "bold", "paddingBottom": 10, "fontFamily": "Arial", "paddingLeft": 25, "backgroundOpacity": 0.7 }, "verticalAlign": "bottom", "horizontalAlign": "right" }, "shadowOpacity": 0.3, "closeButton": { "iconLineWidth": 2, "backgroundColor": "#009FE3", "iconHeight": 18, "iconWidth": 18, "height": 45, "iconColor": "#FFFFFF", "width": 45 }, "shadowBlurRadius": 4, "paddingLeft": 20, "backgroundOpacity": 1 } } },
        e = this['get']('data'),
        f = e['createQuizConfig']['call'](this);
    r['call'](this, f), f['playList'] = a, f['player'] = this, f['theme'] = 'theme' in f ? this['mixObject'](d, f['theme']) : d; if (f['questions']) { q['call'](this, f['questions']); for (var g = 0x0; g < f['questions']['length']; ++g) { var h = f['questions'][g];
            q['call'](this, h['options']); } }
    f['objectives'] && q['call'](this, f['objectives']);
    f['califications'] && q['call'](this, f['califications']);
    f['score'] && (this[f['score']['id']] = f['score']);
    f['question'] && (this[f['question']['id']] = f['question']);
    f['timeout'] && (this[f['timeout']['id']] = f['timeout']); var j = f['data'] && f['data']['titlesScale'] ? f['data']['titlesScale'] : 0x1,
        k = f['data'] && f['data']['bodyScale'] ? f['data']['bodyScale'] : 0x1; if (this['get']('isMobile') && !this['get']('data')['tour']['isIPad']() && !this['get']('data')['tour']['isVRDevice']()) { var l = this['mixObject'](f['theme'], { 'question': { 'window': { 'width': '100%', 'height': '100%', 'minWidth': undefined, 'backgroundOpacity': 0x1, 'borderRadius': 0x0, 'paddingLeft': 0x0, 'paddingRight': 0x0, 'paddingBottom': 0x0, 'paddingTop': 0x0, 'verticalAlign': 'middle', 'title': { 'paddingBottom': 0x19, 'paddingTop': 0x19 }, 'bodyContainer': { 'layout': 'vertical', 'horizontalAlign': 'center', 'paddingLeft': 0x0, 'paddingRight': 0x0, 'gap': 0x14 }, 'mediaContainer': { 'width': '100%', 'height': '45%' }, 'optionsContainer': { 'width': '100%', 'height': '55%', 'paddingLeft': 0x14, 'paddingRight': 0x14 } } }, 'score': { 'window': { 'description': { 'paddingLeft': 0xa, 'paddingRight': 0xa }, 'calification': { 'fontSize': 0x14 * k, 'paddingLeft': 0xa, 'paddingRight': 0xa } } } });
        f['theme'] = l; } var m = document['getElementById']('metaViewport'),
        n = m ? /initial-scale=(\d+(\.\d+)?)/ ['exec'](m['getAttribute']('content')) : undefined,
        o = n ? n[0x1] : 0x1;
    e['scorePortraitConfig'] = { 'theme': { 'window': { 'minWidth': 0xfa / o, 'maxHeight': 0x258 / o, 'content': { 'height': '100%' }, 'statsContainer': { 'layout': 'vertical', 'horizontalAlign': 'center', 'maxHeight': 0x258, 'paddingLeft': 0x0, 'paddingRight': 0x0, 'width': '100%', 'height': '100%' }, 'buttonsContainer': { 'paddingLeft': 0xa, 'paddingRight': 0xa, 'button': { 'paddingLeft': 0xf, 'paddingRight': 0xf } } } } }, e['scoreLandscapeConfig'] = { 'theme': { 'window': { 'title': { 'fontSize': 0x1e * j, 'paddingTop': 0xa }, 'stats': { 'height': 0x64 }, 'buttonsContainer': { 'paddingBottom': 0x14, 'paddingTop': 0xa }, 'description': { 'paddingBottom': 0x5, 'paddingTop': 0x5 } } } }; var p = new TDV['Quiz'](f);
    p['setMaxListeners'](0x32);
    c === !![] && p['bind'](TDV['Quiz']['EVENT_PROPERTIES_CHANGE'], function() { if ((p['get'](TDV['Quiz']['PROPERTY']['QUESTIONS_ANSWERED']) + p['get'](TDV['Quiz']['PROPERTY']['ITEMS_FOUND'])) / (p['get'](TDV['Quiz']['PROPERTY']['QUESTION_COUNT']) + p['get'](TDV['Quiz']['PROPERTY']['ITEM_COUNT'])) == 0x1) setTimeout(function() { p['finish'](); }, 0x0); }['bind'](this));
    b === !![] && p['start']();
    e['quiz'] = p, e['quizConfig'] = f;

    function q(s) { for (var t = 0x0; t < s['length']; ++t) { var u = s[t]; if ('id' in u) this[u['id']] = u; } }

    function r(s) { for (var t in s) { var u = s[t]; if (typeof u == 'object' && u !== null) r['call'](this, u);
            else { if (typeof u == 'string' && u['startsWith']('this.')) s[t] = _getObject(this, u); } } } }, TDV['Tour']['Script']['getQuizTotalObjectiveProperty'] = function(a) { var b = this['get']('data')['quiz'],
        c = this['get']('data')['quizConfig'],
        d = c['objectives'],
        e = 0x0; for (var f = 0x0, g = d['length']; f < g; ++f) { var h = d[f];
        e += b['getObjective'](h['id'], a); } return e; }, TDV['Tour']['Script']['_initSplitViewer'] = function(a) {
    function b() { var y = a['get']('actualWidth');
        n['get']('children')[0x0]['set']('width', y), o['get']('children')[0x0]['set']('width', y); var z = r['get']('left'),
            A = typeof z == 'string' ? c(z) : z;
        A += r['get']('actualWidth') * 0.5, n['set']('width', d(A)), o['set']('width', d(y - A)); }

    function c(y) { return parseFloat(y['replace']('%', '')) / 0x64 * a['get']('actualWidth'); }

    function d(y) { return y / a['get']('actualWidth') * 0x64 + '%'; }

    function e(y) { f(y['source']); }

    function f(y) { var z = y == t ? s : t; if (u && y != u || !y || !z) return; var A = y['get']('class'),
            B = z['get']('class'); if (A == 'PanoramaPlayer' && B == 'PanoramaPlayer') { var C = y['get']('camera')['get']('initialPosition'),
                D = z['get']('camera')['get']('initialPosition'); if (window['currentPanoramasWithCameraChanged']) { var E = window['currentPanoramasWithCameraChanged'][y['get']('panorama')['get']('id')];
                E && (C = E[0x0]['camera']['get']('initialPosition')); var F = window['currentPanoramasWithCameraChanged'][z['get']('panorama')['get']('id')];
                F && (D = F[0x0]['camera']['get']('initialPosition')); } var G = D['get']('yaw') - C['get']('yaw');
            z['setPosition'](y['get']('yaw') + G, y['get']('pitch'), y['get']('roll'), y['get']('hfov')); } else { if (A == 'Model3DPlayer' && B == 'Model3DPlayer') { var H = y['get']('model')['get']('camera'),
                    I = z['get']('model')['get']('camera'),
                    J = ['yaw', 'pitch', 'x', 'y', 'z', 'fov', 'easing'],
                    K = {}; if (H['get']('class') == 'OrbitModel3DCamera' && I['get']('class') == 'OrbitModel3DCamera' || H['get']('class') == 'FlyOverModel3DCamera' && I['get']('class') == 'FlyOverModel3DCamera') J['push']('distance');
                J['forEach'](L => { K[L] = H['get'](L); }), I['setPosition'](K); } } }

    function g(y) { u = y['source']; }

    function h(y) { k['call'](this, y['source']); }

    function i(y) { var z = y['get']('viewerArea'); if (z == p) s && s['get']('class') == 'PanoramaPlayer' && s['get']('camera')['set']('hoverFactor', v), s = y, u = s, s && s['get']('class') == 'PanoramaPlayer' && (v = s['get']('camera')['get']('hoverFactor'), s['get']('camera')['set']('hoverFactor', 0x0));
        else z == q && (t && t['get']('class') == 'PanoramaPlayer' && t['get']('camera')['set']('hoverFactor', w), t = y, u = t, t && t['get']('class') == 'PanoramaPlayer' && (w = t['get']('camera')['get']('hoverFactor'), t['get']('camera')['set']('hoverFactor', 0x0)));
        f(y); }

    function j(y) { var z = this['getCurrentPlayers'](),
            A = z['length']; while (A-- > 0x0) { var B = z[A];
            B['get']('viewerArea') != y && z['splice'](A, 0x1); } for (A = 0x0; A < z['length']; ++A) { var B = z[A];
            B['bind']('preloadMediaShow', h, this), B['get']('class') == 'PanoramaPlayer' && (B['bind']('cameraPositionChange', e, this), B['bind']('userInteractionStart', g, this)), k['call'](this, B); } return z; }

    function k(y) { var z = x['find'](B => { return B['player'] == y; });
        z && (z['media']['get']('class') == 'Model3D' && (z['media']['get']('camera')['unbind']('positionSet', z['updateFn'], this), z['media']['get']('camera')['unbind']('userInteractionStart', z['userInteractionStartFn'], this)), x['splice'](x['indexOf'](z), 0x1)); var A = this['getMediaFromPlayer'](y); if (!A) return;
        z = { 'media': A, 'player': y, 'updateFn': () => { f(y); }, 'userInteractionStartFn' () { u = y; } }, x['push'](z), z['media']['get']('class') == 'Model3D' && (z['media']['get']('camera')['bind']('positionSet', z['updateFn'], this), z['media']['get']('camera')['bind']('userInteractionStart', z['userInteractionStartFn'], this)), i(y); }

    function l(y) { i(this['getActivePlayerWithViewer'](y['source'])), f(u); } var m = a['get']('children'),
        n = m[0x0],
        o = m[0x1],
        p = n['get']('children')[0x0],
        q = o['get']('children')[0x0],
        r = m[0x2],
        s, t, u, v, w, x = [];
    j['call'](this, p), j['call'](this, q), this['bind']('instanceCreation', y => { var z = y['data']['instance'],
            A = z['get']('class');
        (A == 'PanoramaPlayer' || A == 'Model3DPlayer') && (z['bind']('preloadMediaShow', h, this), z['bind']('cameraPositionChange', e, this), z['bind']('userInteractionStart', g, this), k['call'](this, z)); }, this), p['bind']('mouseDown', l, this), q['bind']('mouseDown', l, this), a['bind']('resize', function() { r['set']('left', (a['get']('actualWidth') - r['get']('actualWidth')) * 0.5), b(); }, this), r['bind']('mouseDown', function(y) { var z = y['pageX'],
            A = function(B) { var C = B['pageX'],
                    D = z - C,
                    E = a['get']('actualWidth'),
                    F = r['get']('left'),
                    G = (typeof F == 'string' ? c(F) : F) - D; if (G < 0x0) C -= G, G = 0x0;
                else G + r['get']('actualWidth') >= E && (C -= G - (E - r['get']('actualWidth')), G = E - r['get']('actualWidth'));
                r['set']('left', G), b(), z = C; };
        this['bind']('mouseMove', A, this), this['bind']('mouseUp', function() { this['unbind']('mouseMove', A, this); }, this); }, this), b(); }, TDV['Tour']['Script']['_initTwinsViewer'] = function(a) {
    function b() { var z = a['get']('actualWidth');
        o['get']('children')[0x0]['set']('width', z), p['get']('children')[0x0]['set']('width', z); var A = s['get']('left'),
            B = typeof A == 'string' ? c(A) : A;
        B += s['get']('actualWidth') * 0.5, o['set']('width', d(B)), p['set']('width', d(z - B)); }

    function c(z) { return parseFloat(z['replace']('%', '')) / 0x64 * a['get']('actualWidth'); }

    function d(z) { return z / a['get']('actualWidth') * 0x64 + '%'; }

    function e(z) { f(z['source']); }

    function f(z) { var A = z == u ? t : u; if (v && z != v || !z || !A) return; var B = z['get']('class'),
            C = A['get']('class'); if (B == 'PanoramaPlayer' && C == 'PanoramaPlayer') { var D = z['get']('camera')['get']('initialPosition'),
                E = A['get']('camera')['get']('initialPosition'); if (window['currentPanoramasWithCameraChanged']) { var F = window['currentPanoramasWithCameraChanged'][z['get']('panorama')['get']('id')];
                F && (D = F[0x0]['camera']['get']('initialPosition')); var G = window['currentPanoramasWithCameraChanged'][A['get']('panorama')['get']('id')];
                G && (E = G[0x0]['camera']['get']('initialPosition')); } var H = E['get']('yaw') - D['get']('yaw');
            A['setPosition'](z['get']('yaw') + H, z['get']('pitch'), z['get']('roll'), z['get']('hfov')); } else { if (B == 'Model3DPlayer' && C == 'Model3DPlayer') { var I = z['get']('model')['get']('camera'),
                    J = A['get']('model')['get']('camera'),
                    K = ['yaw', 'pitch', 'x', 'y', 'z', 'fov', 'easing'],
                    L = {}; if (I['get']('class') == 'OrbitModel3DCamera' && J['get']('class') == 'OrbitModel3DCamera' || I['get']('class') == 'FlyOverModel3DCamera' && J['get']('class') == 'FlyOverModel3DCamera') K['push']('distance');
                K['forEach'](M => { L[M] = I['get'](M); }), J['setPosition'](L); } } }

    function g(z) { v = z['source']; }

    function h(z) { v = t; }

    function i(z) { l['call'](this, z['source']); }

    function j(z) { var A = z['get']('viewerArea'); if (A == q) t && t['get']('class') == 'PanoramaPlayer' && t['get']('camera')['set']('hoverFactor', w), t = z, v = t, t && t['get']('class') == 'PanoramaPlayer' && (w = t['get']('camera')['get']('hoverFactor'), t['get']('camera')['set']('hoverFactor', 0x0));
        else A == r && (u && u['get']('class') == 'PanoramaPlayer' && u['get']('camera')['set']('hoverFactor', x), u = z, v = u, u && u['get']('class') == 'PanoramaPlayer' && (x = u['get']('camera')['get']('hoverFactor'), u['get']('camera')['set']('hoverFactor', 0x0)));
        f(z); }

    function k(z) { var A = this['getCurrentPlayers'](),
            B = A['length']; while (B-- > 0x0) { var C = A[B];
            C['get']('viewerArea') != z && A['splice'](B, 0x1); } for (B = 0x0; B < A['length']; ++B) { var C = A[B];
            C['bind']('preloadMediaShow', i, this), C['get']('class') == 'PanoramaPlayer' && (C['bind']('cameraPositionChange', e, this), C['bind']('userInteractionStart', g, this), C['bind']('userInteractionEnd', h, this)), l['call'](this, C); } return A; }

    function l(z) { var A = y['find'](C => { return C['player'] == z; });
        A && (A['media']['get']('class') == 'Model3D' && (A['media']['get']('camera')['unbind']('positionSet', A['updateFn'], this), A['media']['get']('camera')['unbind']('userInteractionStart', A['userInteractionStartFn'], this)), y['splice'](y['indexOf'](A), 0x1)); var B = this['getMediaFromPlayer'](z); if (!B) return;
        A = { 'media': B, 'player': z, 'updateFn': () => { f(z); }, 'userInteractionStartFn' () { v = z; } }, y['push'](A), A['media']['get']('class') == 'Model3D' && (A['media']['get']('camera')['bind']('positionSet', A['updateFn'], this), A['media']['get']('camera')['bind']('userInteractionStart', A['userInteractionStartFn'], this)), j(z); }

    function m(z) { j(this['getActivePlayerWithViewer'](z['source'])), f(v); } var n = a['get']('children'),
        o = n[0x0],
        p = n[0x1],
        q = o['get']('children')[0x0],
        r = p['get']('children')[0x0],
        s = n[0x2],
        t, u, v, w, x, y = [];
    k['call'](this, q), k['call'](this, r), this['bind']('instanceCreation', z => { var A = z['data']['instance']; if (A['get']('class') == 'PanoramaPlayer') { var B = A;
            B['bind']('preloadMediaShow', i, this), B['get']('class') == 'PanoramaPlayer' && (B['bind']('cameraPositionChange', e, this), B['bind']('userInteractionStart', g, this)), l['call'](this, B); } }, this), q['bind']('mouseDown', m, this), r['bind']('mouseDown', m, this), a['bind']('resize', function() { s['set']('left', (a['get']('actualWidth') - s['get']('actualWidth')) * 0.5), b(); }, this), b(); }, TDV['Tour']['Script']['isCardboardViewMode'] = function() { var a = this['getByClassName']('PanoramaPlayer'); return a['length'] > 0x0 && a[0x0]['get']('viewMode') == 'cardboard'; };
const isVRMode = function() { return this['getMainViewer']()['get']('viewMode') === 'vr'; };
TDV['Tour']['Script']['isPanorama'] = function(a) { return ['Panorama', 'HDRPanorama', 'LivePanorama', 'Video360', 'VideoPanorama']['indexOf'](a['get']('class')) != -0x1; }, TDV['Tour']['Script']['keepCompVisible'] = function(a, b) { var c = 'keepVisibility_' + a['get']('id'),
        d = this['getKey'](c); if (d == undefined && b) this['registerKey'](c, b);
    else d != undefined && !b && this['unregisterKey'](c); }, TDV['Tour']['Script']['_initItemWithComps'] = function(a, b, c, d, e, f, g, h) { var j = a['get']('items')[b],
        k = j['get']('media'),
        l = j['get']('player'),
        m = k['get']('loop') == undefined || k['get']('loop'),
        n = h > 0x0,
        o = this['rootPlayer'],
        p = function(x) { var y = f ? f['get']('class') : undefined,
                z = undefined; switch (y) {
                case 'FadeInEffect':
                case 'FadeOutEffect':
                    z = o['createInstance'](x ? 'FadeInEffect' : 'FadeOutEffect'); break;
                case 'SlideInEffect':
                case 'SlideOutEffect':
                    z = o['createInstance'](x ? 'SlideInEffect' : 'SlideOutEffect'); break; } if (z) { z['set']('duration', f['get']('duration')), z['set']('easing', f['get']('easing')); if (y['indexOf']('Slide') != -0x1) z['set'](x ? 'from' : 'to', f['get'](f['get']('class') == 'SlideInEffect' ? 'from' : 'to')); } return z; },
        q = function() { for (var x = 0x0, y = c['length']; x < y; ++x) { var z = c[x]; if (h > 0x0) this['setComponentVisibility'](z, !e, 0x0, p(!e));
                else { var A = 'visibility_' + z['get']('id'); if (this['existsKey'](A)) { if (this['getKey'](A)) this['setComponentVisibility'](z, !![], 0x0, p(!![]));
                        else this['setComponentVisibility'](z, ![], 0x0, p(![]));
                        this['unregisterKey'](A); } } }
            j['unbind']('end', q, this); if (!m) k['unbind']('end', q, this); },
        r = function() { j['unbind']('stop', r, this, !![]), j['unbind']('stop', r, this), j['unbind']('begin', r, this, !![]), j['unbind']('begin', r, this); for (var x = 0x0, y = c['length']; x < y; ++x) { this['keepCompVisible'](c[x], ![]); } },
        s = function(x, y, z) { var A = function() { var B = function(F, G, H) { o['setComponentVisibility'](F, G, y, H, G ? 'showEffect' : 'hideEffect', ![]); if (z > 0x0) { var I = y + z + (H != undefined ? H['get']('duration') : 0x0);
                        o['setComponentVisibility'](F, !G, I, p(!G), G ? 'hideEffect' : 'showEffect', !![]); } }; for (var C = 0x0, D = c['length']; C < D; ++C) { var E = c[C]; if (e == 'toggle') { if (!E['get']('visible')) B['call'](this, E, !![], p(!![]));
                        else B['call'](this, E, ![], p(![])); } else B['call'](this, E, e, p(e)); }
                j['unbind'](x, A, this); if (x == 'end' && !m) k['unbind'](x, A, this); };
            j['bind'](x, A, this); if (x == 'end' && !m) k['bind'](x, A, this); }; if (d == 'begin') { for (var t = 0x0, u = c['length']; t < u; ++t) { var v = c[t];
            this['keepCompVisible'](v, !![]); if (n) { var w = 'visibility_' + v['get']('id');
                this['registerKey'](w, v['get']('visible')); } }
        j['bind']('stop', r, this, !![]), j['bind']('stop', r, this), j['bind']('begin', r, this, !![]), j['bind']('begin', r, this); if (n) { j['bind']('end', q, this); if (!m) k['bind']('end', q, this); } } else d == 'end' && h > 0x0 && (s['call'](this, 'begin', h, 0x0), h = 0x0); if (d != undefined) s['call'](this, d, g, h); }, TDV['Tour']['Script']['loadFromCurrentMediaPlayList'] = function(a, b, c) { var d = a['get']('selectedIndex'),
        e = a['get']('items')['length'],
        f = (d + b) % e; while (f < 0x0) { f = e + f; } if (d != f) { if (c) { var g = a['get']('items')[f];
            this['skip3DTransitionOnce'](g['get']('player')); }
        a['set']('selectedIndex', f); } }, TDV['Tour']['Script']['mixObject'] = function(a, b) { return this['assignObjRecursively'](b, this['copyObjRecursively'](a)); }, TDV['Tour']['Script']['downloadFile'] = function(a) { if ((navigator['userAgent']['toLowerCase']()['indexOf']('chrome') > -0x1 || navigator['userAgent']['toLowerCase']()['indexOf']('safari') > -0x1) && !/(iP)/g ['test'](navigator['userAgent'])) { var b = document['createElement']('a');
        b['href'] = a, b['setAttribute']('target', '_blank'); if (b['download'] !== undefined) { var c = a['substring'](a['lastIndexOf']('/') + 0x1, a['length']);
            b['download'] = c; } if (document['createEvent']) { var d = document['createEvent']('MouseEvents');
            d['initEvent']('click', !![], !![]), b['dispatchEvent'](d); return; } }
    window['open'](a, '_blank'); }, TDV['Tour']['Script']['openLink'] = function(a, b) { if (!a || a == location['href']) return; if (!b) b = '_blank';
    (b == '_top' || b == '_self') && this['updateDeepLink']({ 'includeCurrentView': !![], 'includeCurrentVisibleHotspots': !![], 'includeCurrentMeasureModel3DObjects': !![], 'setHash': !![] }); var c = window && window['process'] && window['process']['versions'] && window['process']['versions']['electron'] || navigator && navigator['userAgent'] && navigator['userAgent']['indexOf']('Electron') >= 0x0; if (c && b == '_blank') { a['startsWith']('files/') && (a = '/' + a); if (a['startsWith']('//')) a = 'https:' + a;
        else { if (a['startsWith']('/')) { var d = window['location']['href']['split']('/');
                d['pop'](), a = d['join']('/') + a; } } var e = a['split']('.')['pop']()['toLowerCase'](); if ((['pdf', 'zip', 'xls', 'xlsx']['indexOf'](e) == -0x1 || a['startsWith']('file://')) && window['hasOwnProperty']('require')) { var f = window['require']('electron')['shell'];
            f['openExternal'](a); } else window['open'](a, b); } else { if (c && (b == '_top' || b == '_self')) window['location'] = a;
        else { var g = this['get']('data')['tour']; if (g['isMobileApp']() && g['isIOS']()) a = 'blank:' + a; var h = window['open'](a, b);
            h['focus'](); } } }, TDV['Tour']['Script']['startPanoramaWithModel'] = function(a, b) { var c = a['get']('media'),
        d = _findLocationWithPanorama['call'](this, c); if (!d) { b['call'](this); return; } var e = d['get']('model'),
        f = a['get']('player')['get']('viewerArea'),
        g = this['getActivePlayersWithViewer'](f),
        h = g['length'] == 0x1 ? g['find'](function(o) { return this['getMediaFromPlayer'](o) == e; }['bind'](this)) : undefined; if (h) b['call'](this);
    else { var g = _getPlayersWithViewer['call'](this, f),
            h = g['find'](function(o) { return o['get']('class') == 'Model3DPlayer'; }),
            i, j; if (!h) h = this['createInstance']('Model3DPlayer'), h['set']('viewerArea', f);
        else { var k = this['getByClassName']('Model3DPlayListItem');
            i = k['find'](function(o) { return o['get']('player') == h; }['bind'](this)); }!i && (i = this['createInstance']('Model3DPlayListItem'), i['set']('player', h), _initModel3DItem['call'](this, i));
        i['set']('media', e); var l = d['get']('forceModelLoading');
        d['set']('forceModelLoading', !![]); var m = function() { i['unbind']('begin', m, this), b['call'](this); },
            n = function() { a['unbind']('begin', n, this), d['set']('forceModelLoading', l); if (j) this['disposeInstance'](j); };
        a['bind']('begin', n, this); if (i['get']('state') == 'playing') m['call'](this);
        else i['bind']('begin', m, this), j = this['createInstance']('PlayList'), j['set']('items', [i]), j['set']('selectedIndex', 0x0); } }, TDV['Tour']['Script']['pauseCurrentPlayers'] = function(a) { var b = this['getCurrentPlayers'](),
        c = b['length']; while (c-- > 0x0) { var d = b[c]; if (d['get']('state') == 'playing' || d['get']('data') && d['get']('data')['playing'] || d['get']('viewerArea') && d['get']('viewerArea')['get']('id') == this['getMainViewer']() || d['get']('camera') && d['get']('camera')['get']('idleSequence') && d['get']('camera')['get']('timeToIdle') > 0x0 && d['get']('state') == 'playing' || d['get']('class') == 'Model3DPlayer' && d['get']('model') && d['get']('model')['get']('camera')['get']('state') == 'playing') { var e = this['getMediaFromPlayer'](d);
            a && e && e['get']('class') != 'Video360' && 'pauseCamera' in d ? d['pauseCamera']() : d['pause'](); } else b['splice'](c, 0x1); } return b; }, TDV['Tour']['Script']['pauseGlobalAudiosWhilePlayItem'] = function(a, b, c) { var d = a['get']('items')[b]; if (d['get']('class') == 'VideoPlayListItem') { var e = d['get']('player'),
            f = !![],
            g = this['_getPlayListsWithViewer'](e['get']('viewerArea')),
            h = function(n) { if (n['data']['state'] == 'playing' && f) this['pauseGlobalAudios'](c, !![]), f = ![];
                else n['data']['state'] == 'stopped' && !f && (window['resumeAudiosBlocked'] = ![], this['resumeGlobalAudios'](), f = !![]); };

        function m(n) { if (n['source'] != a && n['source']['get']('selectedIndex') != -0x1 || n['source'] == a && n['data']['nextSelectedIndex'] != b) { for (var o = 0x0; o < g['length']; ++o) { var p = g[o];
                    p['unbind']('changing', m, this); }
                e['unbind']('stateChange', h, this); if (!f) this['resumeGlobalAudios'](); } }
        e['bind']('stateChange', h, this); for (var j = 0x0; j < g['length']; ++j) { var k = g[j];
            k['bind']('changing', m, this); } } else { var l = function() { if (d['get']('class') == 'VideoPlayListItem') { if (e['get']('state') == 'stopped') { this['resumeGlobalAudios'](); return; } }
            a['get']('selectedIndex') != b && this['resumeGlobalAudios'](); };
        this['pauseGlobalAudios'](c, !![]), this['executeFunctionWhenChange'](a, b, l, l); } }, TDV['Tour']['Script']['pauseGlobalAudios'] = function(b, c) { this['stopTextToSpeech'](); if (window['pausedAudiosLIFO'] == undefined) window['pausedAudiosLIFO'] = []; var d = this['getByClassName']('VideoPanoramaOverlay');
    d = d['concat'](this['getByClassName']('QuadVideoPanoramaOverlay')); for (var e = d['length'] - 0x1; e >= 0x0; --e) { var f = d[e]; if (f['get']('video')['get']('hasAudio') == ![]) d['splice'](e, 0x1); } var g = this['getByClassName']('Audio')['concat'](d),
        h = {}; if (window['currentGlobalAudios'] != undefined) g = g['concat'](Object['values'](window['currentGlobalAudios'])['map'](function(m) { if (!m['allowResume']) h[m['audio']['get']('id')] = m['audio']; return m['audio']; })); var j = []; for (var e = 0x0, k = g['length']; e < k; ++e) { var l = g[e];
        l && l['get']('state') == 'playing' && (b == undefined || b['indexOf'](l) == -0x1) && (l['get']('id') in h ? l['stop']() : (l['pause'](), j['push'](l))); } if (c || j['length'] > 0x0) window['pausedAudiosLIFO']['push'](j); return j; }, TDV['Tour']['Script']['resumeGlobalAudios'] = function() { if (window['pausedAudiosLIFO'] == undefined) return; if (window['resumeAudiosBlocked']) { window['pausedAudiosLIFO']['length'] > 0x1 && (window['pausedAudiosLIFO'][window['pausedAudiosLIFO']['length'] - 0x2] = window['pausedAudiosLIFO'][window['pausedAudiosLIFO']['length'] - 0x2]['concat'](window['pausedAudiosLIFO'][window['pausedAudiosLIFO']['length'] - 0x1]), window['pausedAudiosLIFO']['splice'](window['pausedAudiosLIFO']['length'] - 0x1, 0x1)); return; } var b = window['pausedAudiosLIFO']['pop'](); if (!b) return; for (var c = 0x0, d = b['length']; c < d; ++c) { var e = b[c]; if (e['get']('state') == 'paused') e['play'](); } }, TDV['Tour']['Script']['pauseGlobalAudio'] = function(a) { var b = window['currentGlobalAudios']; if (b) { var c = b[a['get']('id')]; if (c) a = c['audio']; } if (a['get']('state') == 'playing') a['pause'](); }, TDV['Tour']['Script']['playAudioList'] = function(a, b) { if (a['length'] == 0x0) return; if (a['length'] == 0x1 && b) { var c = a[0x0];
        c['set']('loop', !![]), this['playGlobalAudio'](c, !![], null, !![]); } else { var d = -0x1,
            e, f = this['playGlobalAudio'],
            g = function() { if (++d >= a['length']) { if (!b) return;
                    d = 0x0; }
                e = a[d], f(e, !![], g, !![]); };
        g(); } }, TDV['Tour']['Script']['playGlobalAudioWhilePlayActiveMedia'] = function(a, b, c, d) { var e = this['getActiveMediaWithViewer'](this['getMainViewer']()),
        f = this['getFirstPlayListWithMedia'](e, !![]),
        g = this['getPlayListItemByMedia'](f, e),
        h = f['get']('items')['indexOf'](g); return this['playGlobalAudioWhilePlay'](f, h, a, b, c, d); }, TDV['Tour']['Script']['playGlobalAudioWhilePlay'] = function(a, b, c, d, e, f) { var g = function(o) { if (o['data']['previousSelectedIndex'] == b) { this['stopGlobalAudio'](c); if (j) { var p = i['get']('media'),
                        q = p['get']('audios');
                    q['splice'](q['indexOf'](c), 0x1), p['set']('audios', q); }
                a['unbind']('change', g, this); if (e) e(); } },
        h = window['currentGlobalAudios']; if (h && c['get']('id') in h) return c = h[c['get']('id')]['audio'], c['get']('state') != 'playing' && c['play'](), c;
    a['bind']('change', g, this); var i = a['get']('items')[b],
        j = i['get']('class') == 'PanoramaPlayListItem'; if (j) { var k = i['get']('media'),
            h = (k['get']('audios') || [])['slice'](); if (c['get']('class') == 'MediaAudio') { var l = this['rootPlayer']['createInstance']('PanoramaAudio');
            l['set']('autoplay', ![]), l['set']('audio', c['get']('audio')), l['set']('loop', c['get']('loop')), l['set']('id', c['get']('id')), this['cloneBindings'](c, l, 'start'), this['cloneBindings'](c, l, 'end'), this['cloneBindings'](c, l, 'stateChange'), c = l; }
        h['push'](c), k['set']('audios', h); } var m = this['playGlobalAudio'](c, d, function() { a['unbind']('change', g, this); if (e) e['call'](this); }); if (f === !![]) { var n = function() { if (m['get']('state') == 'playing') this['pauseGlobalAudios']([m], !![]);
            else m['get']('state') == 'stopped' && (this['resumeGlobalAudios'](), m['unbind']('stateChange', n, this)); };
        m['bind']('stateChange', n, this); } return m; }, TDV['Tour']['Script']['playGlobalAudio'] = function(a, b, c, d) { var e = function() { a['unbind']('end', e, this), this['stopGlobalAudio'](a); if (c) c['call'](this); };
    a = this['getGlobalAudio'](a); var f = window['currentGlobalAudios'];!f && (f = window['currentGlobalAudios'] = {});
    f[a['get']('id')] = { 'audio': a, 'asBackground': d || ![], 'allowResume': b }; if (a['get']('state') == 'playing') return a; return !a['get']('loop') && a['bind']('end', e, this), a['play'](), a; }, TDV['Tour']['Script']['restartTourWithoutInteraction'] = function(a) { var b = null;
    this['bind']('userInteraction', c['bind'](this), this), c['call'](this);

    function c() { if (b !== null) b['cancel']();
        b = new Timer(a, function() { var d = this['get']('data')['tour']; if (d) { if (this['isCardboardViewMode']()) location['reload']();
                else d['reload'](); } }['bind'](this)); } }, TDV['Tour']['Script']['resumePlayers'] = function(a, b) { for (var c = 0x0; c < a['length']; ++c) { var d = a[c],
            e = this['getMediaFromPlayer'](d); if (!e) continue; if (b && e['get']('class') != 'Video360' && 'pauseCamera' in d) d['resumeCamera']();
        else { if (d['get']('state') != 'playing') { var f = d['get']('data');!f && (f = {}, d['set']('data', f));
                f['playing'] = !![]; var g = function() { d['get']('state') == 'playing' && (delete f['playing'], d['unbind']('stateChange', g, this)); };
                d['bind']('stateChange', g, this), d['play'](); } } } }, TDV['Tour']['Script']['stopGlobalAudios'] = function(a) { var b = window['currentGlobalAudios'],
        c = this;
    b && Object['keys'](b)['forEach'](function(d) { var e = b[d];
        (!a || a && !e['asBackground']) && c['stopGlobalAudio'](e['audio']); }); }, TDV['Tour']['Script']['stopGlobalAudio'] = function(a) { var b = window['currentGlobalAudios']; if (b) { var c = b[a['get']('id')];
        c && (a = c['audio'], delete b[a['get']('id')], Object['keys'](b)['length'] == 0x0 && (window['currentGlobalAudios'] = undefined)); } if (a) a['stop'](); }, TDV['Tour']['Script']['setCameraSameSpotAsMedia'] = function(a, b) { var c = this['getCurrentPlayerWithMedia'](b); if (c != undefined) { var d = a['get']('initialPosition');
        d['set']('yaw', c['get']('yaw')), d['set']('pitch', c['get']('pitch')), d['set']('hfov', c['get']('hfov')); } }, TDV['Tour']['Script']['isComponentVisible'] = function(a) { if (isVRMode['call'](this)) { var b = a['get']('id') + '_vr';
        b in this && (a = this[b]); } return a['get']('visible'); }, TDV['Tour']['Script']['setComponentVisibility'] = function(a, b, c, d, e, f) { var g = a['get']('id') + '_vr';
    g in this && this['setComponentVisibility'](this[g], b, c, d, e, f); var h = a['get']('data') || {}; if (!!h['visibleOnlyOnVR'] || !!h['visibleIfCardboardAvailable'] && !this['get']('cardboardAvailable') || !!h['visibleIfGyroscopeAvailable'] && !this['get']('gyroscopeAvailable')) return; var j = this['getKey']('keepVisibility_' + a['get']('id')); if (j) return;
    this['unregisterKey']('visibility_' + a['get']('id')); var k = function() { e && a['set'](e, d);
            a['set']('visible', b); if (a['get']('class') == 'ViewerArea') { try { if (b) a['restart']();
                    else { if (a['get']('playbackState') == 'playing') a['pause'](); } } catch (o) {}; } },
        l = 'effectTimeout_' + a['get']('id'); if (!f && window['hasOwnProperty'](l)) { var m = window[l]; if (m instanceof Array)
            for (var n = 0x0; n < m['length']; n++) { m[n]['cancel'](); } else m['cancel']();
        delete window[l]; } else { if (b == a['get']('visible') && !f) return; } if (c && c > 0x0) { var m = new Timer(c / 0x3e8, function() { if (window[l] instanceof Array) { var o = window[l],
                    p = o['indexOf'](m);
                o['splice'](p, 0x1), o['length'] == 0x0 && delete window[l]; } else delete window[l];
            k(); });
        window['hasOwnProperty'](l) ? window[l] = [window[l], m] : window[l] = m; } else k(); }, TDV['Tour']['Script']['setDirectionalPanoramaAudio'] = function(a, b, c, d) { a['set']('yaw', b), a['set']('pitch', c), a['set']('maximumAngle', d); }, TDV['Tour']['Script']['setLocale'] = function(a) { this['stopTextToSpeech'](); var b = this['get']('data')['localeManager']; if (b) this['get']('data')['localeManager']['setLocale'](a);
    else this['get']('data')['defaultLocale'] = a, this['get']('data')['forceDefaultLocale'] = !![]; }, TDV['Tour']['Script']['setEndToItemIndex'] = function(a, b, c) { var d = function() { if (a['get']('selectedIndex') == b) { var e = a['get']('items')[c];
            this['skip3DTransitionOnce'](e['get']('player')), a['set']('selectedIndex', c); } };
    this['executeFunctionWhenChange'](a, b, d); }, TDV['Tour']['Script']['setMapLocation'] = function(a, b) { var c = function() { a['unbind']('stop', c, this), d['set']('mapPlayer', null); };
    a['bind']('stop', c, this); var d = a['get']('player');
    d['set']('mapPlayer', b); }, TDV['Tour']['Script']['setMainMediaByIndex'] = function(a) { var b = undefined; if (a >= 0x0 && a < this['mainPlayList']['get']('items')['length']) { b = this['mainPlayList']['get']('items')[a]; var c = b['get']('media'),
            d = c['get']('class')['indexOf']('Panorama') != -0x1 ? _findLocationWithPanorama['call'](this, c) : null;
        d ? this['startPanoramaWithModel']['call'](this, b, function() { this['mainPlayList']['set']('selectedIndex', a); }['bind'](this)) : this['mainPlayList']['set']('selectedIndex', a); } return b; }, TDV['Tour']['Script']['setMainMediaByName'] = function(a) { var b = this['getMainViewer'](),
        c = this['_getPlayListsWithViewer'](b); for (var d = 0x0, e = c['length']; d < e; ++d) { var f = c[d],
            g = f['get']('items'); for (var h = 0x0, k = g['length']; h < k; ++h) { var l = g[h],
                m = l['get']('media')['get']('data'); if (m !== undefined && m['label'] == a && l['get']('player')['get']('viewerArea') == b) return f['set']('selectedIndex', h), l; } } }, TDV['Tour']['Script']['executeAudioAction'] = function(a, b, c, d, e, f) { if (a['length'] == 0x0) return; var g, h, j = this['getMainViewer'](); if (c && !(c === !![])) { var k = this['getPlayListsWithMedia'](c); for (var l = 0x0; l < k['length']; ++l) { var m = k[l],
                n = this['getPlayListItemByMedia'](m, c); if (n && n['get']('player') && n['get']('player')['get']('viewerArea') == j) { g = m, h = g['get']('items')['indexOf'](n); break; } }!g && k['length'] > 0x0 && (g = k[0x0], h = this['getPlayListItemIndexByMedia'](g, c)); if (!g) c = !![]; } if (c === !![]) { var o = this['getActiveMediaWithViewer'](j); if (o) { g = this['getFirstPlayListWithMedia'](o, !![]); var n = this['getPlayListItemByMedia'](g, o);
            h = g['get']('items')['indexOf'](n); } else c = null; } var p = [],
        q = function() { var z = p['concat'](),
                A = ![],
                B = function(E) { var F = E['source']['get']('state'); if (F == 'playing') !A && (A = !![], this['pauseGlobalAudios'](p, !![]));
                    else F == 'stopped' && (z['splice'](z['indexOf'](E['source']), 0x1), z['length'] == 0x0 && this['resumeGlobalAudios'](), E['source']['unbind']('stateChange', B, this)); }['bind'](this); for (var C = 0x0, D = p['length']; C < D; ++C) { p[C]['bind']('stateChange', B, this); } }['bind'](this),
        r = function() { for (var z = 0x0, A = a['length']; z < A; ++z) { var B = a[z];
                p['push'](this['playGlobalAudio'](B, d)); } if (e) q(); }['bind'](this),
        s = function(z) { for (var A = 0x0, B = a['length']; A < B; ++A) { var C = a[A];
                p['push'](this['playGlobalAudioWhilePlay'](g, h, C, d, z)); } if (e) q(); }['bind'](this),
        t = function() { for (var z = 0x0, A = a['length']; z < A; ++z) { this['pauseGlobalAudio'](a[z]); } }['bind'](this),
        u = function() { for (var z = 0x0, A = a['length']; z < A; ++z) { this['stopGlobalAudio'](a[z]); } }['bind'](this),
        v = function() { for (var z = 0x0, A = a['length']; z < A; ++z) { if (this['getGlobalAudio'](a[z])['get']('state') == 'playing') return !![]; } return ![]; }['bind'](this); if (b == 'playPause' || b == 'playStop') { if (v()) { if (b == 'playPause') t();
            else b == 'playStop' && u(); } else e && (b == 'playStop' && this['stopGlobalAudios'](!![])), g ? s() : r(); } else { if (b == 'play' || b == 'forcePlay') { if (b == 'forcePlay') u(); if (g || c === !![]) { var w; if (f) { var x = g ? g['get']('items')[h]['get']('player') : this['getActivePlayerWithViewer'](this['getMainViewer']()); if (x && x['pauseCamera']) { var y = a['concat']();
                        w = function(z) { y['splice'](y['indexOf'](z), 0x1); if (y['length'] == 0x0) x['resumeCamera'](); }['bind'](this), x['pauseCamera'](); } }
                s(w); } else r(); } else { if (b == 'stop') u();
            else b == 'pause' && t(); } } }, TDV['Tour']['Script']['executeAudioActionByTags'] = function(a, b, c, d, e, f, g) { var h = this['getAudioByTags'](a, b);
    this['executeAudioAction'](h, c, d, e, f, g); }, TDV['Tour']['Script']['setPlayListSelectedIndex'] = function(a, b) { var c = a['get']('items')[b],
        d = c['get']('player'),
        e = d['get']('viewerArea'),
        f = this['getByClassName']('PlayList'); for (var g of f) { if (g == a) continue; var h = g['get']('selectedIndex'); if (h != -0x1) { var i = g['get']('items')[h],
                j = i['get']('player'); if (j && j != d && j['get']('class') != 'Model3DPlayer' && j['get']('viewerArea') == e) g['set']('selectedIndex', -0x1); } }
    a['set']('selectedIndex', b); }, TDV['Tour']['Script']['setMediaBehaviour'] = function(a, b, c, d) { var e = this,
        f = function(D) { D['data']['state'] == 'stopped' && d && k['call'](this, !![]); },
        g = function() { q['unbind']('begin', g, e); var D = q['get']('media'),
                E = D['get']('class');
            (E != 'Panorama' && E != 'Model3D' || D['get']('camera') != undefined && D['get']('camera')['get']('initialSequence') != undefined) && r['bind']('stateChange', f, e); },
        h = function() { var D = n['get']('selectedIndex');
            D != -0x1 && (p = D, k['call'](this, ![])); },
        j = function() { k['call'](this, ![]); },
        k = function(D) { if (!n) return; var E = q['get']('media'); if ((E['get']('class') == 'Video360' || E['get']('class') == 'Video') && E['get']('loop') == !![] && !D) return;
            a['set']('selectedIndex', -0x1); if (y && x != -0x1) { if (y) { if (x > 0x0 && y['get']('movements')[x - 0x1]['get']('class') == 'TargetPanoramaCameraMovement') { var F = z['get']('initialPosition'),
                            G = F['get']('yaw'),
                            H = F['get']('pitch'),
                            I = F['get']('hfov'),
                            J = y['get']('movements')[x - 0x1],
                            K = J['get']('targetYaw'),
                            L = J['get']('targetPitch'),
                            M = J['get']('targetHfov'); if (K !== undefined) F['set']('yaw', K); if (L !== undefined) F['set']('pitch', L); if (M !== undefined) F['set']('hfov', M); var N = function(Q) { F['set']('yaw', G), F['set']('pitch', H), F['set']('hfov', I), t['unbind']('end', N, this); };
                        t['bind']('end', N, this); }
                    y['set']('movementIndex', x); } } if (r) { q['unbind']('begin', g, this), r['unbind']('stateChange', f, this); for (var O = 0x0; O < A['length']; ++O) { A[O]['unbind']('click', j, this); } } if (w) { var P = this['getMediaFromPlayer'](r);
                (n == this['mainPlayList'] || n['get']('items')['length'] > 0x1) && (P == undefined || P == q['get']('media')) && n['set']('selectedIndex', p); if (a != n) n['unbind']('change', h, this); } else u['set']('visible', v);
            n = undefined; }; if (!c) { var l = a['get']('selectedIndex'),
            m = l != -0x1 ? a['get']('items')[a['get']('selectedIndex')]['get']('player') : this['getActivePlayerWithViewer'](this['getMainViewer']());
        m && (c = this['getMediaFromPlayer'](m)); } var n = undefined; if (c) { var o = this['getPlayListsWithMedia'](c, !![]); if (o['indexOf'](a) != -0x1) n = a;
        else { if (o['indexOf'](this['mainPlayList']) != -0x1) n = this['mainPlayList'];
            else o['length'] > 0x0 && (n = o[0x0]); } } if (!n) { a['set']('selectedIndex', b); return; } var p = n['get']('selectedIndex'),
        q = a['get']('items')[b],
        r = q['get']('player'),
        s = this['getMediaFromPlayer'](r); if (a['get']('selectedIndex') == b && s == q['get']('media') || p == -0x1) return; if (a['get']('selectedIndex') == b && s != q['get']('media')) a['set']('selectedIndex', -0x1); var t = n['get']('items')[p],
        u = r['get']('viewerArea'),
        v = u['get']('visible'),
        w = u == t['get']('player')['get']('viewerArea');
    w ? a != n && (n['set']('selectedIndex', -0x1), n['bind']('change', h, this)) : u['set']('visible', !![]); var x = -0x1,
        y = undefined,
        z = t['get']('camera');
    z && (y = z['get']('initialSequence'), y && (x = y['get']('movementIndex') || -0x1));
    a['set']('selectedIndex', b); var A = [],
        B = function(D) { var E = r['get'](D); if (E == undefined) return; if (Array['isArray'](E)) A = A['concat'](E);
            else A['push'](E); };
    B('buttonStop'); for (var C = 0x0; C < A['length']; ++C) { A[C]['bind']('click', j, this); }
    q['bind']('begin', g, e), this['executeFunctionWhenChange'](a, b, d ? j : undefined); }, TDV['Tour']['Script']['setOverlayBehaviour'] = function(a, b, c, d) { var e = function() { switch (c) {
            case 'triggerClick':
                this['triggerOverlay'](a, 'click'); break;
            case 'stop':
            case 'play':
            case 'pause':
                a[c](); break;
            case 'togglePlayPause':
            case 'togglePlayStop':
                if (a['get']('state') == 'playing') a[c == 'togglePlayPause' ? 'pause' : 'stop']();
                else a['play'](); break; } if (d) { if (window['overlaysDispatched'] == undefined) window['overlaysDispatched'] = {}; var j = a['get']('id');
            window['overlaysDispatched'][j] = !![], setTimeout(function() { delete window['overlaysDispatched'][j]; }, 0x3e8); } }; if (d && window['overlaysDispatched'] != undefined && a['get']('id') in window['overlaysDispatched']) return; var f = this['getFirstPlayListWithMedia'](b, !![]); if (f != undefined) { var g = this['getPlayListItemByMedia'](f, b),
            h = g['get']('player'); if (f['get']('items')['indexOf'](g) != f['get']('selectedIndex') || this['isPanorama'](g['get']('media')) && h['get']('rendererPanorama') != g['get']('media')) { var i = function(j) { g['unbind']('begin', i, this), e['call'](this); };
            g['bind']('begin', i, this); return; } }
    e['call'](this); }, TDV['Tour']['Script']['setOverlaysVisibility'] = function(a, b, c) { var d = 'overlayEffects',
        e = undefined,
        f = this['getKey'](d);!f && (f = {}, this['registerKey'](d, f)); for (var g = 0x0, h = a['length']; g < h; ++g) { var j = a[g]; if (!j) continue;
        c && c > 0x0 ? f[j['get']('id')] = new Timer(c / 0x3e8, k['bind'](this, j)) : k['call'](this, j); }

    function k(l) { if (l['get']('class') == 'PanoramaModel3DLocation') { var m = l['get']('data')['object'];
            k['call'](this, m); var n = m['get']('data')['panoramaOverlays']; for (var o = 0x0, p = n['length']; o < p; ++o) { k['call'](this, n[o]); } } if (!l) return; var q = l['get']('id'),
            r = f[q];
        r && (r['cancel'](), delete r[q]); var s = b == 'toggle' ? !l['get']('enabled') : b;
        l['set']('enabled', s); if (l['get']('class') == 'PanoramaModel3DLocation') l['get']('data')['enabled'] = s; var t = l['get']('data'); if (s && t && 'group' in t) { var u = this['getOverlaysByGroupname'](t['group']); for (var v = 0x0, w = u['length']; v < w; ++v) { var x = u[v]; if (x != l) x['set']('enabled', !s); } } if (!e) e = this['getByClassName']('AdjacentPanorama'); for (var y = 0x0, A = e['length']; y < A; ++y) { var B = e[y],
                t = B['get']('data'); if (!t) continue; var x = this[t['overlayID']];
            x && x == l && B['set']('enabled', x['get']('enabled')); } } }, TDV['Tour']['Script']['setOverlaysVisibilityByTags'] = function(a, b, c, d, e) { var f = c ? this['getPanoramaOverlaysByTags'](c, a, d) : this['getOverlaysByTags'](a, d);
    this['setOverlaysVisibility'](f, b, e); }, TDV['Tour']['Script']['setComponentsVisibilityByTags'] = function(a, b, c, d, e) { var f = this['getComponentsByTags'](a, e); for (var g = 0x0, h = f['length']; g < h; ++g) { var j = f[g]; if (b == 'toggle') j['get']('visible') ? d(j) : c(j);
        else b ? c(j) : d(j); } }, TDV['Tour']['Script']['setModel3DCameraWithCurrentSpot'] = function(a, b) { var c = this['getActiveMediaWithViewer'](b || this['getMainViewer']()),
        d = a['get']('media'); if (c != undefined && c['get']('class')['indexOf']('Model3D') != -0x1 && c != d) { var e = c['get']('camera'),
            f = ['x', 'y', 'z', 'yaw', 'pitch', 'fov', 'distance'],
            g = {}; for (var h of f) { var i = e['get'](h); if (i !== undefined) g[h] = i; }
        this['startModel3DWithCameraSpot'](a, g); } }, TDV['Tour']['Script']['setModel3DCameraSpot'] = function(a, b, c, d, e) { var f = a['get']('selectedIndex'),
        g = a['get']('items'),
        h = b['get']('media'),
        j = h['get']('camera'); if (f >= 0x0 && g[f] == b && h['get']('isLoaded')) { var k = this['_getPlayListsWithViewer'](b['get']('player')['get']('viewerArea')); for (var l = 0x0; l < k['length']; ++l) { var m = k[l];
            m !== a && m['get']('selectedIndex') !== -0x1 && m['get']('items')[m['get']('selectedIndex')]['get']('media') !== h && m['set']('selectedIndex', -0x1); }
        j['set']('yaw', j['get']('yaw') % 0x168); var n = b['get']('player')['get']('viewerArea'),
            o = this['getActiveMediaWithViewer'](n); if (o['get']('class')['indexOf']('Panorama') != -0x1) { if (d !== undefined) { d *= 0x3e8; var p = n['get']('modelToPanoramaTraslationDuration'),
                    q = n['get']('panoramaToModelTraslationDuration'),
                    r = () => { s['cancel'](), a['unbind']('change', r, this), n['set']('modelToPanoramaTraslationDuration', p), n['set']('panoramaToModelTraslationDuration', q); },
                    s = new Timer(d / 0x3e8, r);
                a['bind']('change', r, this), n['set']('modelToPanoramaTraslationDuration', d), n['set']('panoramaToModelTraslationDuration', d); }
            j['setStoredPosition'](c); } else this['createTweenModel3D'](j, c, d, e); } else { if (j['get']('state') == 'playing') j['stop']();
        this['startModel3DWithCameraSpot'](b, c); } }, TDV['Tour']['Script']['createTweenModel3D'] = function(a, b, c, d) { if (a['get']('state') == 'playing') a['stop'](); var e = this['createTween'](a, b, c, d);
    a['bind']('userInteractionStart', f, this), e['bind']('end', g, this), e['play']();

    function f() { a['unbind']('userInteractionStart', f, this), e['unbind']('end', g, this), e['cancel'](); }

    function g() { a['unbind']('userInteractionStart', f, this), e['unbind']('end', g, this); } }, TDV['Tour']['Script']['setModel3DCameraSequence'] = function(a, b, c) { var d = a['get']('selectedIndex'),
        e = a['get']('items'),
        f = b['get']('media'); if (e[d] === b && f['get']('isLoaded')) { var g = this['_getPlayListsWithViewer'](b['get']('player')['get']('viewerArea')); for (var h = 0x0; h < g['length']; ++h) { var j = g[h];
            j !== a && j['get']('selectedIndex') !== -0x1 && j['get']('items')[j['get']('selectedIndex')]['get']('media') !== f && j['set']('selectedIndex', -0x1); }
        c['play'](); } else { var k = c['get']('movements'),
            l = {}; if (k['length'] > 0x0) { var m = k[0x0]; if (m['get']('class') == 'TargetModel3DCameraMovement') { var n = ['x', 'y', 'z', 'yaw', 'pitch', 'fov', 'distance']; for (var o in n) { o = n[o]; var p = m['get']('target' + o['charAt'](0x0)['toUpperCase']() + o['slice'](0x1));
                    p !== undefined && (l[o] = p); } } }
        this['startModel3DWithCameraSpot'](b, l); var q = function() { b['unbind']('begin', q, this), c['play'](); };
        b['bind']('begin', q, this); } }, TDV['Tour']['Script']['setPanoramaCameraWithCurrentSpot'] = function(a, b) { var c = this['getActiveMediaWithViewer'](b || this['getMainViewer']()); if (c != undefined && (c['get']('class')['indexOf']('Panorama') != -0x1 || c['get']('class') == 'Video360')) { var d = a['get']('media'),
            e = this['clonePanoramaCamera'](a['get']('camera'));
        this['setCameraSameSpotAsMedia'](e, c), this['startPanoramaWithCamera'](d, e); } }, TDV['Tour']['Script']['setPanoramaCameraWithSpot'] = function(a, b, c, d, e) { var f = b['get']('media'),
        g = b['get']('player'); if (a['get']('items')[a['get']('selectedIndex')] == b || g['get']('rendererPanorama') == f) { if (c === undefined) c = g['get']('yaw'); if (d === undefined) d = g['get']('pitch'); if (e === undefined) e = g['get']('hfov');
        g['moveTo'](c, d, g['get']('roll'), e); } else { var h = this['clonePanoramaCamera'](b['get']('camera')),
            i = h['get']('initialPosition'); if (c !== undefined) i['set']('yaw', c); if (d !== undefined) i['set']('pitch', d); if (e !== undefined) i['set']('hfov', e);
        this['startPanoramaWithCamera'](f, h); } }, TDV['Tour']['Script']['setSurfaceSelectionHotspotMode'] = function(a) { var b = this['getByClassName']('HotspotPanoramaOverlay'),
        c = this['getByClassName']('PanoramaPlayer'),
        d = a == 'hotspotEnabled',
        e = a == 'circleEnabled',
        f = !!a;
    b['forEach'](function(g) { var h = g['get']('data'); if (h && h['hasPanoramaAction'] == !![]) g['set']('enabledInSurfaceSelection', d); }), c['forEach'](function(g) { g['set']('adjacentPanoramaPositionsEnabled', e), g['set']('surfaceSelectionEnabled', f); }), this['get']('data')['surfaceSelectionHotspotMode'] = a; }, TDV['Tour']['Script']['setValue'] = function(a, b, c) { try { if ('set' in a) a['set'](b, c);
        else a[b] = c; } catch (d) {} }, TDV['Tour']['Script']['setStartTimeVideo'] = function(a, b) { var c = this['getPlayListItems'](a),
        d = [],
        e = function() { for (var j = 0x0; j < c['length']; ++j) { var k = c[j];
                k['set']('startTime', d[j]), k['unbind']('stop', e, this); } }; for (var f = 0x0; f < c['length']; ++f) { var g = c[f],
            h = g['get']('player'); if (!h) continue;
        h['get']('video') == a && h['get']('state') == 'playing' ? h['seek'](b) : (d['push'](g['get']('startTime')), g['set']('startTime', b), g['bind']('stop', e, this)); } }, TDV['Tour']['Script']['setStartTimeVideoSync'] = function(a, b) { if (a && b) this['setStartTimeVideo'](a, b['get']('currentTime')); }, TDV['Tour']['Script']['skip3DTransitionOnce'] = function(a) { if (a && a['get']('class') == 'PanoramaPlayer') { var b = a['get']('viewerArea'); if (b && b['get']('translationTransitionEnabled') == !![]) { var c = function() { a['unbind']('preloadMediaShow', c, this), b['set']('translationTransitionEnabled', !![]); };
            b['set']('translationTransitionEnabled', ![]), a['bind']('preloadMediaShow', c, this); } } }, TDV['Tour']['Script']['shareSocial'] = function(a, b, c, d, e) { b == undefined && (b = location['href']['split'](location['search'] || location['hash'] || /[?#]/)[0x0]);
    c && (b += this['updateDeepLink'](d, ![]));
    b = function(g) { switch (g) {
            case 'email':
                return 'mailto:?body=' + encodeURIComponent(b);
            case 'facebook':
                var h = b['indexOf']('?') != -0x1;
                b = b['replace']('#', '?'); if (h) { var i = b['lastIndexOf']('?');
                    b = b['substring'](0x0, i) + '&' + b['substring'](i + 0x1); } return 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(b);
            case 'linkedin':
                return 'https://www.linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent(b);
            case 'pinterest':
                return 'https://pinterest.com/pin/create/button/?url=' + b;
            case 'telegram':
                return 'https://t.me/share/url?url=' + b;
            case 'twitter':
                return 'https://twitter.com/intent/tweet?source=webclient&url=' + b;
            case 'whatsapp':
                return 'https://api.whatsapp.com/send/?text=' + encodeURIComponent(b);
            default:
                return b; } }(a); if (e)
        for (var f in e) { b += '&' + f + '=' + e[f]; }
    if (a == 'clipboard') this['copyToClipboard'](b);
    else this['openLink'](b, '_blank'); }, TDV['Tour']['Script']['showComponentsWhileMouseOver'] = function(a, b, c, d) { var e = function(j) { for (var k = 0x0, l = b['length']; k < l; k++) { var m = b[k]; if (!d || d(m, j)) m['set']('visible', j); } }; if (this['get']('isMobile') || this['get']('touchDevice')) e['call'](this, !![]);
    else { var f = -0x1,
            g = function() { e['call'](this, !![]), f && (f['cancel'](), f = undefined), a['bind']('rollOut', h, this); },
            h = function() { var i = function() { e['call'](this, ![]); };
                a['unbind']('rollOut', h, this), f = new Timer(c / 0x3e8, i['bind'](this)); };
        a['bind']('rollOver', g, this); } }, TDV['Tour']['Script']['setObjectsVisibilityByTags'] = function(a, b, c, d) { var e = this['_getObjectsByTags'](b, ['InnerModel3DObject'], 'tags2Objects', c)['filter'](function(f) { return a['get']('objects')['indexOf'](f) != -0x1; }['bind'](this));
    this['setObjectsVisibility'](e, d); }, TDV['Tour']['Script']['setObjectsVisibilityByID'] = function(a, b, c) { var d = b['map'](function(e) { return this['getModel3DInnerObject'](a, e); }['bind'](this));
    this['setObjectsVisibility'](d, c); }, TDV['Tour']['Script']['setObjectsVisibility'] = function(a, b) { a['forEach'](function(c) { if (c) c['set']('enabled', b === 'toggle' ? !c['get']('enabled') : b); }['bind'](this)); }, TDV['Tour']['Script']['getModel3DInnerObject'] = function(a, b) { var c = a['get']('objects'); for (var d = 0x0, e = c['length']; d < e; ++d) { var f = c[d]; if (f['get']('class') == 'InnerModel3DObject' && f['get']('objectId') == b) return f; } return undefined; }, TDV['Tour']['Script']['showPopupMedia'] = function(a, b, c, d, e, f) { if (isVRMode['call'](this)) { showPopupMediaVR['call'](this, a, b, c, f); return; } var g = this,
        h = function() { window['resumeAudiosBlocked'] = ![], c['set']('selectedIndex', -0x1), g['getMainViewer']()['set']('toolTipEnabled', !![]), this['resumePlayers'](m, !![]), l && this['unbind']('resize', j, this), a['unbind']('close', h, this); },
        i = function() { a['hide'](); },
        j = function() { var n = function(F) { return a['get'](F) || 0x0; },
                o = g['get']('actualWidth'),
                p = g['get']('actualHeight'),
                q = g['getMediaWidth'](b),
                r = g['getMediaHeight'](b),
                s = parseFloat(d) / 0x64,
                t = parseFloat(e) / 0x64,
                u = s * o,
                v = t * p,
                x = n('footerHeight'),
                y = n('headerHeight'); if (!y) { var z = n('closeButtonIconHeight') + n('closeButtonPaddingTop') + n('closeButtonPaddingBottom'),
                    A = g['getPixels'](n('titleFontSize')) + n('titlePaddingTop') + n('titlePaddingBottom');
                y = z > A ? z : A, y += n('headerPaddingTop') + n('headerPaddingBottom'); } var B = u - n('bodyPaddingLeft') - n('bodyPaddingRight') - n('paddingLeft') - n('paddingRight'),
                C = v - y - x - n('bodyPaddingTop') - n('bodyPaddingBottom') - n('paddingTop') - n('paddingBottom'),
                D = B / C,
                E = q / r;
            D > E ? u = C * E + n('bodyPaddingLeft') + n('bodyPaddingRight') + n('paddingLeft') + n('paddingRight') : v = B / E + y + x + n('bodyPaddingTop') + n('bodyPaddingBottom') + n('paddingTop') + n('paddingBottom'), u > o * s && (u = o * s), v > p * t && (v = p * t), a['set']('width', u), a['set']('height', v), a['set']('x', (o - n('actualWidth')) * 0.5), a['set']('y', (p - n('actualHeight')) * 0.5); };
    f && this['executeFunctionWhenChange'](c, 0x0, i); var k = b['get']('class'),
        l = k == 'Video' || k == 'Video360';
    c['set']('selectedIndex', 0x0);
    l ? (this['bind']('resize', j, this), j(), c['get']('items')[0x0]['get']('player')['play']()) : (a['set']('width', d), a['set']('height', e));
    a['set']('maxWidth', 0x2710), a['set']('maxHeight', 0x2710), window['resumeAudiosBlocked'] = !![], this['getMainViewer']()['set']('toolTipEnabled', ![]); var m = this['pauseCurrentPlayers'](!![]);
    a['bind']('close', h, this), a['show'](this, !![]); };
const showPopupMediaVR = function(a, b, c, d) { const e = getPlayListItemClass(b); if (e === null) return;
    window['resumeAudiosBlocked'] = !![]; const f = this['pauseCurrentPlayers'](!![]),
        g = this['get']('xrPanels'),
        h = () => { window['resumeAudiosBlocked'] = ![], o['set']('selectedIndex', -0x1), this['resumePlayers'](f, !![]), g['splice'](g['indexOf'](l), 0x1), this['set']('xrPanels', g), delete this[o['get']('id')], delete this[n['get']('id')], t['set']('selectedIndex', u); },
        i = this['createInstance']('CloseButton'),
        j = a['getAttributeNames']()['filter'](x => x['indexOf']('closeButton') != -0x1); for (const x of j) { var k = x['slice']('closeButton' ['length']);
        k = k['charAt'](0x0)['toLowerCase']() + k['slice'](0x1), i['set'](k, a['get'](x)); }
    i['bind']('click', h, this); const l = this['createInstance']('XRPanel');
    l['set']('yaw', 0x2d), l['set']('pitch', 0x1e), l['set']('content', i), g['push'](l), this['set']('xrPanels', g); const m = this['getMainViewer'](),
        n = this['createInstance'](getPlayerClass(b));
    n['set']('viewerArea', m), n['set']('xrEnabled', !![]), n['set']('id', 'player' + (Math['random']() + 0x1)['toString'](0x24)['substring'](0x2)), this[n['get']('id')] = n; const o = this['createInstance']('PlayList');
    o['set']('id', c['get']('id') + '_cloned'), this[o['get']('id')] = o; const p = c['get']('items')[0x0],
        q = this['clone'](p),
        r = q['getEventNames'](); for (const y of r) { this['cloneBindings'](p, q, y, z => { return z['replace'](new RegExp(c['get']('id'), 'g'), o['get']('id'))['replace'](new RegExp(p['get']('player')['get']('id'), 'g'), n['get']('id')); }); }
    q['set']('player', n), o['set']('items', [q]);
    d && this['executeFunctionWhenChange'](o, 0x0, h); const s = this['_getPlayListsWithViewer'](m); let t, u; for (let z of s) { if (z['get']('selectedIndex') !== -0x1) { u = z['get']('selectedIndex'), t = z; break; } }
    o['set']('selectedIndex', 0x0); const v = b['get']('class');
    (v === 'Video' || v === 'Video360') && n['play'](); };
TDV['Tour']['Script']['showPopupImage'] = function(a, b, c, d, e, f, g, h, i, j, k, l, m, n) { if (isVRMode['call'](this)) { showPopupImageVR['call'](this, a, b, g, h, i, j); return; } var o = ![],
        p = function() { I['unbind']('loaded', s, this), x['call'](this); },
        q = function() { I['unbind']('click', q, this), M != undefined && clearTimeout(M); },
        r = function() { setTimeout(C, 0x0); },
        s = function() { this['unbind']('click', p, this), H['set']('visible', !![]), C(), J['set']('visible', !![]), I['unbind']('loaded', s, this), I['bind']('resize', r, this), M = setTimeout(t['bind'](this), 0xc8); },
        t = function() { M = undefined;
            h && (I['bind']('click', q, this), v['call'](this));
            I['bind']('userInteractionStart', D, this), I['bind']('userInteractionEnd', E, this), I['bind']('backgroundClick', w, this);
            b && (I['bind']('click', A, this), I['set']('imageCursor', 'hand'));
            J['bind']('click', w, this); if (k) k['call'](this); },
        u = function() { h && M && (M['cancel'](), M = undefined); },
        v = function() { h && (u(), M = new Timer(h / 0x3e8, x['bind'](this))); },
        w = function() { x['call'](this); },
        x = function(O) { if (n !== undefined && !!O) { n['call'](this); return; }
            this['getMainViewer']()['set']('toolTipEnabled', !![]), o = !![]; if (M) M['cancel'](); if (N) clearTimeout(N); if (h) q();
            f && f['get']('duration') > 0x0 ? f['bind']('end', z, this) : setTimeout(() => { y['call'](this); }, 0x0), I['set']('visible', ![]), J['set']('visible', ![]), H['set']('visible', ![]), this['unbind']('click', p, this), I['unbind']('backgroundClick', w, this), I['unbind']('userInteractionStart', D, this), I['unbind']('userInteractionEnd', E, this, !![]), I['unbind']('resize', r, this), b && (I['unbind']('click', A, this), I['set']('cursor', 'default')), J['unbind']('click', w, this), this['resumePlayers'](L, i == null || j), j && this['resumeGlobalAudios'](), i && this['stopGlobalAudio'](i); },
        y = function() { I['set']('image', null); if (l) l['call'](this); },
        z = function() { f['unbind']('end', z, this), y['call'](this); },
        A = function() { I['set']('image', B() ? a : b); },
        B = function() { return I['get']('image') == b; },
        C = function() { var O = I['get']('actualWidth') - I['get']('imageLeft') - I['get']('imageWidth') + 0xa,
                P = I['get']('imageTop') + 0xa; if (O < 0xa) O = 0xa; if (P < 0xa) P = 0xa;
            J['set']('right', O), J['set']('top', P); },
        D = function() { u(), N ? (clearTimeout(N), N = undefined) : J['set']('visible', ![]); },
        E = function() { v['call'](this), !o && (N = setTimeout(F, 0x12c)); },
        F = function() { N = undefined, J['set']('visible', !![]), C(); },
        G = function(O) { var P = O['get']('data'); if (P && 'extraLevels' in P) { var Q = this['rootPlayer']['createInstance'](O['get']('class')),
                    R = P['extraLevels']; for (var S = 0x0; S < R['length']; S++) { var T = R[S]; if (typeof T == 'string') R[S] = this[T['replace']('this.', '')]; }
                Q['set']('levels', O['get']('levels')['concat'](R)), O = Q; } return O; };
    this['getMainViewer']()['set']('toolTipEnabled', ![]); var H = this['veilPopupPanorama'],
        I = this['zoomImagePopupPanorama'],
        J = this['closeButtonPopupPanorama'];
    (m === !![] || m === undefined) && this['updateIndexGlobalZoomImage'](); if (g)
        for (var K in g) { J['set'](K, g[K]); }
    var L = this['pauseCurrentPlayers'](i == null || !j);
    j && this['pauseGlobalAudios'](null, !![]);
    i && this['playGlobalAudio'](i, !![]); var M = undefined,
        N = undefined;
    a = G['call'](this, a); if (b) b = G['call'](this, b); return I['bind']('loaded', s, this), setTimeout(function() { this['bind']('click', p, this, ![]); }['bind'](this), 0x0), I['set']('image', a), I['set']('customWidth', c), I['set']('customHeight', d), I['set']('showEffect', e), I['set']('hideEffect', f), I['set']('visible', !![]), x['bind'](this); };
const showPopupImageVR = function(a, b, c, d, e, f) { const g = this['getMainViewer'](),
        h = this['createInstance']('PhotoAlbumPlayer');
    h['set']('xrEnabled', !![]), h['set']('viewerArea', g), h['set']('id', 'player' + (Math['random']() + 0x1)['toString'](0x24)['substring'](0x2)), this[h['get']('id')] = h; const i = this['createInstance']('PhotoPlayList'),
        j = this['createInstance']('PhotoAlbum');
    j['set']('loop', !![]), j['set']('playList', i); const k = [];

    function l(C) { const D = this['createInstance']('Photo');
        D['set']('image', C), D['set']('width', C['get']('levels')[0x0]['get']('width')), D['set']('height', C['get']('levels')[0x0]['get']('height')); const E = this['createInstance']('PhotoCamera');
        E['set']('scaleMode', 'fit_inside'); const F = this['createInstance']('PhotoPlayListItem');
        F['set']('media', D), F['set']('camera', E), k['push'](F); }
    l['call'](this, a);
    b && l['call'](this, b); const m = function() { if (b) h['next'](); };
    g['bind']('click', m, this), i['set']('items', k); const n = this['createInstance']('PhotoAlbumPlayListItem');
    n['set']('media', j), n['set']('player', h); const o = this['createInstance']('PlayList');
    o['set']('items', [n]), o['set']('id', 'playList' + (Math['random']() + 0x1)['toString'](0x24)['substring'](0x2)), this[o['get']('id')] = o; const p = this['get']('xrPanels'),
        q = () => { g['unbind']('click', m, this), o['set']('selectedIndex', -0x1), p['splice'](p['indexOf'](s), 0x1), this['set']('xrPanels', p), delete this[o['get']('id')], delete this[h['get']('id')], u['set']('selectedIndex', v), this['resumePlayers'](B, e == null || f), f && this['resumeGlobalAudios'](), e && this['stopGlobalAudio'](e); },
        r = this['createInstance']('CloseButton'); for (const C of Object['keys'](c)) { r['set'](C, c[C]); }
    r['bind']('click', q, this); const s = this['createInstance']('XRPanel');
    s['set']('yaw', 0x2d), s['set']('pitch', 0x1e), s['set']('content', r), p['push'](s), this['set']('xrPanels', p); const t = this['_getPlayListsWithViewer'](g); let u, v; for (let D of t) { if (D['get']('selectedIndex') !== -0x1) { v = D['get']('selectedIndex'), u = D; break; } } var w = g['get']('backgroundColor'),
        x = g['get']('backgroundColorRatios'),
        y = g['get']('backgroundColorDirection'),
        z = function() { n['unbind']('stop', z, this), n['bind']('stop', A, this), g['set']('backgroundColor', '#000000'); },
        A = function() { n['unbind']('stop', A, this), g['set']('backgroundColor', w), g['set']('backgroundColorRatios', x), g['set']('backgroundColorDirection', y); };
    n['bind']('start', z, this); var B = this['pauseCurrentPlayers'](e == null || !f);
    f && this['pauseGlobalAudios'](null, !![]), e && this['playGlobalAudio'](e, !![]), o['set']('selectedIndex', 0x0); };
TDV['Tour']['Script']['updateIndexGlobalZoomImage'] = function() { var a = this['veilPopupPanorama'],
        b = this['zoomImagePopupPanorama'],
        c = this['closeButtonPopupPanorama'];

    function d(h, i, j) { var k = h['indexOf'](i);
        k >= 0x0 && k < h['length'] && (h['splice'](k, 0x1)[0x0], h['splice'](j, 0x0, i)); } var e = this['get']('children'),
        f = this['getByClassName']('Window')['filter'](h => h['get']('showing'))['length'],
        g = e['length'] - f;
    d(e, a, g), d(e, b, g + 0x1), d(e, c, g + 0x2), this['set']('children', e); }, TDV['Tour']['Script']['showPopupPanoramaOverlay'] = function(a, b, c, d, e, f, g, h) { var i = this['isCardboardViewMode'](); if (a['get']('visible') || !i && this['zoomImagePopupPanorama']['get']('visible')) return;
    this['getMainViewer']()['set']('toolTipEnabled', ![]); if (!i) { var j = this['zoomImagePopupPanorama'],
            k = a['get']('showDuration'),
            l = a['get']('hideDuration'),
            m = this['pauseCurrentPlayers'](f == null || !g),
            n = a['get']('popupMaxWidth'),
            o = a['get']('popupMaxHeight'),
            p, q = function() { var v = function() { if (!this['isCardboardViewMode']()) a['set']('visible', ![]); };
                a['unbind']('showEnd', q, this), a['set']('showDuration', 0x1), a['set']('hideDuration', 0x1), p = this['showPopupImage'](c, d, a['get']('popupMaxWidth'), a['get']('popupMaxHeight'), null, null, b, e, f, g, v, r, ![], s); },
            r = function() { if (!p) return;
                p = null, s['call'](this); },
            s = function() { var v = function() { a['unbind']('hideEnd', v, this); if (h) h(); },
                    w = function() { a['unbind']('showEnd', w, this), a['bind']('hideEnd', v, this, !![]), a['set']('visible', ![]), a['set']('showDuration', k), a['set']('popupMaxWidth', n), a['set']('popupMaxHeight', o); if (p) { var z = p;
                            p = null, z(); } };
                this['resumePlayers'](m, f == null || !g), a['set']('hideDuration', l); if (!a['get']('visible') && l > 0x0) { var x = j['get']('imageWidth'),
                        y = j['get']('imageHeight');
                    a['bind']('showEnd', w, this, !![]), a['set']('showDuration', 0x1), a['set']('popupMaxWidth', x), a['set']('popupMaxHeight', y), a['set']('visible', !![]); } else { a['set']('showDuration', k); if (h) h(); }
                this['getMainViewer']()['set']('toolTipEnabled', !![]); };
        a['bind']('showEnd', q, this, !![]); } else { var t = function() { this['resumePlayers'](m, f == null || g);
                g && this['resumeGlobalAudios']();
                f && this['stopGlobalAudio'](f);
                d && (a['set']('image', c), a['unbind']('click', u, this));
                a['unbind']('hideEnd', t, this), this['getMainViewer']()['set']('toolTipEnabled', !![]); if (h) h(); },
            u = function() { a['set']('image', a['get']('image') == c ? d : c); },
            m = this['pauseCurrentPlayers'](f == null || !g);
        g && this['pauseGlobalAudios'](null, !![]);
        f && this['playGlobalAudio'](f, !![]); if (d) a['bind']('click', u, this);
        a['bind']('hideEnd', t, this, !![]); }
    this['updateIndexGlobalZoomImage'](), a['set']('visible', !![]); }, TDV['Tour']['Script']['showPopupPanoramaVideoOverlay'] = function(a, b, c, d, e) { var f = ![],
        g = function() { a['unbind']('showEnd', g), k['bind']('click', i, this), j(), k['set']('visible', !![]); }['bind'](this),
        h = function() { f = !![]; if (!a['get']('loop')) i(); }['bind'](this),
        i = function() { window['resumeAudiosBlocked'] = ![], this['getMainViewer']()['set']('toolTipEnabled', !![]), a['set']('visible', ![]), k['set']('visible', ![]), k['unbind']('click', i, this), a['unbind']('end', h, this), a['unbind']('hideEnd', i, this, !![]), this['resumePlayers'](m, !![]);
            c && this['resumeGlobalAudios'](); if (d) d(); if (e && f) e(); }['bind'](this),
        j = function() { var n = 0xa,
                o = 0xa;
            k['set']('right', n), k['set']('top', o); }['bind'](this);
    this['getMainViewer']()['set']('toolTipEnabled', ![]); var k = this['closeButtonPopupPanorama']; if (b)
        for (var l in b) { k['set'](l, b[l]); }
    window['resumeAudiosBlocked'] = !![]; var m = this['pauseCurrentPlayers'](!![]);
    c && this['pauseGlobalAudios'](), a['bind']('end', h, this, !![]), a['bind']('showEnd', g, this, !![]), a['bind']('hideEnd', i, this, !![]), a['set']('visible', !![]); }, TDV['Tour']['Script']['showWindow'] = function(a, b, c) { if (isVRMode['call'](this)) { showWindowVR['call'](this, a, b, c); return; }
    this['showWindowBase'](a, b, c); }, TDV['Tour']['Script']['showWindowBase'] = function(a, b, c) { if (a['get']('visible') == !![]) return; var d = function() { this['getMainViewer']()['set']('toolTipEnabled', !![]), c && this['resumeGlobalAudios'](), e(), this['resumePlayers'](g, !c), a['unbind']('close', d, this); },
        e = function() { a['unbind']('click', e, this), f != undefined && f['cancel'](); },
        f = undefined;
    b && (a['bind']('click', e, this), f = new Timer(b / 0x3e8, () => a['hide']()));
    this['getMainViewer']()['set']('toolTipEnabled', ![]);
    c && this['pauseGlobalAudios'](null, !![]); var g = this['pauseCurrentPlayers'](!c);
    a['bind']('close', d, this), a['show'](this, !![]); };
const showWindowVR = function(a, b, c) { const d = this['createInstance']('XRWindow');
    d['set']('autoCenter', ![]), d['set']('draggable', !![]); const e = a['getAttributeNames']()['filter'](k => { return k !== 'id'; }),
        f = d['getAttributeNames'](); for (let k of e) { f['includes'](k) && (k === 'children' ? d['set'](k, this['clone'](a['get'](k)['filter'](l => l['get']('class') !== 'ViewerArea'))) : d['set'](k, a['get'](k))); } const g = function() { this['getMainViewer']()['set']('toolTipEnabled', !![]), c && this['resumeGlobalAudios'](), h(), this['resumePlayers'](j, !c), d['unbind']('close', g, this); },
        h = function() { d['unbind']('click', h, this), i !== undefined && i['cancel'](); }; let i = undefined;
    b && (d['bind']('click', h, this), i = new Timer(b / 0x3e8, () => d['hide']()));
    this['getMainViewer']()['set']('toolTipEnabled', ![]);
    c && this['pauseGlobalAudios'](null, !![]); let j = this['pauseCurrentPlayers'](!c);
    d['bind']('close', g, this), d['show'](); };
TDV['Tour']['Script']['startModel3DWithCameraSpot'] = function(a, b) { var c = a['get']('media'),
        d = window['currentPanoramasWithCameraChanged'] == undefined || !(c['get']('id') in window['currentPanoramasWithCameraChanged']); if (!d) return; var e = c['get']('camera');
    b = Object['assign']({}, b); if (!c['get']('isLoaded')) { var f = {}; for (var g in b) { var h = 'initial' + g['charAt'](0x0)['toUpperCase']() + g['slice'](0x1);
            f[h] = e['get'](h), b[h] = b[g], e['set'](h, b[h]), delete b[g]; }
        window['currentPanoramasWithCameraChanged'] == undefined && (window['currentPanoramasWithCameraChanged'] = {}); var i = c['get']('id');
        window['currentPanoramasWithCameraChanged'][i] = [a]; var j = function() { i in window['currentPanoramasWithCameraChanged'] && delete window['currentPanoramasWithCameraChanged'][i];
            a['unbind']('begin', j, this); for (var r in f) { e['set'](r, f[r]); } };
        a['bind']('begin', j, this); } else { for (var g in b) { e['set'](g, b[g]); var h = 'initial' + g['charAt'](0x0)['toUpperCase']() + g['slice'](0x1);
            e['set'](h, b[g]); }
        e['setStoredPosition'](b); } var k = a['get']('player'),
        l = k['get']('viewerArea'),
        m = this['getActivePlayersWithViewer'](l),
        n = m['find'](function(r) { return this['getMediaFromPlayer'](r)['get']('class')['indexOf']('Panorama') != -0x1; }['bind'](this)),
        o = c['get']('data'); if (n && o['panoramaLocations']) { var p = this['getMediaFromPlayer'](n),
            q = _getObject(this, o['panoramaLocations']['find'](r => p == _getObject(this, _getObject(this, r)['get']('data')['panorama'])));
        q && !q['get']('forceModelLoading') && (q['set']('forceModelLoading', !![]), a['bind']('begin', function r() { a['unbind']('begin', r, this), q['set']('forceModelLoading', ![]); }, this)); } }, TDV['Tour']['Script']['startPanoramaWithCamera'] = function(a, b) { var c = this['getByClassName']('PlayList'); if (c['length'] == 0x0) return; var d = window['currentPanoramasWithCameraChanged'] == undefined || !(a['get']('id') in window['currentPanoramasWithCameraChanged']),
        e = []; for (var f = 0x0, g = c['length']; f < g; ++f) { var h = c[f],
            k = h['get']('items'); for (var l = 0x0, m = k['length']; l < m; ++l) { var n = k[l];
            n['get']('media') == a && (n['get']('class') == 'PanoramaPlayListItem' || n['get']('class') == 'Video360PlayListItem') && (d && e['push']({ 'camera': n['get']('camera'), 'item': n }), n['set']('camera', b)); } } if (e['length'] > 0x0) { window['currentPanoramasWithCameraChanged'] == undefined && (window['currentPanoramasWithCameraChanged'] = {}); var o = a['get']('id');
        window['currentPanoramasWithCameraChanged'][o] = e; var p = function() { o in window['currentPanoramasWithCameraChanged'] && delete window['currentPanoramasWithCameraChanged'][o]; for (var r = 0x0; r < e['length']; r++) { e[r]['item']['set']('camera', e[r]['camera']), e[r]['item']['unbind']('end', p, this); } }; for (var f = 0x0; f < e['length']; f++) { var q = e[f],
                n = q['item'];
            this['skip3DTransitionOnce'](n['get']('player')), n['bind']('end', p, this); } } }, TDV['Tour']['Script']['stopAndGoCamera'] = function(a, b) { var c = a['get']('initialSequence');
    c['pause'](); var d = function() { c['play'](); };
    new Timer(b / 0x3e8, d); }, TDV['Tour']['Script']['syncPlaylists'] = function(a) { var b = function(h, k) { for (var l = 0x0, m = a['length']; l < m; ++l) { var n = a[l]; if (n != k) { var o = n['get']('items'); for (var p = 0x0, q = o['length']; p < q; ++p) { if (o[p]['get']('media') == h) { n['get']('selectedIndex') != p && n['set']('selectedIndex', p); break; } } } } },
        c = function(h) { var j = h['source'],
                k = j['get']('selectedIndex'); if (k < 0x0) return; var l = j['get']('items')[k]['get']('media');
            b(l, j); },
        d = function(h) { var j = h['source']['get']('panoramaMapLocation'); if (j) { var k = j['get']('map');
                b(k); } }; for (var e = 0x0, f = a['length']; e < f; ++e) { a[e]['bind']('change', c, this); } var g = this['getByClassName']('MapPlayer'); for (var e = 0x0, f = g['length']; e < f; ++e) { g[e]['bind']('panoramaMapLocation_change', d, this); } }, TDV['Tour']['Script']['translate'] = function(a) { return this['get']('data')['localeManager']['trans'](a); }, TDV['Tour']['Script']['triggerOverlay'] = function(a, b) { a['get']('class') == 'PanoramaModel3DLocation' && (a = a['get']('data')['object']); if (a['get']('areas') != undefined) { var c = a['get']('areas'); for (var d = 0x0; d < c['length']; ++d) { c[d]['trigger'](b); } } else a['trigger'](b); }, TDV['Tour']['Script']['updateDeepLink'] = function(a) { a = a || {}; var b = this['mainPlayList']['get']('selectedIndex'),
        c, d = b >= 0x0 ? this['mainPlayList']['get']('items')[b]['get']('media') : this['getActiveMediaWithViewer'](this['getMainViewer']()); if (d != undefined) { var e = d['get']('data'); if (e && e['label']) { if (b >= 0x0) { var f = this['mainPlayList']['get']('items')['reduce'](function(B, C) { var D = C['get']('media')['get']('data'); return D && e['label'] == D['label'] ? B + 0x1 : B; }, 0x0); if (f != 0x1) c = '#media=' + (b + 0x1); } if (!c) c = '#media-name=' + encodeURIComponent(e['label']); } else b >= 0x0 && (c = '#media=' + (b + 0x1)); } if (d) { if (a['includeCurrentView'] === !![]) { var g = this['getActivePlayerWithViewer'](this['getMainViewer']()); if (g) switch (g['get']('class')) {
                case 'PanoramaPlayer':
                    var h = g['get']('yaw'),
                        j = g['get']('pitch'),
                        k = g['get']('hfov'); if (!isNaN(h) && !isNaN(j)) c += '&yaw=' + h['toFixed'](0x2) + '&pitch=' + j['toFixed'](0x2); if (!isNaN(k)) c += '&fov=' + k['toFixed'](0x2); break;
                case 'Model3DPlayer':
                    var l = g['get']('model'),
                        m = l['get']('camera'),
                        n = [];
                    n['push']('yaw=' + m['get']('yaw')['toFixed'](0x2)), n['push']('pitch=' + m['get']('pitch')['toFixed'](0x2)), n['push']('x=' + m['get']('x')['toFixed'](0x5)), n['push']('y=' + m['get']('y')['toFixed'](0x5)), n['push']('z=' + m['get']('z')['toFixed'](0x5)); if (m['get']('class') == 'OrbitModel3DCamera') n['push']('distance=' + m['get']('distance')['toFixed'](0x5));
                    c += '&' + n['join']('&'); break; } } if (a['includeCurrentVisibleHotspots'] === !![]) { var o = this['getOverlays'](d),
                p = [],
                q = []; for (var r = 0x0, f = o['length']; r < f; ++r) { var s = o[r],
                    t = s['get']('enabled'),
                    e = s['get']('data'); if (t === undefined || !e || !e['label']) continue; var u = encodeURIComponent(e['label']),
                    v = e['group']; if (t != e['defaultEnabledValue']) { if (t) p['push'](u);
                    else !v && q['push'](u); } } if (p['length'] > 0x0) c += '&son=' + p['join'](','); if (q['length'] > 0x0) c += '&hon=' + q['join'](','); if (d['get']('class') == 'Model3D') { var w = d['get']('variant'); if (w) c += '&variant=' + w; var x = d['get']('objects'),
                    y = [],
                    z = [];
                x['forEach'](function(B) { if (B['get']('class') == 'InnerModel3DObject')(B['get']('enabled') ? y : z)['push'](B['get']('objectId')); }); if (y['length'] > 0x0) c += '&sobjids=' + y['join'](','); if (z['length'] > 0x0) c += '&hobjids=' + z['join'](','); } } if (a['includeCurrentMeasureModel3DObjects'] === !![] && d['get']('class') == 'Model3D') { var A = [];
            d['get']('objects')['forEach'](function(B) { if (B['get']('class') == 'MeasureModel3DObject' && B['get']('mode') != 'create') { var C = [B['get']('data')['id'], B['get']('x'), B['get']('y'), B['get']('z')];
                    B['get']('points')['forEach'](function(D) { C['push'](D['get']('x'), D['get']('y'), D['get']('z')); }), C['length'] > 0x4 && A['push'](C['join'](',')); } }); if (A['length'] > 0x0) c += '&measures=' + A['join']('+'); } } return c && a['setHash'] === !![] && (location['hash'] = c), c; }, TDV['Tour']['Script']['updateMediaLabelFromPlayList'] = function(a, b, c) { var d = function() { var f = a['get']('selectedIndex'); if (f >= 0x0) { var g = function() { j['unbind']('begin', g), h(f); },
                    h = function(k) { var l = j['get']('media'),
                            m = l['get']('data'),
                            n = m !== undefined ? m['description'] : undefined;
                        i(n); },
                    i = function(k) { k !== undefined ? b['set']('html', '<div\x20style=\x22text-align:left\x22><SPAN\x20STYLE=\x22color:#FFFFFF;font-size:12px;font-family:Verdana\x22><span\x20color=\x22white\x22\x20font-family=\x22Verdana\x22\x20font-size=\x2212px\x22>' + k + '</SPAN></div>') : b['set']('html', ''); var l = b['get']('html');
                        b['set']('visible', l !== undefined && l); },
                    j = a['get']('items')[f];
                b['get']('html') ? (i('Loading...'), j['bind']('begin', g)) : h(f); } },
        e = function() { b['set']('html', undefined), a['unbind']('change', d, this), c['unbind']('stop', e, this); };
    c && c['bind']('stop', e, this), a['bind']('change', d, this), d(); }, TDV['Tour']['Script']['updateVideoCues'] = function(a, b) { var c = a['get']('items')[b],
        d = c['get']('media'); if (d['get']('cues')['length'] == 0x0) return; var e = c['get']('player'),
        f = [],
        g = function() { a['get']('selectedIndex') != b && (d['unbind']('cueChange', h, this), a['unbind']('change', g, this)); },
        h = function(j) { var k = e['get']('currentTime'),
                l = j['data']['activeCues']; for (var m = 0x0, n = f['length']; m < n; ++m) { var o = f[m];
                l['indexOf'](o) == -0x1 && (k < o['get']('startTime') || o['get']('endTime') < k + 0.5) && o['trigger']('end'); } for (var m = 0x0, n = l['length']; m < n; ++m) { var o = l[m];
                f['indexOf'](o) == -0x1 && k >= o['get']('startTime') && k < o['get']('endTime') && o['trigger']('begin'); }
            f = l; };
    d['bind']('cueChange', h, this), a['bind']('change', g, this); }, TDV['Tour']['Script']['visibleComponentsIfPlayerFlagEnabled'] = function(a, b) { var c = this['get'](b); for (var d in a) { a[d]['set']('visible', c); } }, TDV['Tour']['Script']['quizStart'] = function() { var a = this['get']('data')['quiz']; return a ? a['start']() : undefined; }, TDV['Tour']['Script']['quizFinish'] = function() { var a = this['get']('data')['quiz']; return a ? a['finish']() : undefined; }, TDV['Tour']['Script']['quizPauseTimer'] = function() { var a = this['get']('data')['quiz']; return a ? a['pauseTimer']() : undefined; }, TDV['Tour']['Script']['quizResumeTimer'] = function() { var a = this['get']('data')['quiz']; return a ? a['continueTimer']() : undefined; }, TDV['Tour']['Script']['quizSetItemFound'] = function(a) { var b = this['get']('data')['quiz']; if (b) b['setItemFound'](a); }, TDV['Tour']['Script']['quizShowQuestion'] = function(a) { var b = this['get']('data'),
        c = b['quiz'],
        d; if (c) { var e = this['pauseCurrentPlayers'](!![]),
            f = this[a],
            g, h = this['get']('data')['tour']['isIPad'](),
            i = this['get']('data')['tour']['isVRDevice'](); if (!f['media'] || this['isCardboardViewMode']()) g = this['get']('isMobile') && !h && !i ? { 'theme': { 'window': { 'height': undefined, 'maxHeight': this['get']('actualHeight'), 'optionsContainer': { 'height': '100%' } } } } : { 'theme': { 'window': { 'width': '40%', 'height': undefined, 'maxHeight': 0x2bc, 'optionsContainer': { 'width': '100%' } } } };
        else { if (this['get']('isMobile') && !h && !i && this['get']('orientation') == 'landscape') g = { 'theme': { 'window': { 'bodyContainer': { 'layout': 'horizontal', 'paddingLeft': 0x1e, 'paddingRight': 0x1e }, 'mediaContainer': { 'width': '60%', 'height': '100%' }, 'buttonsContainer': { 'paddingLeft': 0x14, 'paddingRight': 0x14 }, 'optionsContainer': { 'width': '40%', 'height': '100%', 'paddingLeft': 0x0, 'paddingRight': 0x0 } } } };
            else(h || i) && this['get']('orientation') == 'portrait' && (g = { 'theme': { 'window': { 'width': '90%' } } }); } if (this['get']('isMobile') && this['get']('orientation') == 'landscape') { var j = this['get']('data')['tour']['getNotchValue']();
            j > 0x0 && (g = this['mixObject'](g || {}, { 'theme': { 'window': { 'width': undefined, 'left': j, 'right': j } } })); } var k = this['get']('data')['textToSpeechConfig']['speechOnQuizQuestion'] && !!f['title']; if (k) this['textToSpeech'](f['title'], a);
        d = c['showQuestion'](a, g), d['then'](function(l) { if (k) this['stopTextToSpeech']();
            this['resumePlayers'](e, !![]); }['bind'](this)); } return d; }, TDV['Tour']['Script']['quizShowScore'] = function(a) { var b = this['get']('data'),
        c = b['quiz']; if (c) return this['get']('isMobile') && (a = a || {}, a = this['mixObject'](a, b[this['get']('orientation') == 'portrait' ? 'scorePortraitConfig' : 'scoreLandscapeConfig'])), c['showScore'](a); }, TDV['Tour']['Script']['quizShowTimeout'] = function(a, b) { var c = this['get']('data'),
        d = c['quiz'];
    d && (this['get']('isMobile') && (b = b || {}, b = this['mixObject'](b, c[this['get']('orientation') == 'portrait' ? 'scorePortraitConfig' : 'scoreLandscapeConfig'])), d['showTimeout'](a, b)); }, TDV['Tour']['Script']['stopTextToSpeech'] = function(a) { if (window['speechSynthesis'] && (a == undefined || this['t2sLastID'] == a)) { var b = window['speechSynthesis'];
        b['speaking'] && b['cancel'](), this['t2sLastID'] = undefined; } }, TDV['Tour']['Script']['getStateTextToSpeech'] = function(a) { return this['t2sLastID'] == a ? 'playing' : 'stopped'; }, TDV['Tour']['Script']['textToSpeech'] = function(a, b, c) { if (this['get']('mute')) return; var d = this['get']('data'),
        e = d['disableTTS'] || ![]; if (e) return; if (b != undefined && this['t2sLastID'] != b || b == undefined) { c = c || 0x0; if (this['t2sLastID'] && c > this['t2sLastPriority']) return; var f = d['tour'],
            g = d['textToSpeechConfig'],
            h = d['localeManager']['currentLocaleID']; if (window['speechSynthesis']) { var i = window['speechSynthesis'];
            i['speaking'] && i['cancel'](); var j = new SpeechSynthesisUtterance(a); if (h) j['lang'] = h; var k; if (g) { j['volume'] = g['volume'], j['pitch'] = g['pitch'], j['rate'] = g['rate']; if (g['stopBackgroundAudio']) this['pauseGlobalAudios'](null, !![]); }
            j['onend'] = function() { this['t2sLastID'] = null; if (k) clearInterval(k); if (g['stopBackgroundAudio']) this['resumeGlobalAudios'](); }['bind'](this), j['onerror'] = function(m) { console['error']('Text\x20to\x20speech\x20error:\x20', m['error']); }['bind'](this), navigator['userAgent']['indexOf']('Chrome') != -0x1 && !this['get']('isMobile') && (k = setInterval(function() { i['pause'](), i['resume'](); }, 0xbb8)), i['speak'](j), this['t2sLastPriority'] = c, this['t2sLastID'] = b; } else { if (f['isMobileApp']()) { if (!f['isIOS']()) { var l = function(m, n) { var o = { 'command': 'tts', 'type': m }; if (n) o = this['mixObject'](o, n);
                        android['sendJSON'](JSON['stringify'](o)); }['bind'](this);
                    android['onTTSEnd'] = function() { this['t2sLastID'] = null; if (g['stopBackgroundAudio']) this['resumeGlobalAudios']();
                        android['onTTSEnd'] = undefined; }['bind'](this), l('stop'); if (g) { l('init', { 'volume': g['volume'], 'pitch': g['pitch'], 'rate': g['rate'], 'language': h }); if (g['stopBackgroundAudio']) this['pauseGlobalAudios'](null, !![]); }
                    l('play', { 'text': a, 'androidCallback': 'onTTSEnd' }); } else console['error']('Text\x20to\x20Speech\x20isn\x27t\x20supported\x20on\x20this\x20browser'); } else console['error']('Text\x20to\x20Speech\x20isn\x27t\x20supported\x20on\x20this\x20browser'); } } }, TDV['Tour']['Script']['textToSpeechComponent'] = function(a) { var b = a['get']('class'),
        c; if (b == 'HTMLText') { var d = a['get']('html');
        d && (c = this['htmlToPlainText'](d, { 'linkProcess': function(e, f) { return f; } })); } else { if (b == 'Button') c = a['get']('label');
        else b == 'Label' && (c = a['get']('text')); }
    c && this['textToSpeech'](c, a['get']('id')); }, TDV['Tour']['Script']['toggleTextToSpeechComponent'] = function(a) { var b = a['get']('id'); if (this['getStateTextToSpeech'](b) != 'playing') this['textToSpeechComponent'](a);
    else this['stopTextToSpeech'](b); }, TDV['Tour']['Script']['_initTTSTooltips'] = function() {
    function a(c) { var d = c['source'];
        this['textToSpeech'](d['get']('toolTip'), d['get']('id'), 0x1); }

    function b(c) { var d = c['source'];
        this['stopTextToSpeech'](d['get']('id')); }
    setTimeout(function() { var c = this['getByClassName']('UIComponent'); for (var d = 0x0, e = c['length']; d < e; ++d) { var f = c[d],
                g = f['get']('toolTip');
            (!!g || f['get']('class') == 'ViewerArea') && (f['bind']('toolTipShow', a, this), f['bind']('toolTipHide', b, this)); } }['bind'](this), 0x0); }, TDV['Tour']['Script']['takeScreenshot'] = function(a) { var b = this['getActivePlayerWithViewer'](a); if (b && (b['get']('class') == 'PanoramaPlayer' || b['get']('class') == 'Model3DPlayer')) b['saveScreenshot'](); }, TDV['Tour']['Script']['htmlToPlainText'] = function htmlToPlainText(a, b) { var c = function(q, r) { var s = ''; for (var t = 0x0; t < r; t += 0x1) { s += q; } return s; },
        d = null,
        e = null,
        f = 'underline',
        g = 'indention',
        h = '-',
        i = 0x3,
        j = '-',
        k = ![];!!b && (typeof b['linkProcess'] === 'function' && (d = b['linkProcess']), typeof b['imgProcess'] === 'function' && (e = b['imgProcess']), !!b['headingStyle'] && (f = b['headingStyle']), !!b['listStyle'] && (g = b['listStyle']), !!b['uIndentionChar'] && (h = b['uIndentionChar']), !!b['listIndentionTabs'] && (i = b['listIndentionTabs']), !!b['oIndentionChar'] && (j = b['oIndentionChar']), !!b['keepNbsps'] && (k = b['keepNbsps'])); var l = c(h, i),
        m = String(a)['replace'](/\n|\r/g, '\x20'); const n = m['match'](/<\/body>/i);
    n && (m = m['substring'](0x0, n['index'])); const o = m['match'](/<body[^>]*>/i);
    o && (m = m['substring'](o['index'] + o[0x0]['length'], m['length']));
    m = m['replace'](/<(script|style)( [^>]*)*>((?!<\/\1( [^>]*)*>).)*<\/\1>/gi, ''), m = m['replace'](/<(\/)?((?!h[1-6]( [^>]*)*>)(?!img( [^>]*)*>)(?!a( [^>]*)*>)(?!ul( [^>]*)*>)(?!ol( [^>]*)*>)(?!li( [^>]*)*>)(?!p( [^>]*)*>)(?!div( [^>]*)*>)(?!td( [^>]*)*>)(?!br( [^>]*)*>)[^>\/])[^<>]*>/gi, ''), m = m['replace'](/<img([^>]*)>/gi, function(q, r) { var s = '',
            t = '',
            u = /src="([^"]*)"/i ['exec'](r),
            v = /alt="([^"]*)"/i ['exec'](r);
        u !== null && (s = u[0x1]);
        v !== null && (t = v[0x1]); if (typeof e === 'function') return e(s, t); if (t === '') return '![image]\x20(' + s + ')'; return '![' + t + ']\x20(' + s + ')'; });

    function p() { return function(q, r, s, t) { var u = 0x0;
            s && /start="([0-9]+)"/i ['test'](s) && (u = /start="([0-9]+)"/i ['exec'](s)[0x1] - 0x1); var v = '<p>' + t['replace'](/<li[^>]*>(((?!<li[^>]*>)(?!<\/li>).)*)<\/li>/gi, function(w, x) { var y = 0x0,
                    z = x['replace'](/(^|(<br \/>))(?!<p>)/gi, function() { if (r === 'o' && y === 0x0) return u += 0x1, y += 0x1, '<br\x20/>' + u + c(j, i - String(u)['length']); return '<br\x20/>' + l; }); return z; }) + '</p>'; return v; }; } if (g === 'linebreak') m = m['replace'](/<\/?ul[^>]*>|<\/?ol[^>]*>|<\/?li[^>]*>/gi, '\x0a');
    else { if (g === 'indention')
            while (/<(o|u)l[^>]*>(.*)<\/\1l>/gi ['test'](m)) { m = m['replace'](/<(o|u)l([^>]*)>(((?!<(o|u)l[^>]*>)(?!<\/(o|u)l>).)*)<\/\1l>/gi, p()); } } if (f === 'linebreak') m = m['replace'](/<h([1-6])[^>]*>([^<]*)<\/h\1>/gi, '\x0a$2\x0a');
    else { if (f === 'underline') m = m['replace'](/<h1[^>]*>(((?!<\/h1>).)*)<\/h1>/gi, function(q, r) { return '\x0a&nbsp;\x0a' + r + '\x0a' + c('=', r['length']) + '\x0a&nbsp;\x0a'; }), m = m['replace'](/<h2[^>]*>(((?!<\/h2>).)*)<\/h2>/gi, function(q, r) { return '\x0a&nbsp;\x0a' + r + '\x0a' + c('-', r['length']) + '\x0a&nbsp;\x0a'; }), m = m['replace'](/<h([3-6])[^>]*>(((?!<\/h\1>).)*)<\/h\1>/gi, function(q, r, s) { return '\x0a&nbsp;\x0a' + s + '\x0a&nbsp;\x0a'; });
        else f === 'hashify' && (m = m['replace'](/<h([1-6])[^>]*>([^<]*)<\/h\1>/gi, function(q, r, s) { return '\x0a&nbsp;\x0a' + c('#', r) + '\x20' + s + '\x0a&nbsp;\x0a'; })); }
    m = m['replace'](/<br( [^>]*)*>|<p( [^>]*)*>|<\/p( [^>]*)*>|<div( [^>]*)*>|<\/div( [^>]*)*>|<td( [^>]*)*>|<\/td( [^>]*)*>/gi, '\x0a'), m = m['replace'](/<a[^>]*href="([^"]*)"[^>]*>([^<]+)<\/a[^>]*>/gi, function(q, r, s) { if (typeof d === 'function') return d(r, s); return '\x20[' + s + ']\x20(' + r + ')\x20'; }), m = m['replace'](/\n[ \t\f]*/gi, '\x0a'), m = m['replace'](/\n\n+/gi, '\x0a');
    k ? (m = m['replace'](/( |\t)+/gi, '\x20'), m = m['replace'](/&nbsp;/gi, '\x20')) : m = m['replace'](/( |&nbsp;|\t)+/gi, '\x20');
    m = m['replace'](/\n +/gi, '\x0a'), m = m['replace'](/^ +/gi, ''); while (m['indexOf']('\x0a') === 0x0) { m = m['substring'](0x1); } return (m['length'] === 0x0 || m['lastIndexOf']('\x0a') !== m['length'] - 0x1) && (m += '\x0a'), m; }, TDV['Tour']['Script']['openEmbeddedPDF'] = function(a, b) { var c = !!window['MSInputMethodContext'] && !!document['documentMode']; if (c) { this['openLink'](b, '_blank'); return; } var d = a['get']('class'),
        e = !new RegExp('^(?:[a-z]+:)?//', 'i')['test'](b); if (e && d == 'WebFrame') { var f = location['origin'] + location['pathname'];
        a['set']('url', 'lib/pdfjs/web/viewer.html?file=' + encodeURIComponent(f['substring'](0x0, f['lastIndexOf']('/')) + '/' + b) + '#page=1'); } else { var g = location['origin'] == new URL(b)['origin'],
            h = '<iframe\x20\x20id=\x27googleViewer\x27\x20src=\x27https://docs.google.com/viewer?url=[url]&embedded=true\x27\x20width=\x27100%\x27\x20height=\x27100%\x27\x20frameborder=\x270\x27>' + '<p>This\x20browser\x20does\x20not\x20support\x20inline\x20PDFs.\x20Please\x20download\x20the\x20PDF\x20to\x20view\x20it:\x20<a\x20href=\x27[url]\x27>Download\x20PDF</a></p>' + '</iframe>',
            i = /^((?!chrome|android|crios|ipad|iphone).)*safari/i ['test'](navigator['userAgent']),
            j = '<div\x20id=\x22content\x22\x20style=\x22width:100%;height:100%;position:absolute;left:0;top:0;\x22></div>' + '<script\x20type=\x22text/javascript\x22>' + '!function(root,factory){\x22function\x22==typeof\x20define&&define.amd?define([],factory):\x22object\x22==typeof\x20module&&module.exports?module.exports=factory():root.PDFObject=factory()}(this,function(){\x22use\x20strict\x22;if(void\x200===window||void\x200===window.navigator||void\x200===window.navigator.userAgent||void\x200===window.navigator.mimeTypes)return!1;let\x20nav=window.navigator,ua=window.navigator.userAgent,isIE=\x22ActiveXObject\x22in\x20window,isModernBrowser=void\x200!==window.Promise,supportsPdfMimeType=void\x200!==nav.mimeTypes[\x22application/pdf\x22],isMobileDevice=void\x200!==nav.platform&&\x22MacIntel\x22===nav.platform&&void\x200!==nav.maxTouchPoints&&nav.maxTouchPoints>1||/Mobi|Tablet|Android|iPad|iPhone/.test(ua),isSafariDesktop=!isMobileDevice&&void\x200!==nav.vendor&&/Apple/.test(nav.vendor)&&/Safari/.test(ua),isFirefoxWithPDFJS=!(isMobileDevice||!/irefox/.test(ua))&&parseInt(ua.split(\x22rv:\x22)[1].split(\x22.\x22)[0],10)>18,createAXO=function(type){var\x20ax;try{ax=new\x20ActiveXObject(type)}catch(e){ax=null}return\x20ax},supportsPDFs=!isMobileDevice&&(isFirefoxWithPDFJS||supportsPdfMimeType||isIE&&!(!createAXO(\x22AcroPDF.PDF\x22)&&!createAXO(\x22PDF.PdfCtrl\x22))),embedError=function(msg,suppressConsole){return\x20suppressConsole||console.log(\x22[PDFObject]\x20\x22+msg),!1},emptyNodeContents=function(node){for(;node.firstChild;)node.removeChild(node.firstChild)},generatePDFJSMarkup=function(targetNode,url,pdfOpenFragment,PDFJS_URL,id,omitInlineStyles){emptyNodeContents(targetNode);let\x20fullURL=PDFJS_URL+\x22?file=\x22+encodeURIComponent(url)+pdfOpenFragment,div=document.createElement(\x22div\x22),iframe=document.createElement(\x22iframe\x22);return\x20iframe.src=fullURL,iframe.className=\x22pdfobject\x22,iframe.type=\x22application/pdf\x22,iframe.frameborder=\x220\x22,id&&(iframe.id=id),omitInlineStyles||(div.style.cssText=\x22position:\x20absolute;\x20top:\x200;\x20right:\x200;\x20bottom:\x200;\x20left:\x200;\x22,iframe.style.cssText=\x22border:\x20none;\x20width:\x20100%;\x20height:\x20100%;\x22,/*targetNode.style.position=\x22relative\x22,*/targetNode.style.overflow=\x22auto\x22),div.appendChild(iframe),targetNode.appendChild(div),targetNode.classList.add(\x22pdfobject-container\x22),targetNode.getElementsByTagName(\x22iframe\x22)[0]},embed=function(url,targetSelector,options){let\x20selector=targetSelector||!1,opt=options||{},id=\x22string\x22==typeof\x20opt.id?opt.id:\x22\x22,page=opt.page||!1,pdfOpenParams=opt.pdfOpenParams||{},fallbackLink=opt.fallbackLink||!0,width=opt.width||\x22100%\x22,height=opt.height||\x22100%\x22,assumptionMode=\x22boolean\x22!=typeof\x20opt.assumptionMode||opt.assumptionMode,forcePDFJS=\x22boolean\x22==typeof\x20opt.forcePDFJS&&opt.forcePDFJS,supportRedirect=\x22boolean\x22==typeof\x20opt.supportRedirect&&opt.supportRedirect,omitInlineStyles=\x22boolean\x22==typeof\x20opt.omitInlineStyles&&opt.omitInlineStyles,suppressConsole=\x22boolean\x22==typeof\x20opt.suppressConsole&&opt.suppressConsole,forceIframe=\x22boolean\x22==typeof\x20opt.forceIframe&&opt.forceIframe,PDFJS_URL=opt.PDFJS_URL||!1,targetNode=function(targetSelector){let\x20targetNode=document.body;return\x22string\x22==typeof\x20targetSelector?targetNode=document.querySelector(targetSelector):void\x200!==window.jQuery&&targetSelector\x20instanceof\x20jQuery&&targetSelector.length?targetNode=targetSelector.get(0):void\x200!==targetSelector.nodeType&&1===targetSelector.nodeType&&(targetNode=targetSelector),targetNode}(selector),fallbackHTML=\x22\x22,pdfOpenFragment=\x22\x22;if(\x22string\x22!=typeof\x20url)return\x20embedError(\x22URL\x20is\x20not\x20valid\x22,suppressConsole);if(!targetNode)return\x20embedError(\x22Target\x20element\x20cannot\x20be\x20determined\x22,suppressConsole);if(page&&(pdfOpenParams.page=page),pdfOpenFragment=function(pdfParams){let\x20prop,string=\x22\x22;if(pdfParams){for(prop\x20in\x20pdfParams)pdfParams.hasOwnProperty(prop)&&(string+=encodeURIComponent(prop)+\x22=\x22+encodeURIComponent(pdfParams[prop])+\x22&\x22);string&&(string=(string=\x22#\x22+string).slice(0,string.length-1))}return\x20string}(pdfOpenParams),forcePDFJS&&PDFJS_URL)return\x20generatePDFJSMarkup(targetNode,url,pdfOpenFragment,PDFJS_URL,id,omitInlineStyles);if(supportsPDFs||assumptionMode&&isModernBrowser&&!isMobileDevice){return\x20function(embedType,targetNode,targetSelector,url,pdfOpenFragment,width,height,id,omitInlineStyles){emptyNodeContents(targetNode);let\x20embed=document.createElement(embedType);if(embed.src=url+pdfOpenFragment,embed.className=\x22pdfobject\x22,embed.type=\x22application/pdf\x22,id&&(embed.id=id),!omitInlineStyles){let\x20style=\x22embed\x22===embedType?\x22overflow:\x20auto;\x22:\x22border:\x20none;\x22;targetSelector&&targetSelector!==document.body?style+=\x22width:\x20\x22+width+\x22;\x20height:\x20\x22+height+\x22;\x22:style+=\x22position:\x20absolute;\x20top:\x200;\x20right:\x200;\x20bottom:\x200;\x20left:\x200;\x20width:\x20100%;\x20height:\x20100%;\x22,embed.style.cssText=style}return\x20targetNode.classList.add(\x22pdfobject-container\x22),targetNode.appendChild(embed),targetNode.getElementsByTagName(embedType)[0]}(forceIframe||supportRedirect&&isSafariDesktop?\x22iframe\x22:\x22embed\x22,targetNode,targetSelector,url,pdfOpenFragment,width,height,id,omitInlineStyles)}return\x20PDFJS_URL?generatePDFJSMarkup(targetNode,url,pdfOpenFragment,PDFJS_URL,id,omitInlineStyles):(fallbackLink&&(fallbackHTML=\x22string\x22==typeof\x20fallbackLink?fallbackLink:\x22<p>This\x20browser\x20does\x20not\x20support\x20inline\x20PDFs.\x20Please\x20download\x20the\x20PDF\x20to\x20view\x20it:\x20<a\x20href=\x27[url]\x27>Download\x20PDF</a></p>\x22,targetNode.innerHTML=fallbackHTML.replace(/\x5c[url\x5c]/g,url)),embedError(\x22This\x20browser\x20does\x20not\x20support\x20embedded\x20PDFs\x22,suppressConsole))};return{embed:function(a,b,c){return\x20embed(a,b,c)},pdfobjectversion:\x222.2.3\x22,supportsPDFs:supportsPDFs}});' + 'if\x20(typeof\x20module\x20===\x20\x22object\x22\x20&&\x20module.exports)\x20{' + 'this.PDFObject\x20=\x20module.exports;' + '}' + 'PDFObject.embed(\x22' + b + '\x22,\x20\x22#content\x22,\x20{' + (g && PDFObject['supportsPDFs'] ? '\x22PDFJS_URL\x22:\x20\x22' + new URL('lib/pdfjs/web/viewer.html', document['baseURI'])['href'] + '\x22,\x20' : '') + '\x22fallbackLink\x22:\x20\x22' + h + '\x22,' + '\x22forcePDFJS\x22:\x20' + i + '});' + 'if(!PDFObject.supportsPDFs){' + '\x20var\x20iframeTimerId;' + '\x20function\x20checkIframeLoaded(){\x20\x20' + '\x20\x20\x20\x20var\x20iframe\x20=\x20document.getElementById(\x22googleViewer\x22);' + '\x20\x20\x20\x20iframe.src\x20=\x20iframe.src;' + '\x20\x20\x20\x20iframeTimerId\x20=\x20window.setTimeout(checkIframeLoaded,\x205000);' + '\x20}' + '\x20document.getElementById(\x22googleViewer\x22).addEventListener(\x22load\x22,\x20function(){' + '\x20\x20\x20clearInterval(iframeTimerId);\x20' + '\x20});' + '\x20checkIframeLoaded();' + '}' + '</script>'; if (d == 'WebFrame') a['set']('url', 'data:text/html;charset=utf-8,' + encodeURIComponent('<!DOCTYPE\x20html>' + '<html>' + '<head></head>' + '<body\x20style=\x22height:100%;width:100%;overflow:hidden;margin:0px;background-color:rgb(82,\x2086,\x2089);\x22>' + j + '</body>' + '</html>'));
        else d == 'HTML' && a['set']('content', 'data:text/html;charset=utf-8,' + encodeURIComponent(j)); } }, TDV['Tour']['Script']['unloadViewer'] = function(a) { var b = this['getByClassName']('PlayList'); for (var c of b) { const f = c['get']('selectedIndex'); if (f == -0x1) continue; const g = c['get']('items')[f],
            h = g['get']('player'); if (h === undefined) continue; const j = h['get']('viewerArea'); if (j === undefined || j !== a) continue;
        c['set']('selectedIndex', -0x1); } var d = function(k) { var l = k['get']('items'); for (var m = 0x0; m < l['length']; ++m) { var n = l[m],
                o = n['get']('player'); if (o !== undefined && o['get']('viewerArea') == a) return !![]; } return ![]; }; for (var e = b['length'] - 0x1; e >= 0x0; --e) { if (!d(b[e])) b['splice'](e, 0x1); } return b; }, TDV['Tour']['Script']['enableVR'] = function() { var a = this['getMainViewer'](),
        b = this['getActivePlayerWithViewer'](a); if (b['get']('class') == 'Model3DPlayer' && !this['get']('vrControllerAvailable')) return;
    a['set']('viewMode', 'vr'); }, TDV['Tour']['Script']['disableVR'] = function() { var a = this['getMainViewer']();
    a['set']('viewMode', 'standard'); }, TDV['Tour']['Script']['toggleVR'] = function() { var a = this['getMainViewer'](); if (a['get']('viewMode') == 'standard') this['enableVR']();
    else this['disableVR'](); }, TDV['Tour']['Script']['getKey'] = function(a) { return window[a]; }, TDV['Tour']['Script']['registerKey'] = function(a, b) { window[a] = b; }, TDV['Tour']['Script']['unregisterKey'] = function(a) { delete window[a]; }, TDV['Tour']['Script']['existsKey'] = function(a) { return a in window; };

function _getCurrentActiveModels() { var a = this['getByClassName']('Model3DPlayer'),
        b = []; for (var c of a) { var d = c['get']('model'),
            e = c['get']('viewerArea'); if (d && d['get']('isLoaded') && e && e['get']('visible')) b['push'](d); } return b; }

function _onMeasureClick(a) { var b = a['source'],
        c = b['get']('mode');
    c != 'create' && b['set']('mode', c == 'view' ? 'edit' : 'view'); }

function _forEachMeasureModel3DObject(a, b) { if (!a) a = _getCurrentActiveModels['call'](this);
    a['forEach'](function(c) { c['get']('objects')['forEach'](function(d) { if (d['get']('class') == 'MeasureModel3DObject') b(c, d); }['bind'](this)); }['bind'](this)); }

function _deleteModel3DObjects(a, b) { if (!a) a = _getCurrentActiveModels['call'](this);
    a['forEach'](function(c) { var d = c['get']('objects'),
            e = d['filter'](function(f) { return !b['call'](this, f); });
        e['length'] != d['length'] && (c['set']('objects', e), d['forEach'](function(f) { if (b['call'](this, f)) this['disposeInstance'](f); }['bind'](this))); }['bind'](this)); }

function _cloneMeasureModel3DObject(a) { var b = this['clone'](a); return b['set']('data', { 'id': a['get']('id') }), b; }
TDV['Tour']['Script']['startMeasurement'] = function(a, b) { if (!a) a = _getCurrentActiveModels['call'](this); var c = {},
        d = {},
        e = {};
    a['forEach'](function(g) { var h = g['get']('objects'),
            i = h['findIndex'](function(n) { return n['get']('class') == 'MeasureModel3DObject' && n['get']('mode') == 'create'; }),
            j = i != -0x1; if (j) { var k = h[i]; if (k['get']('points')['length'] == 0x0) h['splice'](i, 0x1), this['disposeInstance'](k);
            else k['set']('mode', 'view'); }
        h['forEach'](function(n) { if (n['get']('class') == 'MeasureModel3DObject' && n['get']('mode') == 'edit') n['set']('mode', 'view'); }['bind'](this)); var l = _cloneMeasureModel3DObject['call'](this, b);
        this['cloneBindings'](b, l, 'modeChange'), l['set']('mode', 'create'), l['bind']('click', _onMeasureClick, this); var m = g['get']('camera');
        l['bind']('modeChange', function n() { l['get']('mode') == 'create' ? (c[g['get']('id')] = g['get']('surfaceSelectionEnabled'), g['set']('surfaceSelectionEnabled', !![]), m['get']('class') == 'FlyOverModel3DCamera' && (d[g['get']('id')] = m['get']('doubleClickAction'), m['set']('doubleClickAction', 'none'))) : (l['unbind']('modeChange', n, this), g['set']('surfaceSelectionEnabled', c[g['get']('id')]), m['get']('class') == 'FlyOverModel3DCamera' && m['set']('doubleClickAction', d[g['get']('id')]), h['forEach'](function(o) { var p = e[o['get']('id')];
                p && o['set']('rollOverEnabled', p['rollOverEnabled']); })); }, this), a['length'] > 0x0 && l['bind']('distanceChange', function o() { l['unbind']('distanceChange', o, this), f['call'](this, a['filter'](p => p != g)); }, this), h['forEach'](function(p) { var q = p['get']('id');
            q && (e[q] = { 'rollOverEnabled': p['get']('rollOverEnabled') }, p['set']('rollOverEnabled', !![])); }), h = h['concat'](), h['push'](l), g['set']('objects', h); }['bind'](this));

    function f(g) { this['stopMeasurement'](g); for (var h of g) { var i = h['get']('id');
            h['set']('surfaceSelectionEnabled', c[i]); if (i in d) h['get']('camera')['set']('doubleClickAction', d[i]); } } }, TDV['Tour']['Script']['stopMeasurement'] = function(a) { _deleteModel3DObjects['call'](this, a, function(b) { return b['get']('class') == 'MeasureModel3DObject' && b['get']('mode') == 'create' && b['get']('points')['length'] == 0x0; }), _forEachMeasureModel3DObject['call'](this, a, function(b, c) { c['get']('mode') == 'create' && c['set']('mode', 'edit'); }); }, TDV['Tour']['Script']['toggleMeasurement'] = function(a, b) { if (!a) a = _getCurrentActiveModels['call'](this); var c = a['some'](function(d) { var e = d['get']('objects'),
            f = e['find'](function(g) { return g['get']('class') == 'MeasureModel3DObject' && g['get']('mode') == 'create'; }); return f != null; }); if (!c) this['startMeasurement'](a, b);
    else this['stopMeasurement'](a); }, TDV['Tour']['Script']['cleanAllMeasurements'] = function(a) { _deleteModel3DObjects['call'](this, a, function(b) { return b['get']('class') == 'MeasureModel3DObject'; }); }, TDV['Tour']['Script']['cleanSelectedMeasurements'] = function(a) { _deleteModel3DObjects['call'](this, a, function(b) { return b['get']('class') == 'MeasureModel3DObject' && b['get']('mode') == 'edit'; }); }, TDV['Tour']['Script']['setMeasurementsVisibility'] = function(a, b) { _forEachMeasureModel3DObject['call'](this, a, function(c, d) { d['set']('enabled', b); }); }, TDV['Tour']['Script']['toggleMeasurementsVisibility'] = function(a) { _forEachMeasureModel3DObject['call'](this, a, function(b, c) { c['set']('enabled', !c['get']('enabled')); }); }, TDV['Tour']['Script']['setMeasurementUnits'] = function(a) { _forEachMeasureModel3DObject['call'](this, null, function(b, c) { c['set']('units', a); }); };
//# sourceMappingURL=script.js.map
//Generated with v2026.0.8, Fri Jul 3 2026

var tour;
var devicesUrl = { "mobile": "script_mobile.js", "general": "script_general.js" };
const hasOwn = Object.hasOwn || function(obj, prop) {
    return Object.prototype.hasOwnProperty.call(obj, prop);
};

(function() {
    function isLikelyWatermarkElement(el) {
        if (!el || el.nodeType !== 1) return false;
        var className = (el.className || '').toLowerCase();
        var id = (el.id || '').toLowerCase();
        var style = (el.getAttribute('style') || '').toLowerCase();
        var src = (el.getAttribute('src') || '').toLowerCase();
        var alt = (el.getAttribute('alt') || '').toLowerCase();
        var text = (el.textContent || '').toLowerCase();
        var isOverlayLike = /position\s*:\s*(absolute|fixed)|z-index|pointer-events/.test(style);
        var hasWatermarkKeywords = /3dvista|academic|watermark|branding|brand|logo/.test(text) ||
            /3dvista|academic|watermark|branding|brand|logo/.test(className) ||
            /3dvista|academic|watermark|branding|brand|logo/.test(id) ||
            /3dvista|academic|watermark|branding|brand|logo/.test(src) ||
            /3dvista|academic|watermark|branding|brand|logo/.test(alt);
        var tagName = (el.tagName || '').toLowerCase();
        return hasWatermarkKeywords && (isOverlayLike || tagName === 'img' || tagName === 'svg' || tagName === 'canvas');
    }

    function removeWatermarkOverlay() {
        if (!document || !document.body) return;
        var elements = Array.from(document.querySelectorAll('div,span,svg,img,canvas'));
        for (var i = 0; i < elements.length; ++i) {
            var el = elements[i];
            if (isLikelyWatermarkElement(el)) {
                try {
                    if (el.parentNode) {
                        el.parentNode.removeChild(el);
                    }
                } catch (e) {}
            }
        }
    }

    window.removeWatermarkOverlay = removeWatermarkOverlay;

    function scheduleCleanup() {
        removeWatermarkOverlay();
        setTimeout(removeWatermarkOverlay, 250);
        setTimeout(removeWatermarkOverlay, 1000);
        setTimeout(removeWatermarkOverlay, 3000);
        setTimeout(removeWatermarkOverlay, 8000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', scheduleCleanup, { once: true });
    } else {
        scheduleCleanup();
    }

    if (window.MutationObserver) {
        var observer = new MutationObserver(function() {
            scheduleCleanup();
        });
        try {
            observer.observe(document.documentElement || document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['style', 'class', 'src', 'id', 'alt']
            });
        } catch (e) {}
    }

    window.addEventListener('load', scheduleCleanup);
})();

(function() {
    var deviceType = ['general'];
    var device = TDV.PlayerAPI.device;
    if (device == TDV.PlayerAPI.DEVICE_IPAD)
        deviceType.unshift('ipad');
    else if (device == TDV.PlayerAPI.DEVICE_OCULUS_QUEST_2)
        deviceType.unshift('quest2');
    else if (device == TDV.PlayerAPI.DEVICE_OCULUS_QUEST_3)
        deviceType.unshift('quest3');
    else if (device == TDV.PlayerAPI.DEVICE_PICO_4 ||
        device == TDV.PlayerAPI.DEVICE_PICO_G3 ||
        device == TDV.PlayerAPI.DEVICE_PICO_NEO2 ||
        device == TDV.PlayerAPI.DEVICE_PICO_NEO3)
        deviceType.unshift('pico');
    else if (device == TDV.PlayerAPI.DEVICE_PICO_4_ULTRA)
        deviceType.unshift('pico_ultra');
    else if (device == TDV.PlayerAPI.DEVICE_VIVE_FOCUS || device == TDV.PlayerAPI.DEVICE_PICO_G2)
        deviceType.unshift('htc');
    else if (TDV.PlayerAPI.mobile)
        deviceType.unshift('mobile');
    var url;
    for (var i = 0; i < deviceType.length; ++i) {
        var d = deviceType[i];
        if (d in devicesUrl) {
            url = devicesUrl[d];
            break;
        }
    }
    if (typeof url == "object") {
        var orient = TDV.PlayerAPI.getOrientation();
        if (orient in url) {
            url = url[orient];
        }
    }
    if (url === undefined) {
        console.error("Unknown device type: " + deviceType);
        return;
    }
    var link = document.createElement('link');
    link.rel = 'preload';
    link.href = url + "?v=1783053127873";
    link.as = 'script';
    var el = document.getElementsByTagName('script')[0];
    el.parentNode.insertBefore(link, el);
})();

function loadTour() {
    if (tour) return;

    if (/AppleWebKit/.test(navigator.userAgent) && /Mobile\/\w+/.test(navigator.userAgent)) {
        var preloadContainer = document.getElementById('preloadContainer');
        if (preloadContainer)
            document.body.style.backgroundColor = window.getComputedStyle(preloadContainer).backgroundColor;
    }

    var settings = new TDV.PlayerSettings();
    settings.set(TDV.PlayerSettings.CONTAINER, document.getElementById('viewer'));
    settings.set(TDV.PlayerSettings.WEBVR_POLYFILL_URL, 'lib/WebVRPolyfill.js?v=1783053127873');
    settings.set(TDV.PlayerSettings.HLS_URL, 'lib/Hls.js?v=1783053127873');
    settings.set(TDV.PlayerSettings.QUERY_STRING_PARAMETERS, 'v=1783053127873');

    tour = new TDV.Tour(settings, devicesUrl);
    tour.bind(TDV.Tour.EVENT_TOUR_INITIALIZED, onVirtualTourInit);
    tour.bind(TDV.Tour.EVENT_TOUR_LOADED, onVirtualTourLoaded);
    tour.bind(TDV.Tour.EVENT_TOUR_ENDED, onVirtualTourEnded);
    tour.load();
}

function pauseTour() {
    if (!tour)
        return;

    tour.pause();
}

function resumeTour() {
    if (!tour)
        return;

    tour.resume();
}

function exportTourState() {
    if (!tour)
        return;

    return tour.exportState();
}

function importTourState(state) {
    if (!tour)
        return;

    tour.importState(state);
}

function onVirtualTourInit() {
    var updateTexts = function() {
        document.title = this.trans("tour.name")
    };

    tour.locManager.bind(TDV.Tour.LocaleManager.EVENT_LOCALE_CHANGED, updateTexts.bind(tour.locManager));

    if (tour.player.cookiesEnabled)
        enableCookies();
    else
        tour.player.bind('enableCookies', enableCookies);
}

function onVirtualTourLoaded() {
    disposePreloader();
}

function onVirtualTourEnded() {

}

function enableCookies() {

}

function setMediaByIndex(index) {
    if (!tour)
        return;

    tour.setMediaByIndex(index);
}

function setMediaByName(name) {
    if (!tour)
        return;

    tour.setMediaByName(name);
}

function showPreloader() {
    var preloadContainer = document.getElementById('preloadContainer');
    if (preloadContainer != undefined)
        preloadContainer.style.opacity = 1;
}

function disposePreloader() {
    var preloadContainer = document.getElementById('preloadContainer');
    if (preloadContainer == undefined)
        return;

    var transitionEndName = transitionEndEventName();
    if (transitionEndName) {
        preloadContainer.addEventListener(transitionEndName, hide, false);
        preloadContainer.style.opacity = 0;
        setTimeout(hide, 500); //Force hide. Some cases the transitionend event isn't dispatched with an iFrame.
    } else {
        hide();
    }

    function hide() {

        document.body.style.backgroundColor = window.getComputedStyle(preloadContainer).backgroundColor;
        preloadContainer.style.visibility = 'hidden';
        preloadContainer.style.display = 'none';
        var videoList = preloadContainer.getElementsByTagName("video");
        for (var i = 0; i < videoList.length; ++i) {
            var video = videoList[i];
            video.pause();
            while (video.children.length)
                video.removeChild(video.children[0]);
        }
    }

    function transitionEndEventName() {
        var el = document.createElement('div');
        var transitions = {
            'transition': 'transitionend',
            'OTransition': 'otransitionend',
            'MozTransition': 'transitionend',
            'WebkitTransition': 'webkitTransitionEnd'
        };

        var t;
        for (t in transitions) {
            if (el.style[t] !== undefined) {
                return transitions[t];
            }
        }

        return undefined;
    }
}

function onBodyClick() {
    document.body.removeEventListener("click", onBodyClick);
    document.body.removeEventListener("touchend", onBodyClick);

}

function onLoad() {
    if (/AppleWebKit/.test(navigator.userAgent) && /Mobile\/\w+/.test(navigator.userAgent)) {
        var onOrientationChange = function() {
            document.documentElement.style.height = 'initial';
            document.body.style.height = 'initial';
            Array.from(document.querySelectorAll('.fill-viewport')).forEach(function(element) {
                element.classList.toggle('landscape-right', window.orientation == -90);
                element.classList.toggle('landscape-left', window.orientation == 90);
            });
            setTimeout(function() {
                document.documentElement.style.height = '100dvh';
                document.body.style.height = undefined;
            }, 500);
        };
        window.addEventListener('orientationchange', onOrientationChange);
        onOrientationChange();
    }

    var params = getParams(location.search.substr(1));
    if (hasOwn(params, "skip-loading")) {
        loadTour();
        disposePreloader();
        return;
    }

    if (isOVRWeb()) {
        showPreloader();
        loadTour();
        return;
    }

    showPreloader();
    loadTour();
}

function onMessage(event) {
    let data = event.data;
    switch (data.type) {
        case 'pauseTour':
            pauseTour();
            break;
        case 'resumeTour':
            resumeTour();
            break;
        case 'exportState':
            event.source.postMessage({
                type: 'exportState',
                state: exportTourState()
            }, event.origin);
            break;
        case 'importState':
            importTourState(data.state);
            break;
    }
}



function playVideo(video, autoplayMuted, clickComponent) {
    function hasAudio(video) {
        return video.mozHasAudio ||
            Boolean(video.webkitAudioDecodedByteCount) ||
            Boolean(video.audioTracks && video.audioTracks.length);
    }

    function detectUserAction() {
        var component = clickComponent || document.getElementById('preloadContainer');
        var onVideoClick = function(e) {
            var videos = document.getElementsByTagName("video");
            for (var i = 0; i < videos.length; i++) {
                var video = videos[i];
                if (video.paused) {
                    video.play();
                }
                video.muted = false;
                if (hasAudio(video)) {
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    e.preventDefault();
                }
            }

            component.removeEventListener('click', onVideoClick);
            component.removeEventListener('touchend', onVideoClick);

            if (component === clickComponent) {
                setComponentVisibility(false);
            }
        };
        component.addEventListener("click", onVideoClick);
        component.addEventListener("touchend", onVideoClick);
    }

    function setComponentVisibility(visible) {
        clickComponent.style.visibility = visible ? 'visible' : 'hidden';
    }

    var canPlay = true;
    var promise = video.play();
    if (promise) {
        promise.catch(function() {
            if (clickComponent)
                setComponentVisibility(true);
            canPlay = false;
            if (autoplayMuted) {
                video.muted = true;
                video.play();
            }
            detectUserAction();
        });
    } else {
        canPlay = false;
    }

    if (!canPlay || video.muted) {
        detectUserAction();
    } else if (clickComponent) {
        setComponentVisibility(false);
    }
}

function isOVRWeb() {
    return new URLSearchParams(window.location.hash.substring(1)).has("ovrweb");
}

function getParams(value) {
    const params = new URLSearchParams(value);
    const result = Object.create(null); // evita prototype pollution
    for (const [key, value] of params.entries()) {
        result[key.toLowerCase()] = value;
    }
    return result;
}

document.addEventListener('DOMContentLoaded', onLoad);
window.addEventListener('message', onMessage);