const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, 'slugs_config.json');

function restoreOriginalSyntax(p) {
    if (!fs.existsSync(p)) return;
    let content = fs.readFileSync(p, 'utf8');

    // Xóa bộ lọc nếu còn
    let startIdx = content.indexOf('// --- 3DVISTA DYNAMIC FILTER ---');
    let endIdx = content.indexOf('// --- END 3DVISTA DYNAMIC FILTER ---');
    if (startIdx > -1 && endIdx > -1) {
        let before = content.substring(0, startIdx);
        let after = content.substring(endIdx + '// --- END 3DVISTA DYNAMIC FILTER ---'.length);
        content = before + after.trimLeft();
    }

    // Xóa bộ lọc HARDCODED nếu còn
    startIdx = content.indexOf('// --- 3DVISTA HARDCODED FILTER ---');
    endIdx = content.indexOf('// --- END 3DVISTA HARDCODED FILTER ---');
    if (startIdx > -1 && endIdx > -1) {
        let before = content.substring(0, startIdx);
        let after = content.substring(endIdx + '// --- END 3DVISTA HARDCODED FILTER ---'.length);
        content = before + after.trimLeft();
    }

    // Khôi phục đuôi file hoàn hảo (chính xác như bản gốc 3DVista)
    let badTail1 = "    return a;\n} }, TDV['PlayerAPI']['defineScript'](script);";
    let badTail2 = "    return a;\n}, TDV['PlayerAPI']['defineScript'](script);";
    let badTail3 = "    return a;\\n} }, TDV['PlayerAPI']['defineScript'](script);";
    let badTail4 = "    return a;\\n}, TDV['PlayerAPI']['defineScript'](script);";

    let perfectTail = "    return a;\n};\n\n\nTDV['PlayerAPI']['defineScript'](script);";

    // Dùng regex để bắt tất cả các dạng lỗi do các đoạn script trước gây ra
    let regex = /return a;[\s\S]*?TDV\['PlayerAPI'\]\['defineScript'\]\(script\);/g;
    if (regex.test(content)) {
        content = content.replace(regex, perfectTail);
        fs.writeFileSync(p, content);
    }
}

function generateSlugs() {
    let slugsConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    let scriptBase = fs.readFileSync(path.join(__dirname, 'script.js'), 'utf8');

    for (const [slug, allowedPanoramas] of Object.entries(slugsConfig)) {
        console.log(`Đang tạo 3 nhóm file cho slug: ${slug}`);

        // 1. Tạo script_{slug}.js
        let newScriptContent = scriptBase.replace(/['"]script_general\.js['"]/g, `'script_general_${slug}.js'`);
        newScriptContent = newScriptContent.replace(/['"]script_mobile\.js['"]/g, `'script_mobile_${slug}.js'`);
        fs.writeFileSync(path.join(__dirname, `script_${slug}.js`), newScriptContent);

        // 2. Tạo file HTML trỏ tới script_{slug}.js (không cần thẻ <head> interceptor nữa)
        let indexHtml = fs.readFileSync(path.join(__dirname, 'index.htm'), 'utf8');
        let newHtml = indexHtml.replace(/"script\.js\?v=\d+"/g, `"script_${slug}.js?v=" + Date.now()`);
        newHtml = newHtml.replace(/'script\.js\?v=\d+'/g, `'script_${slug}.js?v=' + Date.now()`);
        newHtml = newHtml.replace(/"script\.js"/g, `"script_${slug}.js"`);
        fs.writeFileSync(path.join(__dirname, `${slug}.html`), newHtml);

        // 3. Tạo script_general_{slug}.js và script_mobile_{slug}.js
        ['script_general.js', 'script_mobile.js'].forEach(file => {
            let p = path.join(__dirname, file);
            if (!fs.existsSync(p)) return;
            let content = fs.readFileSync(p, 'utf8');

            // Chèn bộ lọc cứng (hardcoded) vào ĐÚNG VỊ TRÍ, ngay trước TDV['PlayerAPI']
            let filterCode = `
// --- 3DVISTA HARDCODED FILTER ---
(function() {
    try {
        var allowed = ${JSON.stringify(allowedPanoramas)};
        if (typeof script !== 'undefined' && script.definitions) {
            var defs = script.definitions;
            var removedItemIds = {};
            var newDefs = [];
            
            // Lọc các definitions
            for (var i = 0; i < defs.length; i++) {
                var d = defs[i];
                var keep = true;
                
                if (d && d.class === "PanoramaPlayListItem") {
                    var mediaId = d.media ? d.media.replace("this.", "") : "";
                    if (mediaId.indexOf("panorama_") === 0 && allowed.indexOf(mediaId) === -1) {
                        removedItemIds[d.id] = true;
                        keep = false;
                    }
                } else if (d && d.class === "Panorama") {
                    if (d.id && d.id.indexOf("panorama_") === 0 && allowed.indexOf(d.id) === -1) {
                        keep = false; // Xóa hẳn Panorama khỏi bộ nhớ
                    }
                }
                
                if (keep) newDefs.push(d);
            }
            script.definitions = newDefs;
            
            // Xóa các tham chiếu trong PlayList và Menu
            for (var i = 0; i < newDefs.length; i++) {
                var d = newDefs[i];
                
                // Lọc items array (dùng cho PlayList, Menu...)
                if (d && d.items && d.items.length) {
                    var newItems = [];
                    for (var j = 0; j < d.items.length; j++) {
                        var itemRef = d.items[j];
                        if (typeof itemRef === 'string') {
                            var id = itemRef.replace("this.", "");
                            if (!removedItemIds[id]) newItems.push(itemRef);
                        } else if (itemRef && typeof itemRef === 'object' && itemRef.media) {
                            var mediaId = itemRef.media.replace("this.", "");
                            if (mediaId.indexOf("panorama_") === 0 && allowed.indexOf(mediaId) === -1) {
                            } else newItems.push(itemRef);
                        } else newItems.push(itemRef);
                    }
                    d.items = newItems;
                }
                
                // Lọc adjacentPanoramas (các hotspot chuyển cảnh)
                if (d && d.adjacentPanoramas && d.adjacentPanoramas.length) {
                    var newAdj = [];
                    for (var j = 0; j < d.adjacentPanoramas.length; j++) {
                        var adj = d.adjacentPanoramas[j];
                        if (adj && adj.panorama) {
                            var panoId = adj.panorama.replace("this.", "");
                            if (panoId.indexOf("panorama_") === 0 && allowed.indexOf(panoId) === -1) {
                                // Bỏ qua hotspot này vì dẫn tới pano đã bị khóa
                            } else newAdj.push(adj);
                        } else {
                            newAdj.push(adj);
                        }
                    }
                    d.adjacentPanoramas = newAdj;
                }
            }
        }
    } catch(e) { console.log(e); }
})();
// --- END 3DVISTA HARDCODED FILTER ---

TDV['PlayerAPI']['defineScript'](script);`;

            content = content.replace("TDV['PlayerAPI']['defineScript'](script);", filterCode);

            let newFile = file.replace('.js', `_${slug}.js`);
            fs.writeFileSync(path.join(__dirname, newFile), content);
            console.log(`Đã tạo file đã lọc: ${newFile}`);
        });
    }
}

try {
    restoreOriginalSyntax(path.join(__dirname, 'script_general.js'));
    restoreOriginalSyntax(path.join(__dirname, 'script_mobile.js'));
    console.log("Đã khôi phục cú pháp gốc 100%!");

    generateSlugs();
    console.log("\n[THÀNH CÔNG] Đã chia thành 3 nhóm file riêng biệt cho mỗi slug!");
} catch (e) {
    console.error(e);
}
