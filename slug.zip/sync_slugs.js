const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, 'slugs_config.json');
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

// Quét tất cả các file .html trong thư mục (trừ index.htm)
const files = fs.readdirSync(__dirname);
const htmlFiles = files.filter(f => f.endsWith('.html') && f !== 'index.htm');

let updated = false;

htmlFiles.forEach(htmlFile => {
    let newSlug = htmlFile.replace('.html', '');
    let htmlContent = fs.readFileSync(path.join(__dirname, htmlFile), 'utf8');
    
    // Tìm xem file HTML này đang trỏ tới script_XXXX.js nào
    let match = htmlContent.match(/script_([a-zA-Z0-9_-]+)\.js/);
    if (match) {
        let oldSlug = match[1];
        
        // Nếu tên file HTML khác với tên script bên trong, nghĩa là người dùng vừa đổi tên file HTML!
        if (oldSlug !== newSlug) {
            console.log(`\n🔄 Phát hiện bạn vừa đổi tên file HTML thành: ${htmlFile}`);
            console.log(`Đang tự động đồng bộ hóa các file JS liên quan từ '${oldSlug}' sang '${newSlug}'...`);
            
            // 1. Cập nhật nội dung bên trong file HTML
            htmlContent = htmlContent.replace(new RegExp(`script_${oldSlug}\\.js`, 'g'), `script_${newSlug}.js`);
            fs.writeFileSync(path.join(__dirname, htmlFile), htmlContent);
            
            // 2. Đổi tên 3 file JS liên quan (nếu chúng tồn tại)
            const jsFilesToRename = [
                { old: `script_${oldSlug}.js`, new: `script_${newSlug}.js` },
                { old: `script_general_${oldSlug}.js`, new: `script_general_${newSlug}.js` },
                { old: `script_mobile_${oldSlug}.js`, new: `script_mobile_${newSlug}.js` }
            ];
            
            jsFilesToRename.forEach(f => {
                let oldPath = path.join(__dirname, f.old);
                let newPath = path.join(__dirname, f.new);
                if (fs.existsSync(oldPath)) {
                    fs.renameSync(oldPath, newPath);
                }
            });
            
            // 3. Sửa nội dung file script_{newSlug}.js để trỏ tới đúng file general và mobile mới
            let mainScriptPath = path.join(__dirname, `script_${newSlug}.js`);
            if (fs.existsSync(mainScriptPath)) {
                let mainScriptContent = fs.readFileSync(mainScriptPath, 'utf8');
                mainScriptContent = mainScriptContent.replace(new RegExp(`script_general_${oldSlug}\\.js`, 'g'), `script_general_${newSlug}.js`);
                mainScriptContent = mainScriptContent.replace(new RegExp(`script_mobile_${oldSlug}\\.js`, 'g'), `script_mobile_${newSlug}.js`);
                fs.writeFileSync(mainScriptPath, mainScriptContent);
            }
            
            // 4. Cập nhật slugs_config.json
            if (config[oldSlug]) {
                config[newSlug] = config[oldSlug];
                delete config[oldSlug];
            }
            
            updated = true;
            console.log(`✅ Đã đồng bộ thành công toàn bộ JS cho '${newSlug}'!`);
        }
    }
});

if (updated) {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    console.log(`\n[THÀNH CÔNG] Đã cập nhật xong slugs_config.json và toàn bộ file JS!`);
} else {
    console.log("Mọi thứ đã đồng bộ, không phát hiện sự thay đổi tên file HTML nào.");
}
