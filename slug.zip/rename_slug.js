const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const args = process.argv.slice(2);
if (args.length < 2) {
    console.error("Cú pháp: node rename_slug.js <tên_cũ> <tên_mới>");
    console.error("Ví dụ: node rename_slug.js khutrungbay phongtruyenthong");
    process.exit(1);
}

const oldSlug = args[0];
const newSlug = args[1];
const configPath = path.join(__dirname, 'slugs_config.json');

// 1. Cập nhật file cấu hình
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
if (!config[oldSlug]) {
    console.error(`LỖI: Không tìm thấy nhóm '${oldSlug}' trong file slugs_config.json`);
    process.exit(1);
}

// Chuyển dữ liệu sang key mới và xóa key cũ
config[newSlug] = config[oldSlug];
delete config[oldSlug];

fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
console.log(`[1/3] Đã cập nhật file slugs_config.json: đổi '${oldSlug}' thành '${newSlug}'`);

// 2. Xóa các file cũ đã tạo trước đó
const filesToDelete = [
    `${oldSlug}.html`,
    `script_${oldSlug}.js`,
    `script_general_${oldSlug}.js`,
    `script_mobile_${oldSlug}.js`
];

console.log(`[2/3] Đang dọn dẹp các file cũ...`);
filesToDelete.forEach(file => {
    let p = path.join(__dirname, file);
    if (fs.existsSync(p)) {
        try { 
            fs.unlinkSync(p); 
            console.log(`  - Đã xóa: ${file}`); 
        } catch (e) { 
            console.error(`  ! Không thể xóa ${file}:`, e.message); 
        }
    }
});

// 3. Chạy lại tiến trình tạo file mới
console.log(`[3/3] Đang tự động tạo lại hệ thống file với tên mới...`);
try {
    execSync('node generate_slugs.js', { stdio: 'inherit' });
    console.log(`\n🎉 HOÀN TẤT! Đã tự động đổi tên và tái tạo hệ thống thành công.`);
} catch (e) {
    console.error("Lỗi trong quá trình tạo file mới:", e.message);
}
